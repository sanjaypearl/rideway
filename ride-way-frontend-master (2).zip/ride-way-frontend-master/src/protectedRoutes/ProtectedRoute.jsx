import { Navigate } from "react-router-dom";
import authService from "../services/authService";

export const ProtectedRoute = ({ children, requiredRole }) => {
  const user = authService.getCurrentUser();

  const isLoggedIn = !!user;
  const hasCorrectRole = user?.role === requiredRole;
  const needsPasswordReset = user?.needsPasswordChange;

  if (!isLoggedIn || !hasCorrectRole || needsPasswordReset) {
    console.log("yeeppp")
    // Redirect with login modal query param
    return <Navigate to="/?loginModal=true" replace />;
  }
console.log("yeeeeeeeeeee")
  return children;
};
