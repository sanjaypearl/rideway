import apiSlice from "./apiSlice";


export const userApiSlice = apiSlice.injectEndpoints({
  tagTypes: ["User"],
  endpoints: (builder) => ({
    // 🔹 Step 1 - Sign up: send OTP
    sendSignUpOtp: builder.mutation({
      query: (body) => ({
        url: "/auth/user/signup-initiate",
        method: "POST",
        body,
      }),
    }),

    // 🔹 Step 2 - Sign up: verify OTP & create user
    verifySignUpOtp: builder.mutation({
      query: (body) => ({
        url: "/auth/user/signup-verify",
        method: "POST",
        body,
      }),
      invalidatesTags: ["User"],
    }),

    // 🔹 Step 1 - Login via OTP
    requestLoginOtp: builder.mutation({
      query: (body) => ({
        url: "/auth/login/request-otp",
        method: "POST",
        body,
      }),
    }),

    // 🔹 Step 2 - Login via OTP: verify and get token
    verifyLoginOtp: builder.mutation({
      query: (body) => ({
        url: "/auth/login/verify-otp",
        method: "POST",
        body,
      }),
    }),
  }),
});

export const {
  useSendSignUpOtpMutation,
  useVerifySignUpOtpMutation,
  useRequestLoginOtpMutation,
  useVerifyLoginOtpMutation,
} = userApiSlice;
