import toast from "react-hot-toast";
import apiSlice from "./apiSlice";

export const blogApi = apiSlice.injectEndpoints({
  tagTypes: ["GetBlog"],
  endpoints: (builder) => ({
    getBlogs: builder.query({
      query: () => "blog/get-blogs",
      transformResponse: (data) => data?.blogs || [],
      providesTags: ["GetBlog"],
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    getSingleBlog: builder.query({
      query: (id) => `blog/get-blogs/${id}`,
      transformResponse: (data) => data?.blog || null,
      providesTags: (result, error, id) => [{ type: "GetBlog", id }],
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    addBlog: builder.mutation({
      query: (blogData) => {
        const formData = new FormData();
        formData.append("title", blogData.title);
        formData.append("content", blogData.content);
        formData.append("author", blogData.author || "Admin");
        if (blogData.thumbnail) {
          formData.append("thumbnail", blogData.thumbnail);
        }

        return {
          url: "blog/add-blog",
          method: "POST",
          body: formData,
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")),
          },
        };
      },
      invalidatesTags: ["GetBlog"],
      onQueryStarted: async (blogData, { dispatch, queryFulfilled }) => {
        const optimisticBlog = {
          _id: Date.now().toString(),
          title: blogData.title,
          content: blogData.content,
          author: blogData.author || "Admin",
          thumbnail: blogData.thumbnail || null,
          date: new Date().toISOString(),
          views: 0,
        };

        const patchResult = dispatch(
          blogApi.util.updateQueryData("getBlogs", undefined, (draft) => {
            draft.push(optimisticBlog);
          })
        );

        try {
          const { data } = await queryFulfilled;
          toast.success(data.message);
        } catch (error) {
          toast.error(error?.error?.data?.error || "Failed to add blog");
          patchResult.undo();
        }
      },
    }),

    editBlog: builder.mutation({
      query: ({ id, blogData }) => {
        const formData = new FormData();
        formData.append("title", blogData.title);
        formData.append("content", blogData.content);
        formData.append("author", blogData.author || "Admin");
        if (blogData.thumbnail) {
          formData.append("thumbnail", blogData.thumbnail);
        }

        return {
          url: `blog/edit-blog/${id}`,
          method: "PUT",
          body: formData,
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")),
          },
        };
      },
      invalidatesTags: ["GetBlog"],
      onQueryStarted: async (
        { id, blogData },
        { dispatch, queryFulfilled }
      ) => {
        const patchResult = dispatch(
          blogApi.util.updateQueryData("getBlogs", undefined, (draft) => {
            const blogIndex = draft.findIndex((blog) => blog._id === id);
            if (blogIndex !== -1) {
              draft[blogIndex] = { ...draft[blogIndex], ...blogData };
            }
          })
        );

        try {
          const { data } = await queryFulfilled;
          toast.success(data.message);
        } catch (error) {
          toast.error(error?.error?.data?.error || "Failed to update blog");
          patchResult.undo();
        }
      },
    }),

    getBlogsForAdmin: builder.query({
      query: ({ search = "", page = 1, limit = 10 } = {}) => ({
        url: `blog/get-blogs-admin`,
        params: { search, page, limit },
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      transformResponse: (data) => data || { blogs: [], totalBlogs: 0 },
      providesTags: ["GetBlog"],
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    deleteBlog: builder.mutation({
      query: (id) => ({
        url: `blog/delete-blog/${id}`,
        method: "DELETE",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      invalidatesTags: ["GetBlog"],
      onQueryStarted: async (id, { dispatch, queryFulfilled }) => {
        const patchResult = dispatch(
          blogApi.util.updateQueryData("getBlogs", undefined, (draft) => {
            return draft.filter((blog) => blog._id !== id);
          })
        );

        try {
          const { data } = await queryFulfilled;
          toast.success(data.message);
        } catch (error) {
          toast.error(error?.error?.data?.error || "Failed to delete blog");
          patchResult.undo();
        }
      },
    }),
  }),
});

export const {
  useGetBlogsQuery,
  useGetSingleBlogQuery,
  useAddBlogMutation,
  useEditBlogMutation,
  useGetBlogsForAdminQuery,
  useDeleteBlogMutation,
} = blogApi;
