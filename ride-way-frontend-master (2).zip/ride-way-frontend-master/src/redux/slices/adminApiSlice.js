import apiSlice from "./apiSlice";

export const adminApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    // 📊 Admin stats
    getAdminStats: builder.query({
      query: ({ year, month }) => ({
        url: `/admin/stats?year=${year}&month=${month}`,
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")) || "",
        },
      }),
      keepUnusedDataFor: 300,
      refetchOnFocus: true,
      refetchOnReconnect: true,
      refetchOnMountOrArgChange: true,
      providesTags: (result, error, { year, month }) =>
        result
          ? [{ type: "Admin", id: `${year}-${month}` }]
          : [{ type: "Admin", id: "LIST" }],
    }),

    // 👥 Get all hosts
    getAllHosts: builder.query({
      query: ({ page = 1, limit = 10, approved = "", city = "", search = "" }) => {
        const queryParams = new URLSearchParams();
        queryParams.append("page", page);
        queryParams.append("limit", limit);
        if (approved !== "") queryParams.append("approved", approved);
        if (city) queryParams.append("city", city);
        if (search) queryParams.append("search", search);

        return {
          url: `/admin/hosts?${queryParams.toString()}`,
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")) || "",
          },
        };
      },
      providesTags: (result) =>
        result
          ? [
              ...result.hosts.map(({ _id }) => ({ type: "Hosts", id: _id })),
              { type: "Hosts", id: "LIST" },
            ]
          : [{ type: "Hosts", id: "LIST" }],
    }),

    // ✅ Verify a host
    verifyHost: builder.mutation({
      query: (id) => ({
        url: `/admin/hosts/verify/${id}`,
        method: "PATCH",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")) || "",
        },
      }),
      invalidatesTags: (result, error, id) => [
        { type: "Hosts", id },
        { type: "Hosts", id: "LIST" },
      ],
    }),

    // ❌ Delete a host
    deleteHost: builder.mutation({
      query: (id) => ({
        url: `/admin/hosts/${id}`,
        method: "DELETE",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")) || "",
        },
      }),
      invalidatesTags: (result, error, id) => [
        { type: "Hosts", id },
        { type: "Hosts", id: "LIST" },
      ],
    }),

    // ✅ Confirm a booking
    confirmBooking: builder.mutation({
      query: (orderId) => ({
        url: `/admin/order/confirm-booking/${orderId}`,
        method: "PUT",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")) || "",
        },
      }),
      invalidatesTags: (result, error, orderId) => [
        { type: "Order", id: orderId },
        { type: "Order", id: "LIST" },
      ],
      keepUnusedDataFor: 60,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),
  }),
});

export const {
  useGetAdminStatsQuery,
  useGetAllHostsQuery,
  useVerifyHostMutation,
  useDeleteHostMutation,
  useConfirmBookingMutation,
} = adminApi;