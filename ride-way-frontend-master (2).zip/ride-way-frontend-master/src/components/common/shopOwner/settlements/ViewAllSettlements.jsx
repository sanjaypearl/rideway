import React from 'react'

const ViewAllSettlements = () => {
  return (
    <div>ViewAllSettlements</div>
  )
}

export default ViewAllSettlements