/* eslint-disable react/prop-types */
import { useState } from "react";
import {
  Button,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
  IconButton,
  Input,
  Typography,
} from "@material-tailwind/react";
import { TrashIcon } from "@heroicons/react/24/outline";
import { toast } from "react-hot-toast";
import { useDeleteCouponMutation } from "../../../../redux/slices/couponApi";

export default function DeleteCouponCodeModal({ id, onSuccess }) {
  const [open, setOpen] = useState(false);
  const [verificationText, setVerificationText] = useState("");
  const requiredText = "DELETE";

  const [deleteCoupon, { isLoading }] = useDeleteCouponMutation();

  const handleOpen = () => {
    setVerificationText("");
    setOpen(!open);
  };

  const handleDelete = async () => {
    try {
      await deleteCoupon(id).unwrap();
      toast.success("Coupon deleted");
      onSuccess?.();
      handleOpen();
    } catch (error) {
      toast.error(error?.data?.error || "Failed to delete");
    }
  };

  return (
    <>
      <IconButton
        onClick={handleOpen}
        variant="text"
        className="hover:bg-transparent active:bg-transparent focus:bg-transparent transition-colors duration-300 p-2"
      >
        <TrashIcon className="h-4 w-4 text-red-500" />
      </IconButton>

      <Dialog open={open} handler={handleOpen} className="rounded-md bg-white">
        <DialogHeader>Are you sure?</DialogHeader>
        <DialogBody>
          <Typography>
            Do you really want to delete this coupon? This process cannot be undone.
          </Typography>
          <Typography className="mt-2 mb-5">
            Please type <span className="font-bold text-red-500">{requiredText}</span> to confirm.
          </Typography>
          <Input
            type="text"
            label="Enter DELETE to confirm"
            value={verificationText}
            onChange={(e) => setVerificationText(e.target.value)}
            color="blue"
          />
        </DialogBody>
        <DialogFooter>
          <Button variant="text" color="red" onClick={handleOpen} className="mr-1">
            Cancel
          </Button>
          <Button
            variant="gradient"
            color="blue"
            onClick={handleDelete}
            disabled={verificationText !== requiredText || isLoading}
          >
            Confirm
          </Button>
        </DialogFooter>
      </Dialog>
    </>
  );
}
