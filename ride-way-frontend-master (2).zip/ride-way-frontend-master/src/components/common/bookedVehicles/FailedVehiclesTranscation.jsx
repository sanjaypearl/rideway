import React from 'react'

const FailedVehiclesTranscation = () => {
  return (
    <div>FailedVehiclesTranscation</div>
  )
}

export default FailedVehiclesTranscation