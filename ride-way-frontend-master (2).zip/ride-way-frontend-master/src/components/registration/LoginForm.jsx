import { useState } from "react";
import PropTypes from "prop-types";
import { Button, Input } from "@material-tailwind/react";
import {
  useSendOtpMutation,
  useVerifyOtpMutation,
} from "@/redux/slices/authApiSlice";
import toast from "react-hot-toast";

const LoginForm = ({
  role,
  switchToSignup,
  switchToForgotPassword,
  handleClose,
}) => {
  const [identifier, setIdentifier] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState(1);
  const [isError, setIsError] = useState(false);
  const [error, setError] = useState("");

  const [sendOtp, { isLoading: isSending }] = useSendOtpMutation();
  const [verifyOtp, { isLoading: isVerifying }] = useVerifyOtpMutation();

  const isPhone = /^\d{10}$/.test(identifier);
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier);

  const handleSend = async () => {
    try {
      await sendOtp({ identifier, role }).unwrap();
      setStep(2);
    } catch (err) {
      setError(err?.data?.error || "Failed to send OTP");
      setIsError(true);
      console.error("Send OTP error:", err);
    }
  };

  const handleVerify = async () => {
    try {
      await verifyOtp({ identifier, otp, role }).unwrap();
      window.location.reload()
      handleClose();
    } catch (err) {
      setError(err?.data?.error || "OTP verification failed");
      setIsError(true);
      console.error("Verify OTP error:", err);
    }
  };

  return (
    <div className="space-y-5">
      {isError && <span className="text-red-700">{error}</span>}

      {step === 1 ? (
        <>
          <Input
            type="text"
            label="Email or Phone"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value.trim())}
            color="blue"
          />
          <Button
            className="w-full bg-blue-400 shadow-none"
            disabled={!(isPhone || isEmail) || isSending}
            onClick={handleSend}
          >
            {isSending ? "Sending…" : "Send OTP"}
          </Button>
        </>
      ) : (
        <>
          <Input
            type="text"
            maxLength={6}
            label="Enter OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            color="blue"
          />
          <Button
            className="w-full bg-blue-400 shadow-none"
            disabled={otp.length !== 6 || isVerifying}
            onClick={handleVerify}
          >
            {isVerifying ? "Verifying…" : "Verify & Sign In"}
          </Button>
        </>
      )}

      {/* links */}
      {step === 1 && role !== "admin" && (
        <p className="pt-2 text-center text-sm">
          Don't Have a  Account?{" "}
          <span
            onClick={switchToSignup}
            className="font-bold cursor-pointer text-blue-400"
          >
            SIGN UP
          </span>
        </p>
      )}
    </div>
  );
};

LoginForm.propTypes = {
  role: PropTypes.oneOf(["user", "host"]).isRequired,
  switchToSignup: PropTypes.func.isRequired,
  switchToForgotPassword: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};

export default LoginForm;
