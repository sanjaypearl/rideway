import { Button } from "@material-tailwind/react";
import SelectCityOrLocationModal from "../modal/selectCityOrLocation/SelectCityOrLocationModal";
import Swal from "sweetalert2";
import { useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import myContext from "../../context/myContext";

const SearchSection = () => {
  const navigate = useNavigate();
  const {
    startDate: contextStartDate,
    setStartDate: setContextStartDate,
    endDate: contextEndDate,
    setEndDate: setContextEndDate,
    selectedCity,
  } = useContext(myContext);

  const [startDate, setStartDate] = useState(contextStartDate || "");
  const [endDate, setEndDate] = useState(contextEndDate || "");

  useEffect(() => {
    setStartDate(contextStartDate || "");
    setEndDate(contextEndDate || "");
  }, [contextStartDate, contextEndDate]);

  const handleSearch = () => {
    if (!startDate || !endDate) {
      return Swal.fire({
        title: "Missing Dates",
        text: "Please select both start and end dates.",
        icon: "warning",
        confirmButtonText: "OK",
        confirmButtonColor: "#2563eb",
      });
    }

    if (new Date(endDate) < new Date(startDate)) {
      return Swal.fire({
        title: "Invalid Date Range",
        text: "End date cannot be before start date.",
        icon: "warning",
        confirmButtonText: "OK",
        confirmButtonColor: "#2563eb",
      });
    }

    if (startDate !== contextStartDate) setContextStartDate(startDate);
    if (endDate !== contextEndDate) setContextEndDate(endDate);
  };

  return (
    <div className="relative w-full min-h-[70vh] overflow-hidden">
      {/* Background Video */}
      <img
        className="absolute top-0 left-0 w-full h-full  z-[-1]"
        src="/images/hero-image.jpg"
      />

      {/* Overlay for better readability */}
      <div className="absolute inset-0 "></div>

      {/* Foreground Content */}
      <div className="relative z-10 flex flex-col items-center justify-center pt-16 pb-16 lg:pb:0 lg:pt-36 text-white">
        <div className="w-full max-w-3xl px-4 text-center">
          <h1 className="text-4xl lg:text-5xl font-extrabold mb-3 tracking-tight animate-fade-in">
            Two-Wheeler Rentals 
          </h1>
          <p className="text-lg lg:text-xl text-gray-200 font-medium">
            Convenient, Trustworthy, and Budget-Friendly Rides
          </p>
        </div>

        <div className="bg-transpaert text-black rounded-xl px-6 lg:px-0 lg:mt-4 w-full max-w-5xl mx-4 transform transition-all duration-300 hover:scale-[1.01]">
          <h2 className="text-center text-2xl lg:text-3xl font-semibold text-white mb-6">
            Find Your Perfect Bike or Scooty
          </h2>
          <div className="flex flex-col lg:flex-row justify-between gap-4">
            <div className="flex-1 min-w-[12rem]">
              <label className="block text-sm font-medium text-white mb-1">
                Select City
              </label>
              <div className="w-full px-4 py-3 rounded-lg border border-white focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50 text-gray-800">
                <SelectCityOrLocationModal />
              </div>
            </div>

            <div className="flex-1 min-w-[12rem]">
              <label className="block text-sm font-medium text-white mb-1">
                Pick-up Date
              </label>
              <input
                name="startDate"
                type="date"
                className="w-full uppercase px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50 text-gray-800"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>

            <div className="flex-1 min-w-[12rem]">
              <label className="block text-sm font-medium text-white mb-1">
                Drop-off Date
              </label>
              <input
                name="endDate"
                type="date"
                className="w-full uppercase px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50 text-gray-800"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                min={startDate || new Date().toISOString().split("T")[0]}
              />
            </div>

            <div className="flex-1 min-w-[10rem] flex items-end">
              <Button
                onClick={handleSearch}
                className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300 font-semibold text-lg shadow-md"
              >
                Search Vehicle
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Tailwind Animation Keyframes */}
      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fadeIn 1s ease-out;
        }
      `}</style>
    </div>
  );
};

export default SearchSection;
