
import { Card } from "@material-tailwind/react";

const services = [
  {
    icon: "/images/home/price.png", // Blue price tag icon
    title: "Affordable Prices",
    description: "Competitive rates for budget-friendly rentals",
  },
  {
    icon: "/images/home/location.png", // Blue location pin icon
    title: "Multiple Locations",
    description: "Convenient pick-up points across the city",
  },
  {
    icon: "/images/home/payment.png", // Blue credit card icon
    title: "Instant & Secure Payments",
    description: "Fast, safe, and hassle-free transactions",
  },
  {
    icon: "/images/home/bike.png", // Blue bike icon
    title: "Wide Range",
    description: "Choose from a variety of bikes and scooters",
  },
];

const Services = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 justify-center gap-6 py-12 px-4 lg:px-8 bg-gradient-to-b from-gray-50 to-white">
      {services.map((service, index) => (
        <Card
          key={index}
          className="flex flex-col items-center p-6 w-full rounded-xl border border-gray-100 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 bg-white"
        >
          <img
            src={service.icon}
            className="w-16 h-16 mb-4 transform hover:scale-110 transition-transform duration-200"
            alt={service.title}
          />
          <h3 className="text-lg font-semibold text-gray-800 mb-2">{service.title}</h3>
          <p className="text-center text-sm text-gray-600">{service.description}</p>
        </Card>
      ))}
      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in-up {
          animation: fadeInUp 0.5s ease-out forwards;
        }
        .card:nth-child(1) { animation-delay: 0.1s; }
        .card:nth-child(2) { animation-delay: 0.2s; }
        .card:nth-child(3) { animation-delay: 0.3s; }
        .card:nth-child(4) { animation-delay: 0.4s; }
      `}</style>
    </div>
  );
};

export default Services;
