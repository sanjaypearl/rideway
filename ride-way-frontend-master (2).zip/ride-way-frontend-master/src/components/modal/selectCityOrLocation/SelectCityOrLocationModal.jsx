/* eslint-disable react/prop-types */
import { useContext, useState, useEffect, useCallback } from "react";
import axios from "axios";
import { Dialog, DialogBody, Spinner } from "@material-tailwind/react";
import { AiOutlineEnvironment } from "react-icons/ai";
import { X } from "lucide-react";
import myContext from "../../../context/myContext";
import { useGetCitiesQuery } from "../../../redux/slices/cityApiSlice";
import {
  useGetVehiclesNearbyQuery,
  vehicleApi,
} from "../../../redux/slices/vehicleApiSlice";
import { useDispatch } from "react-redux";
import { memo } from "react";

const CityCard = memo(({ cityImage, _id, cityName, refetch, onClose }) => {
  const dispatch = useDispatch();
  const [resettingCache, setResettingCache] = useState(false);
  const {
    setSelectedCity,
    setVehicleCity,
    setLat,
    setLng,
    setCurrentLocationName,
  } = useContext(myContext);

  const updateSelection = useCallback(() => {
    setSelectedCity(cityName);
    setVehicleCity(_id);
    setLat(null);
    setLng(null);
    setCurrentLocationName("");

    localStorage.setItem("selectedCity", cityName);
    localStorage.setItem("vehicleCity", _id);
    localStorage.removeItem("lat");
    localStorage.removeItem("lng");
    localStorage.removeItem("currentLocationName");

    refetch();
  }, [
    cityName,
    _id,
    setSelectedCity,
    setVehicleCity,
    setLat,
    setLng,
    setCurrentLocationName,
    refetch,
  ]);

  const handleClick = () => {
    setResettingCache(true);
    dispatch(vehicleApi.util.resetApiState());
    updateSelection();
    setResettingCache(false);
    if (onClose) onClose(); // ✅ Close the modal after selection
  };

  return (
    <button
      className={`relative rounded-xl overflow-hidden w-36 h-36 shadow-lg cursor-pointer ${
        resettingCache ? "opacity-50 pointer-events-none" : ""
      }`}
      onClick={handleClick}
      disabled={resettingCache}
    >
      <img
        src={cityImage?.url}
        alt={cityName}
        className="w-full h-full object-cover"
      />
      <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white text-center py-1 transition-colors duration-300 hover:bg-blue-600 hover:bg-opacity-80">
        {cityName}
      </div>
    </button>
  );
});

const errorMessages = {
  PERMISSION_DENIED:
    "Location permission denied. Please enable it in your browser or device settings.",
  POSITION_UNAVAILABLE: "Location information is unavailable.",
  TIMEOUT: "The request to get your location timed out.",
  DEFAULT: "Unable to detect location. Please try again.",
};

export default function SelectCityOrLocationModal() {
  const [open, setOpen] = useState(false);
  const [dialogSize, setDialogSize] = useState("lg");
  const dispatch = useDispatch();

  const {
    lat,
    setLat,
    lng,
    setLng,
    vehicleType,
    setVehicleType,
    vehicleCity,
    setVehicleCity,
    selectedCity,
    setSelectedCity,
    currentLocationName,
    setCurrentLocationName,
    showAlert,
  } = useContext(myContext);

  const { data: cities, isLoading: isCitiesLoading } = useGetCitiesQuery();
  const { data, isLoading, refetch } = useGetVehiclesNearbyQuery(
    { lat, lng, vehicleCity, vehicleType },
    { skip: !vehicleCity && (!lat || !lng) }
  );

  const handleOpen = () => setOpen((prev) => !prev);
  useEffect(() => {
    setOpen(true);
  }, []);

  const loadStoredLocation = useCallback(() => {
    const storedData = {
      selectedCity: localStorage.getItem("selectedCity"),
      vehicleCity: localStorage.getItem("vehicleCity"),
      lat: localStorage.getItem("lat"),
      lng: localStorage.getItem("lng"),
      currentLocationName: localStorage.getItem("currentLocationName"),
    };

    if (storedData.selectedCity && storedData.vehicleCity) {
      setSelectedCity(storedData.selectedCity);
      setVehicleCity(storedData.vehicleCity);
      if (storedData.lat && storedData.lng) {
        setLat(Number(storedData.lat));
        setLng(Number(storedData.lng));
        setCurrentLocationName(storedData.currentLocationName || "");
      }
    }
  }, [setSelectedCity, setVehicleCity, setLat, setLng, setCurrentLocationName]);

  const handleResize = useCallback(() => {
    setDialogSize(window.innerWidth < 768 ? "xxl" : "xl");
  }, []);

  const successCallback = useCallback(
    async (position) => {
      const { latitude, longitude } = position.coords;
      setLat(latitude);
      setLng(longitude);

      try {
        const response = await axios.get(
          `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyDrROirhFaapbWyT1rusyEvBF0lpVxpUyE`
        );
        const addressComponents = response.data.results[0]?.address_components;
        const city = addressComponents?.find((component) =>
          component.types.includes("locality")
        )?.long_name;
        const locationName = response.data.results[0]?.formatted_address;

        if (city) {
          setSelectedCity(city);
          setVehicleCity(city);
          setCurrentLocationName(locationName);

          localStorage.setItem("selectedCity", city);
          localStorage.setItem("vehicleCity", city);
          localStorage.setItem("lat", latitude);
          localStorage.setItem("lng", longitude);
          localStorage.setItem("currentLocationName", locationName);

          refetch();
          setOpen(false); // Close modal after geolocation success
        } else {
          showAlert(
            "Could not determine the city from your location.",
            "error",
            2000
          );
        }
      } catch (error) {
        console.error("Error fetching location details:", error);
        showAlert("Failed to fetch location details.", "error", 2000);
      }
    },
    [
      setLat,
      setLng,
      setSelectedCity,
      setVehicleCity,
      setCurrentLocationName,
      refetch,
      showAlert,
    ]
  );

  const errorCallback = useCallback(
    (error) => {
      const errorMessage = errorMessages[error.code] || errorMessages.DEFAULT;
      console.error("Error detecting location:", error);
      showAlert(errorMessage, "error", 2000);
    },
    [showAlert]
  );

  const handleDetectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
    } else {
      showAlert("Geolocation is not supported by your browser.", "error", 2000);
    }
  };

  useEffect(() => {
    loadStoredLocation();
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, [loadStoredLocation, handleResize]);

  return (
    <>
      <div
        onClick={handleOpen}
        className="flex items-center justify-between   w-full h-full  place-items-center lg:mb-0 cursor-pointer"
      >
        <p>{selectedCity || "Select City"}</p>
        <AiOutlineEnvironment className="text-gray-500" size={20} />
      </div>

      <Dialog
        open={open}
        handler={handleOpen}
        size={dialogSize}
        className="lg:max-w-[90%] max-w-full outline-none shadow-none hover:shadow-none rounded-md bg-white"
      >
        <div className="flex flex-wrap justify-between items-center px-4 lg:px-6 py-4 lg:py-0 rounded-xl">
          <p className="text-lg font-semibold text-black">
            Select City or Location
          </p>
          <div className="flex items-center gap-3 mt-3">
            <button
              onClick={handleDetectLocation}
              className="py-1.5 px-2 border border-blue-200 bg-blue-50 shadow-none hover:shadow-none outline-none text-sm"
            >
              Detect My Location
            </button>
            <div
              onClick={handleOpen}
              className="cursor-pointer py-1.5 px-2 border border-blue-200 bg-blue-50 shadow-none hover:shadow-none outline-none"
            >
              <X color="black" />
            </div>
          </div>
        </div>

        <DialogBody className="max-h-[78vh] overflow-y-auto">
          <div className="flex flex-wrap gap-10 lg:gap-6 justify-center p-6 overflow-x-auto scrollbar-hide">
            {isCitiesLoading ? (
              <Spinner color="blue" />
            ) : (
              cities?.map((city) => (
                <CityCard
                  key={city.cityName}
                  {...city}
                  refetch={refetch}
                  onClose={() => setOpen(false)}
                />
              ))
            )}
          </div>
        </DialogBody>
      </Dialog>
    </>
  );
}
