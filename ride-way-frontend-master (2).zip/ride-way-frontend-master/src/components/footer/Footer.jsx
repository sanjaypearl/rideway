/* eslint-disable react/prop-types */
import { FiMapPin, FiMail, FiPhone, FiMessageCircle } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { useDispatch } from "react-redux";
import { Spinner } from "@material-tailwind/react";
import myContext from "../../context/myContext";
import { useGetCitiesQuery } from "../../redux/slices/cityApiSlice";
import { vehicleApi } from "../../redux/slices/vehicleApiSlice";

export default function Footer({ refetch }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    selectedCity,
    setSelectedCity,
    setVehicleCity,
    setLat,
    setLng,
    setCurrentLocationName,
  } = useContext(myContext);

  // Fetching dynamic city list
  const { data: cities = [], isLoading: isCitiesLoading } = useGetCitiesQuery();

  const handleCityChange = (city) => {
    setSelectedCity(city.cityName);
    setVehicleCity(city._id);
    setLat(null);
    setLng(null);
    setCurrentLocationName("");

    localStorage.setItem("selectedCity", city.cityName);
    localStorage.setItem("vehicleCity", city._id);
    localStorage.removeItem("lat");
    localStorage.removeItem("lng");
    localStorage.removeItem("currentLocationName");

    dispatch(vehicleApi.util.resetApiState());
    if (refetch) {
      refetch();
    }

    navigate("/");
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 0);
  };

  return (
    <footer className="relative text-gray-800 bg-white drop-shadow-md shadow-black">
      <div className="mx-auto w-full max-w-7xl px-6 py-12">
        {/* Logo */}
        <div className="flex justify-center pb-10">
          <img
            src="/logo/logo.png"
            alt="RideAway Rentals"
            className="h-20 w-auto"
          />
        </div>

        {/* Divider */}
        
        {/* columns */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* COMPANY */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              COMPANY
            </h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <a href="/about" className="hover:text-blue-600">
                  About Us
                </a>
              </li>
              <li>
                <a href="/blog" className="hover:text-blue-600">
                  Blogs
                </a>
              </li>
              <li>
                <a href="/faq" className="hover:text-blue-600">
                  FAQ’s
                </a>
              </li>
            </ul>
          </div>

          {/* SUPPORT */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              RIDEAWAY SUPPORT
            </h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <FiMail className="text-blue-600" />
                <a
                  href="mailto:contact@rideaway.in"
                  className="hover:text-blue-600"
                >
                  contact@rideaway.in
                </a>
              </li>
              <li className="flex items-center gap-2">
                <FiPhone className="text-blue-600" />
                <a href="tel:+91 9145103053" className="hover:text-blue-600">
                  +91 9145103053
                </a>
              </li>
              <li className="flex items-center gap-2">
                <FiMessageCircle className="text-blue-600" />
                <a
                  href="https://wa.me/9145103053" // Replace with your number in international format
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-blue-600"
                >
                  Chat With Us
                </a>
              </li>
            </ul>
          </div>

          {/* POLICIES */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              POLICIES
            </h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <a href="/privacy-policy" className="hover:text-blue-600">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms-and-condition" className="hover:text-blue-600">
                  Terms &amp; Conditions
                </a>
              </li>
            </ul>
          </div>

          {/* CONTACT US */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              CONTACT US
            </h4>
            <address className="not-italic text-sm text-gray-600">
              RideAway,
              <br />
              Shop No.2 , Shree Swami Krupa , Hingane Home Colony, Karve nagar,
              Pune, Maharashtra 411052
            </address>
            <a
              href="/contact"
              className="mt-4 inline-block text-blue-600 hover:text-blue-700 hover:underline"
            >
              Get In Touch
            </a>
          </div>
        </div>

        {/* divider */}
        <div className="my-10 h-px w-full bg-gray-300" />

        {/* CITIES */}
        <h4 className="mb-6 text-center text-lg font-semibold underline decoration-blue-600/60 underline-offset-4 text-gray-900">
          RIDEAWAY CITIES
        </h4>

        {isCitiesLoading ? (
          <div className="flex justify-center py-4">
            <Spinner color="blue" />
          </div>
        ) : (
          <ul className="grid grid-cols-2 md:grid-cols-5 md:place-items-center flex-wrap gap-y-3 text-sm text-gray-600">
            {cities?.map((city) => (
              <li key={city._id} className="flex items-center gap-1">
                <FiMapPin className="text-blue-600" />
                <button
                  onClick={() => handleCityChange(city)}
                  className={`hover:text-blue-600 hover:underline ${
                    selectedCity === city.cityName ? "font-bold text-blue-600" : ""
                  }`}
                >
                  Bike rent in <span>{city.cityName}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </footer>
  );
}
