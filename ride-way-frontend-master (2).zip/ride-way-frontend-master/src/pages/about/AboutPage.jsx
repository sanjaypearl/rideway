import { motion } from "framer-motion";
import { MdBikeScooter } from "react-icons/md";
import {  FaMotorcycle } from "react-icons/fa";

import Layout from "../../components/layout/Layout";

const fadeIn = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay },
});

export default function AboutPage() {
  return (
    <Layout>
      <motion.div
        className="max-w-5xl mx-auto px-6 py-12 space-y-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        {/* Hero Section */}
        <motion.section {...fadeIn(0.2)} className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">
            About <span className="text-blue-600">RideAway</span>
          </h1>
          <p className="text-gray-700 text-lg">
            RideAway is India’s premier vehicle-rental platform, connecting
            riders and owners with an easy-to-use, commission-based service
            model.
          </p>
        </motion.section>

        {/* Services Grid */}
        <motion.section {...fadeIn(0.4)}>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Our <span className="text-blue-600">Services</span>
          </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
  {[
    {
      icon: <FaMotorcycle className="h-12 w-12 text-blue-500" />,
      title: "Bike Rentals",
      desc: "Beat city traffic with our reliable and affordable bikes.",
    },
    {
      icon: <MdBikeScooter className="h-12 w-12 text-blue-500" />,
      title: "Scooter Rentals",
      desc: "Comfortable rides for daily commutes and quick errands.",
    },
  ].map((service, idx) => (
    <motion.div
      key={service.title}
      {...fadeIn(0.6 + idx * 0.2)}
      className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition"
    >
      {service.icon}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 mb-1">
          {service.title}
        </h3>
        <p className="text-gray-600">{service.desc}</p>
      </div>
    </motion.div>
  ))}
</div>
        </motion.section>

        {/* Mission & Why Choose Us */}
        <motion.section {...fadeIn(1)} className="space-y-8">
          <div className="flex flex-col md:flex-row md:space-x-10 space-y-6 md:space-y-0">
            <div className="flex-1 p-6 bg-white rounded-xl shadow-md">
              <h3 className="text-2xl font-semibold text-gray-800 mb-3">
                Our <span className="text-blue-600">Mission</span>
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Empowering travelers to explore India their way—be it a city
                adventure or a scenic road trip—while ensuring safety and
                reliability.
              </p>
            </div>
            <div className="flex-1 p-6 bg-white rounded-xl shadow-md">
              <h3 className="text-2xl font-semibold text-gray-800 mb-3">
                Why <span className="text-blue-600">Choose Us</span>
              </h3>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Extensive selection of bikes and scooters</li>
                <li>Competitive pricing with transparent fees</li>
                <li>Secure Razorpay payments</li>
                <li>Seamless booking experience</li>
                <li>Strict quality and safety standards</li>
              </ul>
            </div>
          </div>
        </motion.section>

        {/* How It Works */}
        <motion.section {...fadeIn(1.4)}>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            How It <span className="text-blue-600">Works</span>
          </h2>
          <ol className="space-y-4 text-gray-700 list-decimal list-inside">
            <li>Browse available vehicles on our website or mobile app.</li>
            <li>
              Select your dates, choose a bike or scooter, and book online.
            </li>
            <li>Pay securely via Razorpay in just a few clicks.</li>
            <li>Pick up your ride and enjoy your journey worry-free.</li>
          </ol>
        </motion.section>
      </motion.div>
    </Layout>
  );
}
