import React from "react";
import { Link } from "react-router-dom";
import FAQItem from "./FAQItem";

export default function FAQSection() {
  const customerFaqs = [
    {
      question: "How can I rent a two-wheeler online?",
      answer:
        "You can rent a two-wheeler by visiting our website and following the steps provided.",
    },
    {
      question: "What is the condition of the vehicles?",
      answer:
        "All vehicles are regularly maintained and serviced for your safety and comfort.",
    },
    {
      question: "Is home delivery possible for the vehicle?",
      answer:
        "No, we currently do not offer home delivery services. Please visit our location for pickup.",
    },
    {
      question: "What documents are required for renting a scooter/bike?",
      answer:
        "You need to provide a valid driving license and a government-issued ID proof.",
    },
  ];

  return (
    <div className="bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-6">
          Frequently Asked Questions
        </h2>

        {/* FAQ List */}
        <div className="bg-white rounded-2xl shadow-lg divide-y divide-gray-200 overflow-hidden mb-6">
          {customerFaqs.map((faq) => (
            <FAQItem
              key={faq.question}
              question={faq.question}
              answer={faq.answer}
            />
          ))}
        </div>

        {/* More FAQs Button */}
        <div className="text-center">
          <Link
            to="/faqs"
            className="inline-block px-6 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition"
          >
            More FAQs
          </Link>
        </div>
      </div>
    </div>
  );
}
