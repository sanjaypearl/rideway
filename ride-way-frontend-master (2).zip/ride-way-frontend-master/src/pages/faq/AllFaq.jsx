// src/pages/AllFAQs.jsx
import { useState } from "react";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Layout from "../../components/layout/Layout";
import FAQItem from "./FAQItem";

export default function AllFAQs() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate(); // <— for “Show More” redirect

  /* ------------ FAQ DATA ------------ */
  const faqs = [
    {
      question: "How can I rent a two‑wheeler online?",
      answer:
        "You can rent a two‑wheeler by visiting our website and following the steps provided.",
    },
    {
      question: "What is the condition of the vehicles?",
      answer:
        "All vehicles are regularly maintained and serviced for your safety and comfort.",
    },
    {
      question: "Is home delivery possible for the vehicle?",
      answer:
        "No, we currently do not offer home delivery services. Please visit our location for pickup.",
    },
    {
      question: "What documents are required for renting a scooter/bike?",
      answer:
        "You need to provide a valid driving license and a government‑issued ID proof.",
    },
    // …add more here
  ];

  const filtered = faqs.filter((f) =>
    f.question.toLowerCase().includes(query.toLowerCase())
  );

  /* ------------ JSX ------------ */
  return (
    <Layout>
      {/* ░░ Banner ░░──────────────────────────────────────────────────────── */}
      <div className="relative mx-auto max-w-7xl px-4">
        {/* gradient box */}
        <div
          className="relative rounded-[40px] overflow-hidden bg-gradient-to-r
                     from-blue-400 via-cyan-400 to-blue-400 py-16"
        >
          {/* decorative diagonal stripes */}
          <div
            className="pointer-events-none absolute inset-0 opacity-40"
            
          />

          <h1 className="relative z-10 text-center text-3xl sm:text-4xl font-bold text-white">
            Frequently Asked Questions
          </h1>

          {/* search bar */}
          <div className="relative z-10 max-w-xl mx-auto mt-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full py-4 pl-12 pr-4 rounded-lg bg-white/95
                         outline-none shadow-[0_8px_30px_rgba(0,201,255,0.35)]
                         focus:ring-4 focus:ring-sky-200/60 placeholder:text-gray-400"
            />
          </div>
        </div>
      </div>

      {/* ░░ FAQ card ░░─────────────────────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 mt-4 pb-20">
        {/* subtle background blob (decor) */}
        <div
          className="absolute left-0 top-[300px] -z-10 h-80 w-80 rounded-full 
                     bg-blue-50 blur-2xl opacity-60"
        />

        <div className="bg-white rounded-2xl shadow-lg divide-y divide-gray-200">
          {filtered.length ? (
            filtered.map((faq) => <FAQItem key={faq.question} {...faq} />)
          ) : (
            <p className="p-8 text-center text-gray-500">
              No FAQs found for &ldquo;{query}&rdquo;
            </p>
          )}
        </div>
      </div>
    </Layout>
  );
}
