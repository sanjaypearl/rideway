// src/components/FAQItem.jsx
import React, { useState } from 'react';
import { PlusCircle, MinusCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function FAQItem({ question, answer }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="faq-item">
      <button
        onClick={() => setIsOpen((o) => !o)}
        className="w-full px-6 py-4 flex justify-between items-center text-left text-lg font-medium text-gray-800 bg-white hover:bg-gray-50 focus:outline-none transition"
      >
        <span>{question}</span>
        {isOpen ? (
          <MinusCircle className="h-4 text-blue-500" />
        ) : (
          <PlusCircle className="h-4 text-blue-500" />
        )}
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            key="content"
            initial="collapsed"
            animate="open"
            exit="collapsed"
            variants={{
              open: { height: 'auto', opacity: 1 },
              collapsed: { height: 0, opacity: 0 },
            }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="overflow-hidden px-6"
          >
            <motion.p
              className="py-4 text-gray-600 border-t border-gray-200"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {answer}
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
