/* src/pages/policies/PrivacyPolicy.jsx */
import React from "react";
import Layout from "../../../components/layout/Layout";

const sections = [
  { id: "intro", title: "Introduction" },
  { id: "consent", title: "Consent" },
  { id: "info-collect", title: "1. Types of Information Collected" },
  {
    id: "collection-storage",
    title: "2. Collection and Storage of Information",
  },
  { id: "purpose", title: "3. Purpose for Collecting Information" },
  { id: "share-info", title: "4. Sharing and Disclosure of Your Information" },
  {
    id: "third-party",
    title: "5. Links to Other Websites and Third-Party Services",
  },
  { id: "children-privacy", title: "6. Children’s Privacy" },
  { id: "data-rights", title: "7. Data Protection Rights" },
  { id: "storage-transfer", title: "8. Storage and Transfer of Information" },
  { id: "cookies", title: "9. Cookies and Other Tracking Technologies" },
  { id: "retention", title: "10. Data Retention" },
  { id: "data-security", title: "11. Security Measures and Safeguards" },
  { id: "changes", title: "12. Updates to this Privacy Policy" },
  { id: "miscellaneous", title: "13. Miscellaneous" },
  { id: "grievance", title: "14. Grievance Officer" },
];

export default function PrivacyPolicy() {
  return (
    <Layout>
      <div className="bg-gray-100 py-12 px-4">
        <div className="max-w-7xl mx-auto lg:flex lg:space-x-8">
          {/* Sidebar */}
          <nav className="hidden lg:block lg:w-1/4 sticky top-24">
            <ul className="space-y-3">
              {sections.map((sec) => (
                <li key={sec.id}>
                  <a
                    href={`#${sec.id}`}
                    className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition"
                  >
                    {sec.title}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Content */}
          <article className="lg:w-3/4 bg-white rounded-xl shadow-lg overflow-hidden">
            <header className="px-8 py-6 border-b">
              <h1 className="text-4xl font-semibold text-gray-900">
                Privacy Policy
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                Last Updated: 4 Nov 2024
              </p>
            </header>
            <div className="px-8 py-10 space-y-12">
              {/* Introduction */}
              <section id="intro" className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  Introduction
                </h2>
                <p className="text-gray-700">
                  RIDEAWAY SOLUTIONS PRIVATE LIMITED (referred to as “Company,”
                  “we,” “us,” or “our”) is the owner of the website domain at{" "}
                  <a
                    href="https://rideaway.in/"
                    className="text-blue-600 hover:underline"
                  >
                    www.rideaway.in
                  </a>{" "}
                  and the mobile application “RideAway – Bike Rentals” available
                  on Google Play Store and Apple App Store (collectively
                  referred to as the “Platform”). Any service availed by Users
                  (hereinafter referred to as “you,” “your,” or “User”) through
                  the Platform is conditioned upon your acceptance of the terms
                  and conditions contained in the Terms of Service as available
                  on the Platform and this Privacy Policy (“Privacy Policy”).
                </p>
                <p className="text-gray-700 mt-4">
                  THIS PRIVACY POLICY IS AN ELECTRONIC RECORD IN THE FORM OF AN
                  ELECTRONIC CONTRACT FORMED UNDER THE INFORMATION TECHNOLOGY
                  ACT, 2000 AND THE RULES MADE THEREUNDER AND THE AMENDED
                  PROVISIONS PERTAINING TO ELECTRONIC DOCUMENTS / RECORDS IN
                  VARIOUS STATUTES AS AMENDED BY THE INFORMATION TECHNOLOGY ACT,
                  2000 OR ANY RELEVANT STATUTE OR REGULATION UNDER ANY
                  APPLICABLE JURISDICTION. THIS PRIVACY POLICY DOES NOT REQUIRE
                  ANY PHYSICAL, ELECTRONIC, OR DIGITAL SIGNATURE.
                </p>
                <p className="text-gray-700 mt-4">
                  The purpose of this Privacy Policy is to ensure that there is
                  an intact charter to collect, use, and protect any personal
                  and/or sensitive data collected by us. This Policy defines our
                  procedure for collection, usage, processing, disclosure, and
                  protection of any information obtained by us through the
                  Platform. Capitalized terms that are not defined in this
                  Privacy Policy shall have the same meaning as ascribed to them
                  in our Terms of Service. Any reference made to the Privacy
                  Policy in this document shall mean and refer to the latest
                  version of the Privacy Policy.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Consent */}
              <section id="consent" className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  Consent
                </h2>
                <p className="text-gray-700">
                  THIS PRIVACY POLICY IS A LEGALLY BINDING DOCUMENT BETWEEN YOU
                  AND THE COMPANY. THE TERMS OF THIS PRIVACY POLICY WILL BE
                  EFFECTIVE UPON YOUR ACCEPTANCE OF THE SAME OR BY YOUR USE OF
                  OUR SERVICES AND WILL GOVERN THE RELATIONSHIP BETWEEN THE
                  COMPANY AND YOU FOR YOUR USE OF THE PLATFORM AND OUR SERVICES.
                </p>
                <p className="text-gray-700 mt-4">
                  PLEASE READ THIS PRIVACY POLICY CAREFULLY AS IT AFFECTS YOUR
                  RIGHTS AND LIABILITIES UNDER LAW. BY USING THIS PLATFORM AND
                  AVAILING OUR SERVICES, YOU INDICATE THAT YOU UNDERSTAND,
                  AGREE, AND CONSENT TO THIS PRIVACY POLICY. IF YOU DO NOT AGREE
                  WITH THE TERMS OF THIS PRIVACY POLICY, PLEASE DO NOT USE THIS
                  WEBSITE OR AVAIL OUR SERVICES.
                </p>
                <p className="text-gray-700 mt-4">
                  Please be advised that any Information procured by us shall
                  be:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-3">
                  <li>
                    Processed fairly and lawfully for rendering the Services;
                  </li>
                  <li>Obtained only for specified and lawful purposes;</li>
                  <li>
                    Adequate, relevant, and not excessive in relation to the
                    purpose for which it is required;
                  </li>
                  <li>
                    Able to be reviewed by the User, from time to time, and
                    updated if need arises;
                  </li>
                  <li>
                    Not kept longer than for the time which it is required or
                    the purpose for which it is required or as required by the
                    applicable law.
                  </li>
                </ul>
                <p className="text-gray-700 mt-4">
                  If you do not agree with this Privacy Policy, you may refuse
                  or withdraw your consent at any time, or alternatively choose
                  to not provide us with any Personal Information. You
                  understand that under such circumstances, we may be unable to
                  render Services. Any such intimation to withdraw your consent
                  can be sent to{" "}
                  <a
                    href="mailto:support@rideaway.in"
                    className="text-blue-600 hover:underline"
                  >
                    support@rideaway.in
                  </a>
                  .
                </p>
                <p className="text-gray-700 mt-4">
                  WE SHALL NOT BE LIABLE FOR ANY LOSS OR DAMAGE SUSTAINED BY
                  REASON OF ANY DISCLOSURE (INADVERTENT OR OTHERWISE) OF ANY
                  DATA, IF THE SAME IS EITHER (A) REQUIRED FOR SHARING YOUR
                  INFORMATION FOR LEGITIMATE PURPOSES; OR (B) WAS CAUSED THROUGH
                  NO FAULT, ACT, OR OMISSION OF THE COMPANY.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 1 */}
              <section
                id="info-collect"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  1. Types of Information Collected
                </h2>
                <ul className="list-disc list-inside text-gray-700 space-y-3">
                  <li>
                    <strong>Personal Data:</strong> Means and includes any
                    Information that relates to a natural person through which
                    an individual is identified, such as the name, contact
                    details, email address, gender, age, organization name,
                    organization email ID, demographic information such as
                    address and pin code, any photo identity, or any other
                    information relevant to product choice and preferences
                    provided by a User, including but not limited to information
                    gathered through availing Services.
                  </li>
                  <li>
                    <strong>Sensitive Personal Data:</strong> Means and includes
                    information relating to: (i) government ID cards; (ii)
                    financial information such as bank account or credit card or
                    debit card or other payment instrument details; and (iii)
                    any detail relating to the above-mentioned points as
                    provided to us for using the Platform.
                  </li>
                  <li>
                    <strong>Technical Information:</strong> Means and includes
                    any Information gathered through various technologies that
                    may employ cookies, web beacons, or similar technologies to
                    automatically record certain information from your device
                    through which you use the Platform. This technical
                    information may include your Internet Protocol (IP) address,
                    device or browser type, Internet service provider (ISP),
                    referring or exit pages, clickstream data, operating system,
                    hardware model, operating system version, unique device
                    identifiers, camera data, and mobile network. This data
                    includes usage information and user statistics.
                  </li>
                  <li>
                    <strong>Locational Information:</strong> Shall mean and
                    include the information obtained through GPS or other means,
                    such as the geographical location of the User, locational
                    data, and user tracking.
                  </li>
                  <li>
                    <strong>Social Media Data:</strong> If you access the
                    Platform through a third-party platform such as a social
                    media service or connect Our Services to a third-party
                    platform, the Information we collect may include your
                    username associated with that third-party platform, any
                    information or content the third-party platform has the
                    right to share with us, such as your profile picture, email
                    address, or friends list, and any information you have made
                    public in connection with the respective third-party
                    platform.
                  </li>
                  <li>
                    <strong>Non-Personal Information:</strong> Means and
                    includes any information that does not reveal your specific
                    identity, such as browser information, information collected
                    through cookies, pixel tags, and other technologies,
                    demographic information, etc. This information is generally
                    collected in aggregate form, without identifying any User
                    individually.
                  </li>
                </ul>
              </section>

              <hr className="border-gray-200" />

              {/* Section 2 */}
              <section
                id="collection-storage"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  2. Collection and Storage of Information
                </h2>
                <p className="text-gray-700">
                  Information may be collected in various ways, including during
                  the course of you registering as a User on the Platform or
                  availing certain Services offered on the Platform:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-3">
                  <li>
                    <strong>Directly from You:</strong> For example, from the
                    forms you complete on our Service, preferences you express
                    or provide through our Service, or from your purchases on
                    our Service.
                  </li>
                  <li>
                    <strong>Indirectly from You:</strong> For example, from
                    observing your activity on our Service.
                  </li>
                  <li>
                    <strong>Automatically from You:</strong> For example,
                    through cookies we or our service providers set on your
                    Device as you navigate through our Service.
                  </li>
                  <li>
                    <strong>From Service Providers:</strong> For example, we may
                    receive Information about you from third-party platforms,
                    such as social media platforms, marketing and advertising
                    firms, commercially available sources, and business partners
                    to whom you have consented disclosure of such Information.
                  </li>
                </ul>
                <p className="text-gray-700 mt-4">
                  Please note that each category of Information may be treated
                  differently as per this Privacy Policy.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 3 */}
              <section id="purpose" className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  3. Purpose for Collecting Information
                </h2>
                <p className="text-gray-700">
                  The Company collects, uses, stores, and processes your
                  Information for any purpose as may be permissible under
                  applicable laws (including where the applicable law provides
                  for such collection, usage, storage, or processes in
                  accordance with the consent of the User) and shall include the
                  following:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-3">
                  <li>
                    To render services and facilitate your use of the Platform;
                  </li>
                  <li>
                    To respond to your inquiries or fulfill your requests for
                    information about the various Services offered on the
                    Platform;
                  </li>
                  <li>
                    To provide you with information about Services available on
                    the Platform and to send you information, materials, and
                    offers;
                  </li>
                  <li>
                    To send you important information regarding the Platform,
                    changes in terms and conditions, user agreements, and
                    policies, and/or other administrative information;
                  </li>
                  <li>To send you surveys and marketing communications;</li>
                  <li>To improve user experience;</li>
                  <li>
                    To help you address your problems incurred on the Platform,
                    including capturing error logs and technical data for
                    addressing technical issues;
                  </li>
                  <li>
                    To protect the integrity and for proper administering of the
                    Platform;
                  </li>
                  <li>
                    To conduct academic research, surveys, analytical studies on
                    various aspects including user behavior, user preferences,
                    etc.;
                  </li>
                  <li>
                    To respond to legal, judicial, quasi-judicial process and
                    provide information to law enforcement agencies or in
                    connection with an investigation on matters related to
                    public safety, as permitted by law;
                  </li>
                  <li>To implement information security practices;</li>
                  <li>
                    To determine any security breaches, computer contaminant, or
                    computer virus;
                  </li>
                  <li>
                    To investigate, prevent, or take action regarding illegal
                    activities and suspected fraud;
                  </li>
                  <li>
                    To enable a potential buyer or investor to evaluate the
                    business of the Company;
                  </li>
                  <li>
                    <strong>Business or Research Purposes:</strong> The
                    Information saved, except Sensitive Personal Information, is
                    used for business or research purposes, including improving
                    and customizing the Platform for ease of use and the
                    products and services offered by us. We may archive this
                    information to use it for future communications for
                    providing updates and/or surveys.
                  </li>
                  <li>
                    <strong>Aggregating Information / Anonymized Data:</strong>{" "}
                    We may aggregate Information and analyze it in a manner to
                    further accentuate the level of services that we offer to
                    our customers. This Information includes the average number
                    of Users of the Platform, the average clicks of the
                    services, the features used, the response rate, etc., and
                    other such statistics regarding groups or individuals. In
                    doing so, we shall not be making disclosures of any
                    Sensitive Personal Information.
                  </li>
                </ul>
              </section>

              <hr className="border-gray-200" />

              {/* Section 4 */}
              <section
                id="share-info"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  4. Sharing and Disclosure of Your Information
                </h2>
                <p className="text-gray-700 mb-4">
                  We do not rent, sell, or disclose or share any Information
                  that we collect from you with third parties, save and except
                  in order to provide you with the Services. Any such
                  disclosure, if made, shall be in accordance with this Privacy
                  Policy and as per the procedure prescribed by law and in
                  compliance with our legal obligations. We may share your
                  Information in circumstances and for the purposes as specified
                  hereunder:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-3">
                  <li>
                    <strong>With Vehicle Owners:</strong> For verification and
                    fulfillment of bookings.
                  </li>
                  <li>
                    <strong>Service Providers:</strong> We shall share the
                    information to the third-party service providers/vendors, to
                    provide you with the Services.
                  </li>
                  <li>
                    <strong>Legal Requirements:</strong> We may disclose any
                    Information provided by you on the Platform as may be deemed
                    to be necessary or appropriate:
                    <ul className="list-circle list-inside ml-6 space-y-2 mt-2">
                      <li>
                        Under applicable law, including laws outside your
                        country of residence;
                      </li>
                      <li>To comply with legal process;</li>
                      <li>
                        To respond to requests from public and government
                        authorities, including public and government authorities
                        outside your country of residence;
                      </li>
                      <li>
                        To protect our operations or those of any of our
                        affiliates;
                      </li>
                      <li>
                        To protect our rights, privacy, safety, or property, and
                        that of our affiliates, you, or others;
                      </li>
                      <li>
                        To allow us to pursue available remedies or limit the
                        damages that we may sustain;
                      </li>
                      <li>To protect against legal liability;</li>
                      <li>
                        To protect the personal safety of Users of the Platform;
                      </li>
                      <li>
                        To prevent or investigate possible wrongdoing in
                        connection with the Platform.
                      </li>
                    </ul>
                  </li>
                  <li>
                    <strong>Merger or Acquisition:</strong> We may share
                    Information upon merger or acquisition of the Company with
                    another company. We shall transmit and transfer the
                    Information upon acquisition or merger of the Company with
                    another company.
                  </li>
                  <li>
                    <strong>With Our Service Providers:</strong> We may share
                    Information with other service providers on a need-to-know
                    basis, subject to obligations of confidentiality for
                    provision of Services. We work with institutions, vendors,
                    partners, advertisers, and other service providers,
                    including (but not limited to) those who provide products or
                    services such as contact Information verification, website
                    hosting, data analysis, providing infrastructure,
                    information technology services, auditing services, and
                    other similar services, in different industries and
                    categories of business by virtue of lawful contracts
                    instituted between such third parties and the Company to
                    improve our product and services.
                  </li>
                  <li>
                    <strong>Employees/Agents of Company:</strong> We follow a
                    strict confidentiality policy with regard to disclosure of
                    confidential information to our employees or other
                    personnel. There may be situations where we may disclose the
                    confidential information only to those of our employees and
                    other personnel on a need-to-know basis. Any breach of
                    confidential information by the employees or personnel
                    within the Company is dealt with stringently by us.
                  </li>
                </ul>
                <p className="text-gray-700 mt-4">
                  Except for the Information disclosed pursuant to this section,
                  the Company may share Information only if you authorize us to
                  do so.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 5 */}
              <section
                id="third-party"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  5. Links to Other Websites and Third-Party Services
                </h2>
                <p className="text-gray-700">
                  Our Platform may provide links to other sites. These links are
                  provided for your convenience only, and the provision of these
                  links does not mean that sites are related or associated with
                  us. Please note that these sites have their own terms of use
                  and privacy policy. You should check their privacy policy
                  before you submit your Personal Information or any other data
                  with them. We don’t guarantee the content and the security of
                  those sites.
                </p>
                <p className="text-gray-700 mt-4">
                  We may have certain features on our Platform which may be
                  hosted by third parties; your interaction with such features
                  shall be governed by the privacy policy of such third parties.
                  We shall not be responsible for any loss, damage, claim, or
                  expense caused as a result of you accessing these third-party
                  sites and features.
                </p>
                <p className="text-gray-700 mt-4">
                  We may use your Information to send you promotional
                  Information about third parties which we think you may find
                  interesting if you tell us that you wish this to happen. We
                  shall not be responsible for any disclosure of Information due
                  to unauthorized third-party access or other acts of third
                  parties or acts or omissions beyond our reasonable control,
                  and you agree that you will not hold us responsible for any
                  breach of security unless such breach has been caused as a
                  direct result of our negligence or willful default.
                </p>
                <p className="text-gray-700 mt-4">
                  We use support services of third-party platforms and/or
                  companies to direct you to payment gateways when you opt to
                  pay for our Services. Your financial information is collected,
                  stored, and retained by such third-party platforms. We and
                  such designated third-party platforms undertake measures
                  designed to provide a security level that is appropriate to
                  the risks of processing your personal information. However,
                  you are requested to check and consent to the “Privacy Policy”
                  of such third-party platforms in order to accept how such
                  third-party platforms handle your Information.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 6 */}
              <section
                id="children-privacy"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  6. Children’s Privacy
                </h2>
                <p className="text-gray-700">
                  Our Services are not meant to be used by Children (as defined
                  by applicable privacy laws for a particular jurisdiction). We
                  do not knowingly collect Personal Information relating to
                  children, and if you think that your child has provided this
                  kind of information on our Platform, we strongly encourage you
                  to contact us immediately, and we will take reasonable steps
                  to promptly remove or destroy such information.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 7 */}
              <section
                id="data-rights"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  7. Data Protection Rights
                </h2>
                <p className="text-gray-700">
                  You have certain rights available to you when it comes to your
                  Personal Information. Subject to any exemptions provided by
                  the applicable laws, you have the following rights:
                </p>
                <ul className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>
                    <strong>
                      Rectifying, correcting, updating, and removing Your
                      information:
                    </strong>{" "}
                    You can access, edit, modify, and/or update your Personal
                    Information by logging into your user profile, or you can
                    write to us via email in case you wish to exercise this
                    right.
                  </li>
                  <li>
                    <strong>
                      Accessing and updating or deleting Your information:
                    </strong>{" "}
                    Our Services and related documentation on our Platform
                    provide you with the ability to access, update, and delete
                    certain Personal Information from your Account, if any. We
                    will provide you with information about whether we hold any
                    of your Personal Information upon request. We will respond
                    to such requests within a reasonable timeframe. Please note,
                    however, that we may need to retain certain information for
                    record-keeping purposes, to complete our Services and
                    related obligations to you, or to comply with our legal
                    obligations.
                  </li>
                  <li>
                    <strong>
                      Object or restrict processing of Your information:
                    </strong>{" "}
                    You have the right to: (i) object to our processing of your
                    Personal Information; and/or (ii) request that we restrict
                    the processing of your Personal Information.
                  </li>
                  <li>
                    <strong>Portability:</strong> You shall have the right to
                    request us to transfer Your Personal Information to another
                    controller, or directly to you, in a structured, commonly
                    used, and machine-readable format.
                  </li>
                </ul>
                <p className="text-gray-700 mt-4">
                  In order to exercise these rights, please contact us at{" "}
                  <a
                    href="mailto:support@rideaway.in"
                    className="text-blue-600 hover:underline"
                  >
                    support@rideaway.in
                  </a>
                  .
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 8 */}
              <section
                id="storage-transfer"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  8. Storage and Transfer of Information
                </h2>
                <p className="text-gray-700">
                  Your Information will primarily be stored in electronic form;
                  provided, however, that certain data can also be stored in
                  physical form. We may store, collect, process, and use your
                  data in countries other than the Republic of India but under
                  compliance with applicable laws. We may enter into agreements
                  with third parties (in or outside of India) to store or
                  process your information or data. These third parties may have
                  their own security standards to safeguard your information or
                  data, and we will, on a commercially reasonable basis, require
                  such third parties to adopt reasonable security standards to
                  safeguard your information/data.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 9 */}
              <section id="cookies" className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  9. Cookies and Other Tracking Technologies
                </h2>
                <p className="text-gray-700">
                  Our Platform may utilize “cookies” and other Technical
                  Information. “Cookies” are small text files consisting of
                  alphanumeric numbers used to collect Information about
                  Platform activity. The Technical Information helps us analyze
                  web traffic and helps you by customizing the Platform to your
                  preferences. Cookies in no way give us access to your computer
                  or mobile device. In relation to Cookies, you can deny access
                  to the installation of the Cookies by modifying the settings
                  on your web browser; however, this may prevent you from taking
                  full advantage of the Platform.
                </p>
                <p className="text-gray-700 mt-4">
                  Our use of Cookies and Technical Information allows us to
                  improve the Platform and your experience of the Platform and
                  Services. We may also analyze Technical Information that does
                  not contain Sensitive Personal Information for trends and
                  statistics.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 10 */}
              <section
                id="retention"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  10. Data Retention
                </h2>
                <p className="text-gray-700">
                  We will retain your Information for as long as your Account is
                  active or as needed to provide our Services. We shall retain
                  and use the Information collected by us as necessary to comply
                  with our legal obligations, resolve disputes, or for other
                  Legitimate Purposes. If you cancel/deactivate/unsubscribe your
                  account with us, we are not under any obligation to retain
                  your Information. However, we may retain the Information
                  pertaining to the User for the maximum period permitted under
                  the law of the land from the date of deactivation of the
                  User’s Account.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 11 */}
              <section
                id="data-security"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  11. Security Measures and Safeguards
                </h2>
                <p className="text-gray-700">
                  You agree and accept that your Information may be stored in
                  third-party cloud service infrastructure providers. While all
                  reasonable attempts have been taken from our end to ensure the
                  safe and secure storage of your data, we shall not be liable
                  for any data breach on the part of the third-party cloud
                  service infrastructure provider that was beyond our control.
                  In addition to the security measures put in place by the
                  third-party cloud service infrastructure provider for safe and
                  secure storage of your Information, we use certain physical,
                  managerial, technical, or operational safeguards as per
                  industry standards and established best practices to protect
                  the Information we collect. We use reasonable security
                  practices and procedures and use secure servers as mandated
                  under applicable laws for the protection of your Information.
                  We review our Information collection, storage, and processing
                  practices, including physical security measures, to guard
                  against unauthorized access to systems.
                </p>
                <p className="text-gray-700 mt-4">
                  However, as effective as these measures are, no security
                  system is impenetrable. We cannot guarantee the security of
                  our database, nor can we guarantee that the Information you
                  supply will not be intercepted while being transmitted to us
                  over the internet. However, since the internet is not a 100%
                  secure environment, we, on a best-effort basis, ensure the
                  security of any information the User transmits to us and that
                  the information may not be accessed, disclosed, altered, or
                  destroyed by breach of any of our physical, technical, or
                  managerial safeguards. Please note that emails and other
                  communications the User sends to us through our Platform are
                  not encrypted, and we strongly advise the User not to
                  communicate any confidential information through these means.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 12 */}
              <section id="changes" className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  12. Updates to this Privacy Policy
                </h2>
                <p className="text-gray-700">
                  We may change the data privacy practices and update this
                  Privacy Policy as and when the need arises, and the same will
                  be made available on the Platform. But our commitment to
                  protect your privacy will continue to remain. We suggest that
                  you regularly check this Privacy Policy to apprise yourself of
                  any updates. Your continued use of the Platform and Services
                  or provision of Information thereafter will imply your
                  unconditional acceptance of such updates to this Privacy
                  Policy. Further, we retain the right at any time to deny or
                  suspend access to all, or any part of, the service to anyone
                  who we reasonably believe has violated any provision of this
                  Privacy Policy.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 13 */}
              <section
                id="miscellaneous"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  13. Miscellaneous
                </h2>
                <p className="text-gray-700">
                  THIS PRIVACY POLICY DOES NOT APPLY TO ANY INFORMATION OTHER
                  THAN THE INFORMATION COLLECTED BY US THROUGH THE PLATFORM.
                  THIS PRIVACY POLICY SHALL BE INAPPLICABLE TO ANY UNSOLICITED
                  INFORMATION YOU PROVIDE US THROUGH THE PLATFORM OR THROUGH ANY
                  OTHER MEANS. ALL UNSOLICITED INFORMATION SHALL BE DEEMED TO BE
                  NON-CONFIDENTIAL, AND WE SHALL BE FREE TO USE AND/OR DISCLOSE
                  SUCH UNSOLICITED INFORMATION WITHOUT ANY LIMITATIONS. THE
                  RIGHTS AND REMEDIES AVAILABLE UNDER THIS POLICY MAY BE
                  EXERCISED AS OFTEN AS NECESSARY AND ARE CUMULATIVE AND NOT
                  EXCLUSIVE OF RIGHTS OR REMEDIES PROVIDED BY LAW. RIGHTS UNDER
                  THIS POLICY MAY BE WAIVED ONLY IN WRITING. DELAY IN EXERCISING
                  OR NON-EXERCISE OF ANY SUCH RIGHT OR REMEDY DOES NOT
                  CONSTITUTE A WAIVER OF THAT RIGHT OR REMEDY, OR ANY OTHER
                  RIGHT OR REMEDY.
                </p>
              </section>

              <hr className="border-gray-200" />

              {/* Section 14 */}
              <section
                id="grievance"
                className="border-l-4 border-blue-500 pl-6"
              >
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                  14. Grievance Officer
                </h2>
                <p className="text-gray-700">
                  In furtherance of the Information Technology Act, 2000 (“IT
                  Act”) and the Information Technology (Intermediary Guidelines
                  and Digital Media Ethics Code) Rules, 2021 (“Intermediary
                  Guidelines”), a grievance officer is appointed to ensure
                  compliance with the IT Act and the Intermediary Guidelines.
                </p>
                <p className="text-gray-700 mt-4">
                  <strong>Name:</strong> Mr. Dipesh Lokare
                  <br />
                  <strong>Address:</strong> Sant Tukaram Chowk, Old RTO Office,
                  Road, Akola-444004, Maharashtra, India
                  <br />
                  <strong>Phone:</strong> +919145103053
                  <br />
                  <strong>Email:</strong>{" "}
                  <a
                    href="mailto:support@rideaway.in"
                    className="text-blue-600 hover:underline"
                  >
                    support@rideaway.in
                  </a>
                </p>
                <p className="text-gray-700 mt-4">
                  The grievance officer shall revert to every complaint within
                  24 hours of receipt of the complaint. Further, the Company
                  shall take best possible efforts to redress the complaint
                  within 15 days of receipt of the complaint. Any suggestions by
                  the Company regarding the use of the Services shall not be
                  construed as a warranty.
                </p>
                <p className="text-gray-700 mt-4">
                  Please feel free to reach out to us by email at{" "}
                  <a
                    href="mailto:support@rideaway.in"
                    className="text-blue-600 hover:underline"
                  >
                    support@rideaway.in
                  </a>{" "}
                  in case of any concerns, grievances, or questions relating to
                  our privacy or data-related practices.
                </p>
              </section>
            </div>
          </article>
        </div>
      </div>
    </Layout>
  );
}
