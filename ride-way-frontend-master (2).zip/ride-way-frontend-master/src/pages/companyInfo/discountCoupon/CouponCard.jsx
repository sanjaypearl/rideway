// src/pages/CouponCard.jsx
import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { ClipboardDocumentIcon } from '@heroicons/react/24/outline';
import myContext from '../../../context/myContext';

const CouponCard = ({ image, title, description, discountCode, expiryDate }) => {
  const { showAlert } = useContext(myContext);

  const handleRedeem = () => {
    navigator.clipboard.writeText(discountCode)
      .then(() => showAlert('Coupon code copied!', 'success', 1500))
      .catch(() => showAlert('Copy failed.', 'error'));
  };

  return (
    <motion.div
      className="max-w-xs bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200"
      whileHover={{ scale: 1.03, boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <div className="h-48 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
        <p className="text-gray-600 text-sm">{description}</p>
        <div className="flex items-center justify-between">
          <span className="inline-block bg-blue-100 text-blue-800 font-medium px-3 py-1 rounded-full text-sm">
            {discountCode}
          </span>
          <button
            onClick={handleRedeem}
            className="flex items-center space-x-1 text-blue-500 hover:text-blue-600"
          >
            <ClipboardDocumentIcon className="w-5 h-5" />
            <span className="text-sm font-medium">Copy</span>
          </button>
        </div>
        <p className="text-gray-400 text-xs text-right">{expiryDate}</p>
      </div>
    </motion.div>
  );
};

export default CouponCard;
