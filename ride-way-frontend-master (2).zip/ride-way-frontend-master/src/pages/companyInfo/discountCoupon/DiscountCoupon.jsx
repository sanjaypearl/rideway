// src/pages/DiscountCoupon.jsx
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import Layout from '../../../components/layout/Layout';
import { useGetCouponsQuery } from '../../../redux/slices/couponApi';
import { ClipboardDocumentIcon } from '@heroicons/react/24/outline';

export default function DiscountCoupon() {
  const { data: coupons = [], isLoading, isError } = useGetCouponsQuery();

  const handleCopy = (code) => {
    navigator.clipboard.writeText(code)
      .then(() => toast.success('Code copied to clipboard!'))
      .catch(() => toast.error('Failed to copy code.'));
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <motion.div
            className="text-2xl text-gray-500"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            Loading Coupons…
          </motion.div>
        </div>
      </Layout>
    );
  }

  if (isError) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-red-600 text-xl">Failed to load coupons.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 py-6 px-6">
        <motion.h1
          className="text-center text-5xl font-extrabold text-gray-800 mb-16 bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-600"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          Exclusive Discount Coupons
        </motion.h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12">
          {coupons.map((c, idx) => (
            <motion.div
              key={c._id}
              className="relative bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-200"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: idx * 0.15, duration: 0.6 }}
              whileHover={{ scale: 1.05, rotate: 1 }}
              whileTap={{ scale: 0.95, rotate: -1 }}
            >
              {/* Accent gradient bar */}
              <div className="h-2 bg-gradient-to-r from-blue-400 to-blue-500" />

              <div className="p-8 flex flex-col h-full">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">{c.code}</h2>
                <p className="flex-1 text-gray-600 mb-6">
                  {c.discountValue}
                  {c.discountType === 'percentage' ? '%' : ''} off on all rides
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  Expires:{' '}
                  <time dateTime={c.expirationDate}>
                    {new Date(c.expirationDate).toLocaleDateString(undefined, {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </time>
                </p>
                <motion.button
                  onClick={() => handleCopy(c.code)}
                  className="mt-auto inline-flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-500 to-blue-500 hover:from-blue-600 hover:to-blue-600 text-white font-semibold py-3 rounded-full shadow-lg focus:outline-none"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <ClipboardDocumentIcon className="w-6 h-6" />
                  <span className="text-lg">Copy Code</span>
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
