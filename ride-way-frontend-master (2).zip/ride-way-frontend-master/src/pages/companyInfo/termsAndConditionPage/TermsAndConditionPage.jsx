/* src/pages/TermsAndConditionPage.jsx */
import React from "react";
import Layout from "../../../components/layout/Layout";

const TermsAndConditionPage = () => {
  return (
    <Layout>

    <div class="container mx-auto max-w-4xl bg1½ bg-white p-8 shadow-lg rounded-lg">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Terms & Conditions</h1>
        <p class="text-gray-600 mb-4">
            THESE TERMS OF SERVICES IS AN ELECTRONIC RECORD IN THE FORM OF AN ELECTRONIC CONTRACT FORMED UNDER APPLICABLE LAWS THE AMENDED PROVISIONS PERTAINING TO ELECTRONIC DOCUMENTS / RECORDS IN VARIOUS STATUTES. THESE TERMS OF SERVICES DOES NOT REQUIRE ANY PHYSICAL, ELECTRONIC OR DIGITAL SIGNATURE.
        </p>
        <p class="text-gray-600 mb-4">
            <strong>PLEASE READ THESE TERMS OF SERVICES CAREFULLY.</strong> BY USING THE PLATFORM, YOU INDICATE THAT YOU UNDERSTAND, AGREE AND CONSENT TO THESE TERMS OF SERVICES. IF YOU DO NOT AGREE WITH THE TERMS OF THESE TERMS OF SERVICES, PLEASE DO NOT USE THE PLATFORM OR SERVICES.
        </p>
        <p class="text-gray-600 mb-4">
            These Terms of Service ("Terms") of the website located at the URL <a href="https://www.rideaway.in/" class="text-blue-600 hover:underline">https://www.rideaway.in/</a>, on mobile sites or mobile application and the other associated/ancillary applications, products, websites and services and all other variations of the same and as mobile applications available on the Google Play Store/Apple App Store as “RideAway Rentals” (collectively referred to as “Platform”) is between RIDEAWAY SOLUTIONS PRIVATE LIMITED (referred as “Company” or “we” or “us” or “our"), a company incorporated under the Companies Act, 2013 with its registered office situated at SANT TUKARAM CHOWK, RTO OFIC RD NR ADCC BANK, Gandhinagar (Akola), Akola, Akola- 444004, Maharashtra, and the registered Users, defined to include any person who registers himself/herself/itself on the Platform and holds an Account on the Platform (referred as "you" or "your" or “User”) describe the terms on which Company offers Services.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">1. General Terms</h2>
        <p class="text-gray-600 mb-4">
            These Terms are a contract between you and Company. These Terms of Services shall be read together with the Privacy Policy available at <a href="https://www.rideaway.in/privacy-policy" class="text-blue-600 hover:underline">https://www.rideaway.in/privacy-policy</a> or other terms and condition with all other notices, disclaimers, guidelines appearing on the Platform from time to time (collectively referred to as "Terms and Conditions") constitute the entire agreement upon which you are allowed to access and use the Platform and avail the Services. By accessing this Platform, you are agreeing to be bound by these Terms and Conditions, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. Your continued use of the Platform shall constitute your acceptance to the Terms and Conditions, as revised from time to time.
        </p>
        <p class="text-gray-600 mb-4">
            For sake of clarification:
        </p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>You and Company shall hereinafter be individually referred to as a “Party” and collectively as the “Parties”;</li>
            <li>the term “Person” shall mean any natural person, firm, company, governmental authority, joint venture, association, partnership, limited liability partnership, society or other entity (whether or not having separate legal personality); and</li>
            <li>In the event that the User is not a natural person, it shall be the User's explicit responsibility and liability to ensure that its authorized riders, representatives, or agents comply with these Terms and Conditions. The User shall be held entirely liable for any and all actions, omissions, or conduct of its authorized riders, representatives, or agents in connection with these Terms and Conditions.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">2. Click to Accept</h2>
        <p class="text-gray-600 mb-4">
            Before using certain areas of the Platform, you may be asked to indicate your acceptance of additional special terms and conditions by clicking a button marked “I Accept” “I Agree” “Okay” “I Consent” or other words or actions that similarly acknowledge your consent or acceptance of a Click-Through Terms and Conditions. Any consent so provided by you will be deemed to be valid consent under all applicable laws.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">3. Updation of Terms and Conditions</h2>
        <p class="text-gray-600 mb-4">
            Your use of the Platform is subject to the Terms and Conditions, which may be updated, amended, modified, or revised by us from time to time. To ensure that you are aware of any additions, revisions, amendments, or modifications that we may have made to these Terms and Conditions, it is important for you to refer to the Terms and Conditions from time to time. The updated Terms and Conditions shall be effective immediately and shall supersede these. We shall not be under an obligation to notify you of any changes to the Terms and Conditions. You shall be solely responsible for reviewing the Terms and Conditions from time to time for any modifications. If you continue to use the Platform and/or Services after the updated Terms and Conditions have been published, it shall be deemed that you have read and understood and accept the updated Terms and Conditions. Any reference to Terms of Service herein shall refer to the latest version of the Terms of Service.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">4. Platform Services</h2>
        <p class="text-gray-600 mb-4">
            These Terms and Conditions governs your access to the Platform and such other services which include but are not limited to the rental booking, subscription, and use of various two-wheeled vehicles, such as motorcycles, scooters and similar modes of transportation, along with associated features, content, and functionality provided by our Platform ("Services").
        </p>
        <p class="text-gray-600 mb-4">
            Company reserves the right to update the Platform and /or Services, in order to, inter alia, introduce new features or Services, enhance existing features or Services, improve user experience and performance. You hereby agree that Company will be able to provide support services only if you install all the updates upon receiving notifications while using the Platform and its Services.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">5. Eligibility and Account Registration</h2>
        <p class="text-gray-600 mb-4">
            By using the Platform, you affirm that you are at least 18 years of age and are fully able and competent to accept the Terms and Conditions and the obligations, affirmations, representations, warranties set forth in the Terms and Conditions, and to abide by and comply with the terms stated therein. Registration of User in the Platform is available only to persons who can form legally binding contracts. Persons who are "incompetent to contract" within the meaning of the applicable law including minors, un-discharged insolvents, or person with unsound mind etc. are not eligible to use the Platform.
        </p>
        <p class="text-gray-600 mb-4">
            You must register an account on the Platform (an “Account”). When you register on the Platform and set up your Account, you must: (i) provide accurate and complete information; (ii) promptly update your Account information with any new information that may affect the operation of your Account; (iii) authorize Company to make any inquiries we consider necessary or appropriate to verify your Account information or the information you provide to us via the Platform including document proofs or copies or any such information as required mandatorily by applicable law that need to be provided to us; and (iv) acknowledge and accept any applicable policies, including but not limited to those pertaining to service quality, confidentiality, User integrity, anti-harassment and conflict of interest. You will not use false identities or impersonate any other person or use another account that you are not authorized to use on any computer, mobile phone, tablet, or other device (collectively “Device”).
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Documents required for using the Services:</h3>
        <p class="text-gray-600 mb-2"><strong>For Domestic Users:</strong> The following documents will be needed to rent or subscribe to a vehicle and same needs to be uploaded and verified on our Platform:</p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Driving License:</strong> Original Indian Driving license is required and a learner license is not applicable.</li>
            <li><strong>Aadhaar Card:</strong> Original Aadhaar is required, and if your mobile number indicated in Aadhaar is not as your registered number then upload an additional document (Passport). Passport will also be considered as a valid ID and address proof instead of Aadhaar.</li>
        </ul>
        <p class="text-gray-600 mb-2"><strong>For International Users:</strong> The following documents will be needed to rent or subscribe to a vehicle and same needs to be uploaded and verified on our Platform:</p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Driving License:</strong> A valid driving license from their home country along with an international driving permit is necessary.</li>
            <li><strong>Valid visa and Passport.</strong></li>
        </ul>
        <p class="text-gray-600 mb-4">
            Additionally, the User should carry their original documents at the time of the pickup which were uploaded on the Platform for verification.
        </p>
        <p class="text-gray-600 mb-4">
            You are responsible for safeguarding and maintaining the confidentiality of your Account information. You agree not to disclose your Account information to any third party and that you are entirely and solely responsible for any and all activities or actions that occur pursuant to the use of your Account on the Platform, whether or not you have authorized such activities or actions. You will immediately notify the Company of any unauthorized use of your Account. You may be held liable for losses incurred by Company due to authorized or unauthorized use of your Account as a result of your failure in keeping your Account Information secure and confidential.
        </p>
        <p class="text-gray-600 mb-4">
            If you provide any information that is untrue, inaccurate, not current or incomplete (or becomes untrue, inaccurate, not current or incomplete), or Company has reasonable grounds to suspect that such information is untrue, inaccurate, not current or incomplete, Company has the right to suspend or terminate your Account and refuse any and all current or future use of the Platform / Services (or any portion thereof).
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">6. Platform License</h2>
        <p class="text-gray-600 mb-4">
            Subject to your compliance with these Terms, Company grants you a limited, non-exclusive, non-transferable license: (i) to view, download and print any content of Platform solely for your personal and non-commercial purposes; and (ii) to access, modify, edit and download any content, to which you are permitted access solely for your use. You have no right to sublicense the license rights granted herein.
        </p>
        <p class="text-gray-600 mb-4">
            You will not use, copy, adapt, modify, prepare derivative works based upon, distribute, license, sell, transfer, publicly display, publicly perform, transmit, stream, broadcast or otherwise exploit the Platform and Services, except as expressly permitted in the Terms. No licenses or rights are granted to you by implication or otherwise under any Intellectual Property Rights owned or controlled by Company or its licensors, except for the licenses and rights expressly granted in the Terms. The Platform and the Intellectual Property Rights vested therein is owned by Company.
        </p>
        <p class="text-gray-600 mb-4">
            You agree that this Platform and its Services are made available to you on a non-exclusive, non-transferable, non-sublicensable and on a limited license basis and hence, you will not permit, enable, introduce or facilitate other persons to participate in availing Services from your Account, including others who may be subject to an agreement that is the same or similar to this Terms and Conditions.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">7. Additional Terms and Conditions for Users Using Various Services Offered by the Company</h2>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Short Term Rental Booking Model:</h3>
        <p class="text-gray-600 mb-4">
            Rental for a period of up to 89 (eighty-nine) days is considered as daily and short term rentals.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Rental Booking Model:</h3>
        <p class="text-gray-600 mb-4">
            You shall be obligated to remit the booking amount exclusively via online channels, specifically through our Platform. To gain access to the Services provided by the Company, you must effectuate payment in accordance with the stipulated amount as determined by the Company and displayed on the Platform, which may be subject to alteration at the sole discretion of Company.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Extension Payment:</h3>
        <p class="text-gray-600 mb-4">
            In the event that the User necessitates an extension of the rental duration, the User shall be held responsible for the settlement of any and all additional sums payable for the extended rental. Such payments shall exclusively be facilitated through our Platform, contingent upon the availability of the requisite vehicle.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Invoice:</h3>
        <p class="text-gray-600 mb-4">
            The User shall make the payment to the Company in advance as per the invoice. The Company will raise the invoice on the User for the Services.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Multiple Payment Options:</h3>
        <p class="text-gray-600 mb-4">
            The User acknowledges that multiple payment options such as debit/credit card, net banking, Unified Payments Interface (UPI) etc are made available at the time of making a transaction. The User further agrees and acknowledges that Company shall not be responsible or assume any liability in respect of any loss or damage arising directly or indirectly to the User due to any payment issues arising out of any transaction on the third-party payment gateway. However, the Company reserves the right, but have no obligation, to facilitate and support the User in mutually resolving any transaction failure or such other payment issues faced by the User; provided however, that the User ensures and takes all reasonable efforts to immediately contact, cooperate with and notify the Company regarding the payment issues faced by the User.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Payment Gateway and Regulatory Charges:</h3>
        <p class="text-gray-600 mb-4">
            All charges incurred through the payment gateway and other associated transactional costs shall be subjected to the regulatory frameworks and directives as mandated by competent governmental authorities.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Right to Amend:</h3>
        <p class="text-gray-600 mb-4">
            The Company reserves the right to amend the pricing, pricing bands or structure in any transaction that falls within the purview of these Terms and Conditions from time to time for any reason whatsoever, subject to due notification of such amendment to the User (direct notification or via Platform) and the User specifically disclaims any and all rights that vest upon him/her under any contract, law or equity in this regard.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Refunds and Cancellation:</h3>
        <p class="text-gray-600 mb-2">Any security deposit collected will be refunded to the User.</p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Booking related:</strong></li>
            <li>No show - 100% deduction.</li>
            <li>Between 0 - 6 hrs of the pick up time - 75% rental charges will be withheld.</li>
            <li>Between 6-24 hrs of the pick up time: 50% rental charges will be withheld.</li>
            <li>Between 24-72 hrs of the pick up time: 25% rental charges will be withheld.</li>
            <li>72 hrs or more prior to the pick up time: 10% rental charges will be withheld.</li>
            <li><strong>Cancellation due to document issue:</strong></li>
            <li>37.5% of the rental amount will be deducted, if:</li>
            <li>User is not willing to submit the document as per the Terms and Conditions.</li>
            <li>User is not able to verify his/her identity.</li>
            <li>User has submitted the documents but not present physically at the location or someone else tries to collect the vehicle on their behalf.</li>
            <li>User’s documents are not valid.</li>
            <li><strong>Timeline:</strong> Any refund processed by the Company usually takes 3 (three) to 7 (seven) working days. The refund amount shall be credited to the source account specified by the User during the booking process. The actual time taken for the refund to reflect in the source account may vary depending on the policies and processing times of financial institutions, and the Company shall not be held liable for any delays beyond its control.</li>
            <li><strong>Early Drop-off Refunds:</strong> For avoidance of doubt, it is hereby clarified that no refunds will be issued in cases of early drop-offs.</li>
        </ul>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Deposit:</h3>
        <p class="text-gray-600 mb-4">
            For select vehicles, the Company may require the User to provide a refundable security deposit as a condition of rental. This deposit serves as a security measure to cover potential damages, liabilities, or outstanding charges that may arise during the rental period. The refund of the security deposit shall be initiated by the Company within a reasonable time frame, typically ranging from 3 (three) to 7 (seven) working days. The countdown for this processing time commences from the date of the invoice generated after the conclusion of the rental trip. The refund amount shall be credited to the source account specified by the User during the booking process. The actual time taken for the refund to reflect in the source account may vary depending on the policies and processing times of financial institutions, and the Company shall not be held liable for any delays beyond its control.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Delayed Return:</h3>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Grace Period Overrun:</strong> For vehicles returned subsequent to the designated grace period of 30 (thirty) minutes, the User shall incur a penalty of INR 500/- (Indian Rupees Five Hundred Only), coupled with a sum equivalent to 2 (two) times the standard rental (as the case may be) per hour. This provision applies to all other geographical locations not explicitly specified in the Clause 6(a)(9b) below.</li>
            <li><strong>Grace Period Overrun (specific locations):</strong> In the event of vehicles being returned beyond the stipulated grace period of 30 (thirty) minutes, the User shall be subject to a penalty amounting to INR 200/- (Indian Rupees Two Hundred Only), in addition to the standard hourly rental (as the case may be) charges. This provision applies specifically to the following geographical locations: Pune, Vadodara, Daman, Indore, Jaipur.</li>
        </ul>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Maintenance:</h3>
        <p class="text-gray-600 mb-4">
            The User shall bear the exclusive responsibility for the diligent inspection of engine oils and the meticulous maintenance of the vehicle while it remains in operation on roads. The Company will not be liable for punctures and cleanliness of the vehicle during the rental period. In the event of encountering any mechanical failures during the course of the rental period, it shall be incumbent upon the User to immediately apprise the Company of the same. Furthermore, the User must take explicit written permission from the Company, before making any mechanical changes or repairs to the vehicle during the rental period. The User shall be held accountable in the event that a mechanical failure arises as a direct consequence of negligence pertaining to the routine maintenance of the vehicle during the duration of a booking.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">RideAway Subscription:</h3>
        <p class="text-gray-600 mb-4">
            A subscription based system to eliminate the hassles of ownership available in select cities allowing Users to subscribe to two-wheeler vehicles with free maintenance, doorstep delivery and autopay facilities for a minimum duration of 3 (three) months to a maximum of 36 (thirty-six) months.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Subscription Model:</h3>
        <p class="text-gray-600 mb-4">
            The subscription plans and their respective pricing will be updated on the Platform from time to time and the User is advised to select the appropriate subscription based on its requirements. At the booking stage, the User will have to make the first payment online while making the booking to start the RY subscription service. The booking amount will consist of the first month's subscription fee along with a security deposit. Thereafter, the billing cycle for RY subscription service is 30 (thirty) days. The User has to pay the prescribed monthly subscription fee to avail RY subscription services. The User will be charged until the subscription period ends or the User cancels the subscription plan.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Invoice:</h3>
        <p class="text-gray-600 mb-4">
            The User shall make the payment to the Company in advance as per the invoice. The Company will raise the invoice on the User for the Services.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Authorization of Auto-Debit:</h3>
        <p class="text-gray-600 mb-4">
            By agreeing to these Terms and Conditions, the User hereby grants explicit authorization to the Company to initiate rež

System: automatic debits ("Auto-Debit") from the User’s designated payment instrument for the purpose of collecting payment due for the Services provided herein.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Payment Notification:</h3>
        <p class="text-gray-600 mb-4">
            The Company shall, as a matter of course, furnish the User with timely notification regarding impending financial obligations. Such notifications shall be disseminated no less than 3 (three) days in advance of the due date for each billing cycle as per the respective subscription plan.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Grace Period:</h3>
        <p class="text-gray-600 mb-4">
            In the event that any attempt to effectuate an Auto-Debit on the prescribed due date proves to be unsuccessful, the User shall be accorded a grace period of an additional 3 (three) days from the said due date (“Grace Period”). During this Grace Period, the User shall have the opportunity to rectify any payment discrepancies.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Failure to Remit Payment:</h3>
        <p class="text-gray-600 mb-4">
            In the unfortunate circumstance that the User fails to discharge the payment within the designated Grace Period, the User shall be subject to an additional fee of INR 500/- (Indian Rupees Five Hundred Only) for each individual occurrence of Auto-Debit non-completion.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Alternative Payment Arrangements:</h3>
        <p class="text-gray-600 mb-4">
            In instances of recurring Auto-Debit failures or in the event that the User’s designated payment instrument is no longer viable, the User shall be responsible for promptly furnishing an alternative, valid payment instrument or engaging in an alternative, mutually agreeable resolution process to address any outstanding obligations.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Irregular Payments:</h3>
        <p class="text-gray-600 mb-4">
            If the User does not make payment or makes irregular payments, the Company may, in its sole discretion, terminate the subscription plan availed by the User and/or discontinue the Services without notice.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Multiple Payment Options:</h3>
        <p class="text-gray-600 mb-4">
            The User acknowledges that multiple payment options such as debit/credit card, net banking, Unified Payments Interface (UPI) etc are made available at the time of making transaction. The User further agrees and acknowledges that Company shall not be responsible or assume any liability in respect of any loss or damage arising directly or indirectly to the User due to any payment issues arising out of any transaction on the third-party payment gateway. However, the Company reserves the right, but have no obligation, to facilitate and support the User in mutually resolving any transaction failure or such other payment issues faced by the User; provided however, that the User ensures and takes all reasonable efforts to immediately contact, cooperate with and notify the Company regarding the payment issues faced by the User.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Payment Gateway and Regulatory Charges:</h3>
        <p class="text-gray-600 mb-4">
            All charges incurred through the payment gateway and other associated transactional costs shall be subjected to the regulatory frameworks and directives as mandated by competent governmental authorities.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Right to Amend:</h3>
        <p class="text-gray-600 mb-4">
            The Company reserves the right to amend the subscription, pricing bands or structure in any transaction that falls within the purview of these Terms and Conditions from time to time for any reason whatsoever, subject to due notification of such amendment to the User (direct notification or via Platform) and the User specifically disclaims any and all rights that vest upon him/her under any contract, law or equity in this regard.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Refunds and Cancellations:</h3>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Before commencement:</strong> If the User wishes to cancel their subscription before the start of subscription period, 10% of the first month's subscription fee will be deducted.</li>
            <li><strong>During subscription:</strong> If the User wishes to cancel their subscription during the subscription period, the security deposit will be forfeited.</li>
            <li><strong>Failure to fulfil payment obligations:</strong> Should the User fail to fulfil their payment obligations even after receiving multiple intimations and warnings, the Company reserves the right to terminate the Services, and the security deposit shall be deemed forfeited.</li>
            <li><strong>Illegal or illicit activities:</strong> If it comes to the Company's attention that the vehicle provided as part of the Services is being employed for any illegal or illicit activity, the Company retains the authority to seize the vehicle, terminate the Services forthwith, and declare the security deposit as forfeited.</li>
            <li><strong>Timeline:</strong> Any refund processed by the Company usually takes 3 (three) to 7 (seven) working days. The refund amount shall be credited to the source account specified by the User during the booking process. The actual time taken for the refund to reflect in the source account may vary depending on the policies and processing times of financial institutions, and the Company shall not be held liable for any delays beyond its control.</li>
            <li><strong>No Refunds:</strong> For avoidance of doubt, it is hereby clarified that no refunds will be issued in cases of early termination of subscription.</li>
        </ul>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Deposit:</h3>
        <p class="text-gray-600 mb-4">
            The Company shall require the User to provide a refundable security deposit as a condition of subscription. This deposit serves as a security measure to cover potential damages, liabilities, or outstanding charges that may arise during the subscription period. The deposit will be forfeited in case of an early drop off or early termination of the subscription plan. The security deposit will be refunded fully to the User if they have no dues. The refund of the security deposit shall be initiated by the Company within a reasonable time frame, typically ranging from 3 (three) to 7 (seven) working days. The countdown for this processing time commences from the date of the invoice generated after the conclusion of the subscription period. The refund amount shall be credited to the source account specified by the User during the booking process. The actual time taken for the refund to reflect in the source account may vary depending on the policies and processing times of financial institutions, and the Company shall not be held liable for any delays beyond its control.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Doorstep Delivery Process:</h3>
        <p class="text-gray-600 mb-4">
            The Company will coordinate with the User to schedule the vehicle's delivery. The User must be present at the agreed date and time, at the designated location for vehicle receipt. The User must conduct a test ride of the vehicle before accepting it from the Company. Delivered vehicles cannot be rejected after handover. The User may request a vehicle exchange if dissatisfied with the vehicle's condition. While quality checks are conducted before delivery, the User is expected to inspect for damages and report them to the Company's representative, accompanied by photographic evidence. It is hereby clarified that the vehicle delivery is contingent upon availability. If at the time of the scheduled delivery, the User is unavailable or refuses to take the delivery of the vehicle, they will be charged a stipulated fee of INR 200/- (Indian Rupees Two Hundred Only) for rescheduling. Furthermore, the Company retains the right to refuse Services to any User not deemed suitable by the Company or its authorized staff. Without waiving its rights and claims under the law and equity, the Company reserves the right to terminate/suspend User registration, withdraw Services, or impose penalties if the User misuses or operates the vehicles in contravention of the Company’s policies and these Terms and Conditions.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Doorstep Pickup Process:</h3>
        <p class="text-gray-600 mb-4">
            Pickup details will be mutually decided, with the drop-off location matching the pickup location. The User must be present at the agreed date and time, and the vehicle will be inspected for damages. Should the User fails to return the vehicle at the scheduled date and time, rescheduling will be charged at INR 500/- (Indian Rupees Five Hundred Only) per attempt.
        </p>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Maintenance:</h3>
        <p class="text-gray-600 mb-4">
            During the subsistence of the subscription period, the User shall be under a mandatory obligation to provide, without exception, updates concerning the odometer reading every 15 (fifteen) days to the Company. The User shall bear the exclusive responsibility for the diligent inspection of engine oils and the meticulous maintenance of the vehicle while it remains in operation on roads. In the event of encountering any mechanical failures during the course of the subscription period, it shall be incumbent upon the User to immediately apprise the Company of the same. The User shall be held accountable in the event that a mechanical failure arises as a direct consequence of negligence pertaining to the routine maintenance of the vehicle during the duration of a trip. The Company may provide a singular general service check on a monthly basis, concomitant with the provision of technical assistance in the event of any technical complications that may manifest during the currency of the subscription period. In the instance wherein scheduled maintenance becomes a requisite during the subscription period, an authorized representative of Company shall facilitate the retrieval of the vehicle for the express purpose of servicing. In the remote and improbable circumstance that the maintenance exigency transcends a duration of 6 (six) hours, thereby precluding the immediate resolution of the matter, the User shall be duly apprised, and an alternative vehicle shall be furnished to them for utilization.
        </p>
        <p class="text-gray-600 mb-4">
            The aforementioned additional terms are provided as supplementary to the overarching provisions contained in the Terms and Conditions. It is explicitly clarified that all remaining provisions as set forth in these Terms and Conditions shall apply universally to all Users, irrespective of the specific services or model selected. The aforementioned additional terms pertain specifically to certain services or features and are to be read in conjunction with the general provisions contained in these Terms and Conditions.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">8. Vouchers and Coupons</h2>
        <p class="text-gray-600 mb-4">
            The Company or its affiliated third parties, at their sole discretion, may issue coupons or vouchers, each with distinct terms and functionalities:
        </p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Coupons</strong> represent specified discounts or cashback values applicable to purchases on our Platform. Coupons do not cover any taxes paid during the booking process.</li>
            <li><strong>Vouchers</strong> are specifically issued by the Company at its sole discretion in the event of booking cancellations, allowing Users to receive credits for the entire booking amount. Vouchers can be redeemed on our Platform for future bookings. When a voucher is applied to create a booking, the system will automatically adjust the tax amount for the subsequent booking.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">9. Fuel</h2>
        <p class="text-gray-600 mb-4">
            The rental or subscription amount (as the case may be) does not encompass the cost of fuel. The Company shall supply each vehicle with adequate fuel to reach the nearest accessible fuel station. The Company shall not entertain requests for refunds or reimbursements in case there remains surplus fuel in the vehicle's tank upon its return.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">10. Extra Charges</h2>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li><strong>Excess Km:</strong> The excess km charges post consumption of km limit, will be calculated at the time of drop off and the User will be required to pay the same at the location.</li>
            <li><strong>Damages:</strong> Damages will be inspected at the drop-off time and the charges will be collected on the spot as per the damage terms and conditions.</li>
            <li><strong>Over-speeding:</strong> The vehicles have to be ridden within permissible limits. The speed limit for each vehicle is different which will be communicated in the booking confirmation email after the booking is made. User has to adhere to the speed limit specified for the vehicle or the speed limit specified by the governing authority, whichever is lesser. After 3 (three) consecutive violations of the speed limit, the further violation will be charged INR 500/- (Indian Rupees Five Hundred Only) for each instance.</li>
        </ul>
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Rules & Code of Conduct</h1>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">1. General Rules</h2>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>You shall not use the Platform for any purpose that is prohibited by the Terms; or other rules or policies implemented by us from time to time.</li>
            <li>You shall comply with all applicable local, provincial laws, and regulations in connection with your availing of the Services.</li>
            <li>You shall keep Company informed of any technical issues or problems with the Platform, as and when the issues develop.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            By way of example, and not as a limitation, you shall not (and shall not permit any third party to) take any action (including without limitation host, display, upload, modify, publish, transmit, store, update or sharing of information) that:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>would constitute a violation of any applicable law, rule or regulation or belongs to another person;</li>
            <li>infringes on any intellectual property or other right of any other person or entity;</li>
            <li>is threatening, abusive, harassing, defamatory, libelous, deceptive, fraudulent; or</li>
            <li>impersonates any person or entity;</li>
            <li>deceives or misleads the addressee about the origin of the message or knowingly and intentionally communicates any information which is patently false or misleading in nature but may reasonably be perceived as a fact;</li>
            <li>contains software virus or any other computer code, file or program designed to interrupt, destroy or limit the functionality of any computer resource or;</li>
            <li>is patently false and untrue, and is written or published in any form, with the intent to mislead or harass a person, entity or agency for financial gain or to cause any injury to any person.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            The Company reserves the right to disable any Account from the Platform at any time for any reason (including, but not limited to, upon receipt of claims or allegations from third parties or authorities; or if Company is concerned that you may have violated the Terms of Use), or for no reason at all with or without notice to the User/Users.
        </p>
        <p class="text-gray-600 mb-4">
            Additionally, you shall not share any information that:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>may be harmful to minors or children below the age of 18 (eighteen) years;</li>
            <li>threatens the unity, integrity, defence, security or sovereignty of the country, friendly relations with foreign states or public order or causes incitement to the commission of any cognisable offence or prevents investigation of any offence or is insulting any other nation;</li>
            <li>is invasive of another’s privacy, hateful, or racially, ethnically objectionable, disparaging, relating or encouraging money laundering or gambling, or otherwise unlawful in any manner whatever;</li>
            <li>harms minors in any manner;</li>
            <li>infringes any patent, trademark, copyright or other proprietary rights;</li>
            <li>violates any laws for the time being.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            Furthermore, you shall not (directly or indirectly):
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>take any action that imposes or may impose an unreasonable or disproportionately large load on Company’s (or its third party providers’) infrastructure;</li>
            <li>interfere or attempt to interfere with the proper working of the Platform or any activities conducted on the Platform;</li>
            <li>bypass any measures we may use to prevent or restrict access to the Platform (or parts thereof);</li>
            <li>decipher, decompile, disassemble, reverse engineer or otherwise attempt to derive any source code or underlying ideas or algorithms of any part of the Platform, except to the limited extent applicable laws specifically prohibit such restriction;</li>
            <li>modify, translate, or otherwise create derivative works of any part of the Platform; or</li>
            <li>copy, rent, lease, distribute, or otherwise transfer any or all of the rights that you receive hereunder.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            You will not access the Platform, and/or its services, or the personal information of other Users, available on the Platform in order to build a similar or competitive website, product, or service.
        </p>
        <p class="text-gray-600 mb-4">
            You agree to immediately notify us of any unauthorised use, or suspected unauthorised use of your Account, or any other breach of security, in relation to your personal information on the Platform.
        </p>
        <p class="text-gray-600 mb-4">
            One Account shall not be used by more than one User. Any use of an Account by a third-party would deem to be unauthorised usage. The Company reserves the right to disable any such Account from the Platform.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">2. Use of Your Information</h2>
        <p class="text-gray-600 mb-4">
            You may provide only information that you own or have the right to use. We may only use the information you provide as permitted by our Privacy Policy and applicable law. For example, we will never share your personally identifiable information without your prior permission. Please closely review our <a href="https://www.rideaway.in/privacy-policy" class="text-blue-600 hover:underline">Privacy Policy</a> for more information regarding how we use and disclose your personal information. Our Privacy Policy is hereby incorporated into these Terms of Service by this reference.
        </p>
        <p class="text-gray-600 mb-4">
            We ensure easy access to the Users by providing an option to update your Account information. We reserve the right to moderate the changes or updates requested by you.
        </p>
        <p class="text-gray-600 mb-4">
            We reserve the right to maintain, delete or destroy all information and materials posted or uploaded through the Services, pursuant to our internal record retention and/or destruction policies. We (may/may not) make use of third-party cloud services providers or use our own service infrastructure for hosting the servers and databases. While we make commercially reasonable efforts to ensure that the data stored on our servers is persistent and always available to the User, we will not be responsible in the event of failure of the third-party servers or any other factors outside our reasonable control that may cause the User’s data to be permanently deleted, irretrievable, or temporarily inaccessible.
        </p>
        <p class="text-gray-600 mb-4">
            You acknowledge and agree that we may preserve your information and may also disclose your related information if required to do so by law; or in the good faith belief that such preservation or disclosure is reasonably necessary to: (i) comply with legal process, applicable laws or government requests; (ii) enforce these Terms of Services; (iii) respond to claims that any of your usage of the Platform violates the rights of third parties; (iv) detect, prevent, or otherwise address fraud, security or technical issues; or (v) protect the rights, property, or personal safety of the Platform, its users, or the public.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">3. Use of the Vehicle and Prohibited Uses</h2>
        <p class="text-gray-600 mb-4">
            Users must make bookings for personal use only and are solely responsible for the rented or subscribed vehicle during the rental or subscription period (as the case may be). Any breach of terms during the rental or subscription period will be considered a material breach of these Terms and Conditions. The Company does not guarantee vehicle availability but will act in the User's best interest. The User has to follow the under mentioned terms and conditions:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>Users must handle large and powerful vehicles with care, especially if they are beginners;</li>
            <li>Users between the age group of 18-20 years will be allowed to ride vehicles below 200cc and the Users who are 21 years and above will be allowed to ride all vehicles, including superbikes;</li>
            <li>the User must wear helmets and appropriate riding gear, including closed-toe shoes and pants. No flip-flops, sandals, or shorts allowed;</li>
            <li>The use of mobile holders is at the customer’s discretion. The company shall not be held liable for any damages to the rider or their devices resulting from the use of the mobile holder;</li>
            <li>Bookings and extensions are subject to vehicle availability;</li>
            <li>Only the User is allowed to drive the vehicle;</li>
            <li>Vehicles must be picked up and dropped off at the Company’s designated parking locations unless home delivery is requested and paid for (subject to availability and discretion of the Company);</li>
            <li>The User is responsible for inspection of the vehicle at the pickup location and is expected to inform the executive immediately in case of any damages, malfunctions, missing parts etc.;</li>
            <li>While vehicles are insured, Users may opt for a separate insurance for themselves. The Company is not responsible for the User’s accidental expenses;</li>
            <li>Users ride at their own risk, and the Company is not responsible for any loss, injury, or death resulting from vehicle hire;</li>
            <li>Vehicles must be returned in the same condition as received;</li>
            <li>In case the vehicle returned is found excessively dirty/muddy, the User will have to bear the charge of washing not exceeding INR 200/- (Indian Rupees Two Hundred Only);</li>
            <li>Rental or subscription package excludes fuel, toll, roadside assistance, and taxes;</li>
            <li>Users are solely responsible and liable for any traffic violations and associated costs. Users must report such violations to a Company’s representative as soon as possible;</li>
            <li>Users bear towing costs for tire puncture, collision, or breakdown due to improper usage. Mechanical failures are covered by the Company;</li>
            <li>All our bikes have GPS tracking devices; we recommend that the User follow speed guidelines – our team gets automated updates on the bikes that exceed speed limits and can penalize the User for rash driving up to INR 500/- (Indian Rupees Five Hundred Only) per instance;</li>
            <li>In case the User has left any belongings, the Company will try its best to return the same to the User however the Company cannot be held responsible for the loss of any items due to the negligence of the User;</li>
            <li>In the case of EV vehicles, the Company will be providing a charger along with the vehicle, however it's the User's responsibility to charge the vehicle according to the guidelines.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            The use of a Company’s vehicle under the following conditions is prohibited:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>User will not carry load or passenger more than the prescribed limit by the authorities;</li>
            <li>Our vehicles shall be used solely for personal use and cannot be used for rallies and rally surcharges or any format of professional or amateur competitions or for performing stunts;</li>
            <li>Our vehicle will not be used by any person who is under the influence of (a) alcohol or (b) any drug or medication under the effects of which the operation of a vehicle is prohibited or not recommended;</li>
            <li>Our vehicle will not be used for any illegal activities or activities that are prohibited under applicable laws;</li>
            <li>Users are not allowed to make any modifications, internal or external to the motorcycle. Any additional fittings on the vehicle will lead to prohibition of the User from usage of the motorcycle any further;</li>
            <li>Minors will not be provided with any vehicle from the Company and the same is expected from the Users. The Company will not be responsible in case the vehicle is shared with a minor;</li>
            <li>Any sharp objects, weapons or illegal substances are prohibited from being carried on any Company’s vehicle.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">4. Process to Rent Helmet</h2>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>1 complementary helmet is provided without any charge.</li>
            <li>Extra helmets can be added while making the booking. You will get an option on the summary page to select the quantity of the helmet.</li>
            <li>Users can rent only 2 helmets per booking.</li>
            <li>If the helmet is damaged or lost, a charge of INR 900/- (Indian Rupees Nine Hundred Only) per helmet will be levied since branded helmets will be provided to the User.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">5. Liability for Vehicle Damage</h2>
        <p class="text-gray-600 mb-4">
            The User acknowledges and undertakes the responsibility to bear all costs for any damage to, loss of, or theft (disappearance) of vehicle parts, irrespective of causation or fault. Items rendered irreparable shall be compensated at their prevailing market price.
        </p>
        <p class="text-gray-600 mb-4">
            The representative of the Company shall check the vehicle and its parts in order to ascertain any damage to items. Damage shall be defined as follows:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>any damage pre existing before the vehicle handover, and mutually acknowledged by the User and Company, shall not be charged to the User;</li>
            <li>a tear in the seat cover shall result in a charge for seat cover replacement. The opening of stitched joints shall not incur charges;</li>
            <li>Any variations indicating damage, not attributed to normal wear and tear, shall be chargeable and borne exclusively by the User.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            In the unfortunate event of an accident or collision involving vehicles with an engine capacity below 200cc, it is hereby stipulated that the User shall bear responsibility for the payment of a standardized amount as delineated below:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>An amount not exceeding INR 15,000/- (Indian Rupees Fifteen Thousand Only), coupled with an additional charge equivalent to 50% of the daily rental or subscription rate (as the case may be) for each day during which the vehicle remains inactive, consequent to repair and maintenance.</li>
            <li>In instances wherein the assessed damages transcend the sum of INR 15,000/- (Indian Rupees Fifteen Thousand Only), as professionally estimated, an insurance claim shall be promptly instituted. Subsequently, an ancillary sum of INR 15,000/- (Indian Rupees Fifteen Thousand Only) shall be levied upon the User.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            In the lamentable event of an accident or collision involving vehicles with an engine capacity of 200cc and above, it is hereby established that the User shall be held accountable for the payment of a standardised amount, the particulars of which are enumerated hereunder:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>In instances wherein the assessed damages transcend the sum of INR 25,000/- (Indian Rupees Twenty Five Thousand Only), as professionally estimated, an insurance claim shall be promptly instituted. Subsequently, an ancillary sum of INR 25,000/- (Indian Rupees Twenty Five Thousand Only) shall be levied upon the User.</li>
        </ul>
        <h3 class="text-xl font-semibold text-gray-700 mt-4 mb-2">Theft Liability:</h3>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>It is hereby solemnly acknowledged that the "onus of ownership" during the rental or subscription period (as the case may be) remains squarely upon the User. Consequently, the User shall be vested with sole and unequivocal responsibility for any untoward incidents that may transpire during the rental or subscription period (as the case may be).</li>
            <li>In the lamentable circumstance of the vehicle's theft or disappearance during the rental or subscription period (as the case may be), it shall be incumbent upon the User to promptly initiate the filing of a First Information Report (“FIR”) at the nearest police station. Furthermore, the User shall be obliged to diligently adhere to all ensuing legal procedures until such time as the vehicle is either recovered or an insurance claim is deemed valid.</li>
            <li>In the regrettable event of the insurance claim being repudiated, the User shall bear the onus of remitting payment equivalent to the fair market value of the missing vehicle.</li>
            <li>Refusal to comply with the vehicle recovery process or any reluctance to remit the requisite sum may, at the discretion of Company, precipitate the initiation of legal proceedings against the User. The User shall, in this instance, be liable for any and all legal expenses incurred as a result thereof.</li>
            <li>The User agrees and undertakes to assume responsibility for any and all legal and recovery costs incurred in the course of addressing the aforementioned matter described in this Clause 12.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">6. Declarations, Representations, Warranties and Covenants</h2>
        <p class="text-gray-600 mb-4">
            Each Party hereby represents and warrants that it has the legal right, power and authority to enter into, deliver and perform this Terms and Conditions and any other documents executed in connection with or pursuant thereto.
        </p>
        <p class="text-gray-600 mb-4">
            Notwithstanding anything contained herein, the User does not have the right to assign any of his/her rights under these Terms to any other person or organisation.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">7. Third Party Sites</h2>
        <p class="text-gray-600 mb-4">
            While availing Services, Users may connect with third-party service providers. The Company is not responsible for, and does not endorse, any third-party services mentioned on the Platform or otherwise recommended by the Company. It is hereby stated that the Company shall in no way be responsible for any acts or omissions of third parties. Any transaction, dealings or communication otherwise that the User may have with such third parties are at the User’s own risk and we make no warranties, express or implied regarding the quality or suitability of the services or products of such third-party vendors. You may be redirected to a third-party website upon clicking on such links, these websites will be governed by its privacy policy and terms of use. We shall not be responsible for any transaction or dissemination of information that may take place while accessing these third-party websites.
        </p>
        <p class="text-gray-600 mb-4">
            You acknowledge that when you access a link that leaves the services, the site you will enter into is not controlled by us and different terms of use and privacy policy may apply. By assessing links to other sites, You acknowledge that we are not responsible for those sites. We reserve the right to disable links to and/or from third-party sites to the Services, although we are under no obligation to do so.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">8. Interactive Sessions</h2>
        <p class="text-gray-600 mb-4">
            Some parts of the Services are interactive, and the Company is in no way responsible for the content, information or actions of the User and/or other third parties. You are solely responsible for your interactions and communications with the third-party including any sensitive personal information provided by you to any other parties with whom you interact or communicate with through the Service.
        </p>
        <p class="text-gray-600 mb-4">
            You shall not use the Platform except strictly for the purposes specifically laid down in this Terms of Service.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">9. Intellectual Property</h2>
        <p class="text-gray-600 mb-4">
            Company shall own all right, title and interest (including patent rights, copyrights, trade secret rights, mask work rights, trademark rights and all other rights of any sort throughout the world) relating to any and all inventions (whether or not patentable), works of authorship, mask works, designations, designs, know-how, content of the Platform, video recordings, ideas and information, google text chats which are subject matter of Services (collectively referred to as “Intellectual Properties”).
        </p>
        <p class="text-gray-600 mb-4">
            Notwithstanding anything contained in this Terms and Conditions, Intellectual Properties include all rights of paternity, integrity, disclosure and withdrawal and any other rights that may be known as or referred to as “moral rights,” “artist’s rights,” “droit moral,” or the like.
        </p>
        <p class="text-gray-600 mb-4">
            While rendering Services, Company directly or through its representatives, may provide Users with certain materials relevant to the Services, which may be in the form of audio, video, written and oral content (“Company Materials”). Company Materials shall be the exclusive property of the Company. User hereby agrees and acknowledges that he/she shall ensure that the Company Materials are not shared with any third party, without Company’s written consent and any breach of such nature shall cause financial and irreparable injury to Company. Company hereby provides User with a revocable, non-exclusive, non-transferable, non-sublicensable, limited license to use the Company Materials solely for its personal purpose and not for any commercial use.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">10. Confidentiality</h2>
        <p class="text-gray-600 mb-4">
            The User agrees to keep all technical and non-technical information, which Company may have acquired before or after the date of this Terms and Conditions in relation to the technology, customers, business, operations, financial conditions, assets or affairs of the other Party resulting from negotiating this Terms and Conditions; or exercising its rights or performing its obligations under this Terms and Conditions; or which relates to the contents of this Terms and Conditions (or any agreement or arrangement entered into pursuant to this Terms and Conditions), including but not limited to business plans, business forecasts, research, technology and financial information, procurement requirements, purchasing requirements, manufacturing, customer lists, sales and merchandising efforts, marketing plans, experimental work, development, design details, specifications, engineering, copyrights, trade secrets, proprietary information, know-how, processes, equipment, algorithms, software programs, software source documents, and information in any way related to the current, future and proposed business, products and Services of Company confidential or any other information designated as confidential from time to time.
        </p>
        <p class="text-gray-600 mb-4">
            Notwithstanding anything in the foregoing to the contrary, confidential information shall not include information which: (a) was known by the User prior to receiving the confidential information from Company; (b) becomes rightfully known to the User from a third-party source not known (after diligent inquiry) by the User to be under an obligation to Company to maintain confidentiality; (c) is or becomes publicly available through no fault of or failure to act by the User in breach of this Terms and Conditions; (d) is required to be disclosed in a judicial or administrative proceeding, or is otherwise requested or required to be disclosed by law or regulation.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">11. Rights and Obligations Relating to the Usage of the Platform</h2>
        <p class="text-gray-600 mb-4">
            Users shall be prohibited from carrying out the any illegal acts in the Platform including but not limited to acts mentioned below:
        </p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>violating or attempting to violate the integrity or security of the Platform;</li>
            <li>transmitting any information on or through the Platform that is disruptive or competitive to the provision of our Services;</li>
            <li>intentionally submitting on the Platform any incomplete, false or inaccurate information;</li>
            <li>making any unsolicited communications to other Users;</li>
            <li>using any engine, software, tool, agent or other device or mechanism (such as spiders, robots, avatars or intelligent agents) to navigate or search the Platform;</li>
            <li>circumventing or disabling any digital rights management, usage rules, or other security features of the Platform;</li>
            <li>Any unlawful activities in the Platform which are prohibited by applicable laws.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            The Company shall, upon obtaining knowledge by itself or been brought to actual knowledge by an affected person in writing or through email signed with electronic signature about any such information as mentioned above, be entitled to disable such information that is in contravention of this Clause. We shall also be entitled to preserve such information and associated records for at least 90 (ninety) days for production to governmental authorities for investigation purposes. In case of non-compliance with any applicable laws, rules or regulations, or the Terms and Conditions (including the Privacy Policy) by a User, we shall have the right to immediately terminate your access or usage rights to the Platform and Services and to remove non-compliant information from the Platform.
        </p>
        <p class="text-gray-600 mb-4">
            We may disclose or transfer User-generated information to our affiliates or governmental authorities in such manner as permitted or required by applicable law, and you hereby consent to such transfer. In accordance with the applicable laws, we shall transfer sensitive personal data or information including any information, to any other body corporate or a person in India, or located in any other country, that ensures the same level of data protection that is adhered to by us, only if such transfer is necessary for the performance of the lawful contract between Company or any person on its behalf and the User or where the User has consented to data transfer.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">12. Suspension and Termination</h2>
        <p class="text-gray-600 mb-4">
            These Terms of Services are effective unless and until terminated by either you or Company. You may terminate these Terms of Services at any time by notifying us that you no longer wish to use our Services, or when you cease using our Platform.
        </p>
        <p class="text-gray-600 mb-4">
            We have the right to temporarily suspend access to the whole or any part of the Services for any reason whatsoever (including but not limited to technical/operational reasons) and shall be under no liability to you in such an event. Further, we may, but are not obliged to, give you notice of any interruption of access to the Service.
        </p>
        <p class="text-gray-600 mb-4">
            We may temporarily suspend access to the whole or any part of the Services for pre-scheduled maintenance. The intent to temporarily suspend access for pre-scheduled maintenance shall be communicated to you 48 hours in advance via phone number/email to the contact details provided by you upon creation of your Account. If you choose to access the Platform or avail Services during such pre-scheduled maintenance, we cannot guarantee the availability of the Services and/or functionality of the Platform.
        </p>
        <p class="text-gray-600 mb-4">
            We may terminate your usage of the Platform at any time for any reason, including breach of the Terms and Conditions. We have the right (but not the obligation) to refuse to grant access to Platform. Except for the rights and license granted in these terms, we reserve all other rights and grant no other rights or licenses, implied or otherwise.
        </p>
        <p class="text-gray-600 mb-4">
            Once temporarily suspended, indefinitely suspended or terminated, the User may not continue to use the Platform under the same account, a different account or re-register under a new account. On termination of an account due to the reasons mentioned herein, such User shall no longer have access to data, messages and other material kept on the Platform by such User. All provisions of the Terms of Services, which by their nature should survive termination, shall survive termination, including, without limitation, warranty disclaimers, indemnity and limitations of liability.
        </p>
        <p class="text-gray-600 mb-4">
            In the event of any termination of this Terms and Conditions, the User shall promptly and forthwith make payments accrued or due to Company.
        </p>
        <p class="text-gray-600 mb-4">
            Upon termination of this Terms and Conditions, any rights or obligations of the User existing at the time of expiration or termination, which, by their nature, survive the expiration or termination of this Terms and Conditions and such other provision as specifically identified in this Terms and Conditions, shall survive.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">13. Alerts</h2>
        <p class="text-gray-600 mb-4">
            The Company provides you with multiple automatic and/or customised alerts while providing Services.
        </p>
        <p class="text-gray-600 mb-4">
            You understand and agree that any alerts provided to you through the Platform may be delayed or prevented by a variety of factors. We will do our best to provide alerts in a timely manner with accurate information. However, we neither guarantee the delivery nor the accuracy of the content of any alert. You also agree that we shall not be liable for any delays, failure to deliver, or misdirected delivery of any alert; for any errors in the content of an alert; or for any actions taken or not taken by you or any third party in reliance on an alert.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">14. Contact You</h2>
        <p class="text-gray-600 mb-4">
            You agree that we may contact you through telephone, email, SMS, or any other means of communication for the purpose of:
        </p>
        <ul class="list-disc ml-6 text-gray-600 mb-4">
            <li>Rendering Services;</li>
            <li>Obtaining feedback in relation to Platform or our Services;</li>
            <li>Obtaining feedback in relation to any other Users listed on the Platform;</li>
            <li>Any events or initiatives that you may be interested in as part of the community of users;</li>
            <li>Resolving any complaints, information, or queries by other Users regarding your critical content.</li>
        </ul>
        <p class="text-gray-600 mb-4">
            You agree to provide your fullest cooperation further to such communication by the Company.
        </p>
        <p class="text-gray-600 mb-4">
            The User hereby unconditionally consents that such communications via SMS/other messages and/or voice call by the Company is: (i) upon the request and authorization of the User, (ii) 'transactional' and not an 'unsolicited commercial communication' under Telecom Commercial Communication Customer Preference (“TRAI”) Regulations, 2010 or such other applicable regulations including any amendment thereof, as may be applicable from time to time, (iii) in compliance with the relevant guidelines of TRAI or such other authority in India and abroad.
        </p>
        <p class="text-gray-600 mb-4">
            The User will indemnify the Company against all types of losses and damages incurred by Company due to any action taken by TRAI or any other authority due to any erroneous complaint made by the User against the Company with respect to the intimations mentioned above or on account of any wrong number or email id provided by the User for any reason whatsoever.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">15. Disclaimers</h2>
        <p class="text-gray-600 mb-4">
            THE SERVICE RENDERED ON COMPANY'S PLATFORM ARE PROVIDED "AS IS" AND “AS AVAILABLE”. COMPANY MAKES NO WARRANTIES, EXPRESSED OR IMPLIED, AND HEREBY DISCLAIMS AND NEGATES ALL OTHER WARRANTIES, INCLUDING WITHOUT LIMITATION, IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT OF INTELLECTUAL PROPERTY OR OTHER VIOLATION OF RIGHTS. FURTHERMORE, COMPANY DOES NOT WARRANT OR MAKE ANY REPRESENTATIONS CONCERNING THE ACCURACY, LIKELY RESULTS, OR RELIABILITY OF THE USE OF THE MATERIALS ON ITS PLATFORM OR OTHERWISE RELATING TO SUCH MATERIALS OR ON ANY SITES LINKED TO THIS SITE.
        </p>
        <p class="text-gray-600 mb-4">
            THE COMPANY, ITS DIRECTORS, EMPLOYEES, AGENTS, SUPPLIERS, SPONSORS AND PARTNERS DO NOT WARRANT THAT: (A) THE SERVICE WILL BE SECURE OR AVAILABLE AT ANY PARTICULAR TIME OR LOCATION; (B) ANY DEFECTS OR ERRORS WILL BE CORRECTED; (C) ANY CONTENT OR SOFTWARE AVAILABLE AT OR THROUGH THE SERVICE IS FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS; (D) THE RESULTS OF USING THE SERVICE WILL MEET YOUR REQUIREMENTS; (E) ANY INFORMATION PROVIDED BY US IN ANY WAY WILL MEET YOUR REQUIREMENTS ; OR (F) THE PLATFORM WILL BE FREE OF GLITCHES. YOUR USE OF THE SERVICE IS SOLELY AT YOUR OWN RISK.
        </p>
        <p class="text-gray-600 mb-4">
            COMPANY DOES NOT WARRANT THAT THE USER WILL BE ABLE TO USE THE PLATFORM/PLATFORM AT ALL TIMES OR LOCATIONS ON THE PLATFORM/PLATFORM OR THAT THE PLATFORM AND THE SERVICES PROVIDED THROUGH THE PLATFORM/PLATFORM WILL BE UNINTERRUPTED OR ERROR-FREE.
        </p>
        <p class="text-gray-600 mb-4">
            WE DON’T PROMISE TO STORE OR KEEP SHOWING ANY INFORMATION AND CONTENT THAT YOU’VE POSTED. THE COMPANY DOES NOT PROVIDE A STORAGE SERVICE. YOU AGREE THAT WE HAVE NO OBLIGATION TO STORE, MAINTAIN OR PROVIDE YOU A COPY OF ANY CONTENT OR INFORMATION THAT YOU OR OTHERS PROVIDE, EXCEPT TO THE EXTENT REQUIRED BY APPLICABLE LAW AND AS NOTED IN OUR PRIVACY POLICY.
        </p>
        <p class="text-gray-600 mb-4">
            THE USER ACKNOWLEDGES AND VOLUNTARILY ASSUMES ALL INHERENT RISKS ASSOCIATED WITH THE OPERATION OR RIDING ON ONE OR MORE MOTORCYCLES OR OTHER VEHICLES OWNED OR CONTROLLED BY THE COMPANY, EACH SUCH COMPANY-OWNED OR CONTROLLED VEHICLE REFERRED TO HEREIN AS A "C.O.C.V.". THE USER FULLY COMPREHENDS THAT THE ACT OF OPERATING OR RIDING ON A C.O.C.V. INHERENTLY ENTAILS UNIQUE RISKS, AND ACKNOWLEDGES THAT SERIOUS INJURY, PROPERTY DAMAGE, OR EVEN DEATH MAY OCCUR WITHOUT ANY FAULT ON THEIR PART. BY ACCEPTING THE TERMS AND CONDITIONS, THE USER EXPRESSLY AGREES TO ASSUME THE ENTIRE RISK OF ANY ACCIDENTS, PROPERTY DAMAGE, OR PERSONAL INJURY, INCLUDING BUT NOT LIMITED TO PERMANENT DISABILITY, PARALYSIS, AND DEATH, RESULTING FROM THEIR OPERATION OR RIDING ON A C.O.C.V. THIS ASSUMPTION OF RISK ENCOMPASSES ALL ASPECTS RELATED TO THE C.O.C.V., INCLUDING BUT NOT LIMITED TO THEIR CONDITION, MAINTENANCE, SAFETY, USAGE, WEATHER CONDITIONS, AND THE POTENTIAL FOR SINGLE AND/OR MULTI-VEHICLE ACCIDENTS. FURTHERMORE, THE USER ACKNOWLEDGES THE POTENTIAL USE OF PROTOTYPE OR PRE-PRODUCTION C.O.C.V.s, UNDERSTANDING THE INCREASED RISKS ASSOCIATED WITH SUCH VEHICLES, AND AGREES TO ASSUME THOSE RISKS. THE USER AFFIRMS, AT THE TIME OF BOOKING AND DURING OPERATION, THEIR SOBRIETY AND UNIMPAIRED JUDGMENT, AGREEING NOT TO OPERATE OR RIDE ON ANY C.O.C.V. WHILE UNDER THE INFLUENCE OF ALCOHOL, DRUGS, ILLEGAL SUBSTANCES, OR ANY MEDICATIONS IMPAIRING THEIR ABILITIES. ADDITIONALLY, THE USER UNDERTAKES THE RESPONSIBILITY TO INSPECT EACH C.O.C.V. BEFORE OPERATION, ENSURING ITS PROPER WORKING CONDITION AND THEIR OWN FAMILIARITY WITH ITS OPERATION. THE USER COMMITS TO OPERATING OR RIDING ON EACH C.O.C.V. SAFELY, IN ACCORDANCE WITH THE LAW AND THEIR OWN CAPABILITIES, AND PLEDGES TO ADHERE TO ALL C.O.C.V. USER ELIGIBILITY AND PROGRAM RULES.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">16. Indemnity and Release</h2>
        <p class="text-gray-600 mb-4">
            The User ("Indemnifying Party") undertakes to, without reservation, defend, indemnify, and hold harmless the Company, its affiliates, subsidiaries, joint venture partners, and each of their respective employees, contractors, directors, suppliers, and representatives (collectively referred to as "Indemnified Parties") from and against any and all liabilities, losses, claims, damages, costs, and expenses, including but not limited to reasonable attorneys' fees, that may arise directly or indirectly from: (i) any loss of life, bodily injury, disability, or property damage, including damage to rented or subscribed vehicles, arising from or attributable to the use of the rented or subscribed vehicle (as the case may be); (ii) any act or omission characterized by negligence, wilful misconduct, or any form of misconduct on the part of the Indemnifying Party while operating the rented or subscribed vehicle (as the case may be); (iii) any utilization of the Platform or Services in contravention of applicable laws, regulations, or the stipulations of these Terms and Conditions; (iv) any participation in unlawful activities or violations of pertinent laws, encompassing traffic regulations, during the course of the rental or subscription period (as the case may be); (v) any breach of the Terms and Conditions; and (vi) any claims, disputes, or legal proceedings instituted by third parties in connection with or arising out of the Indemnifying Party's use of the rented or subscribed vehicle (as the case may be) or the Platform. We reserve the right to assume the exclusive defense and control of any matter otherwise subject to indemnification by you, in which event you will assist and cooperate with us in connection therewith.
        </p>
        <p class="text-gray-600 mb-4">
            THE USER, ON BEHALF OF THEMSELVES AND ALL HEIRS, PERSONAL REPRESENTATIVES, ADMINISTRATORS, EXECUTORS, SUCCESSORS, AND ASSIGNS (COLLECTIVELY REFERRED TO AS "HEIRS AND ASSIGNS"), HEREBY RELEASES, WAIVES, AND DISCHARGES THE COMPANY AND ALL AFFILIATED ENTITIES, OFFICERS, DIRECTORS, EMPLOYEES, DEALERS, DISTRIBUTORS, AND AGENTS (COLLECTIVELY REFERRED TO AS "RELEASED PARTIES"), FROM ANY AND ALL CLAIMS, DEMANDS, RIGHTS, AND CAUSES OF ACTION (COLLECTIVELY REFERRED TO AS "CLAIMS") ARISING FROM THE USER'S USE OF ANY C.O.C.V. THIS RELEASE COVERS ANY AND ALL CLAIMS THE USERS OR ANY HEIRS AND ASSIGNS HAVE OR LATER MAY HAVE AGAINST THE RELEASED PARTIES RESULTING FROM OR ARISING OUT OF THEIR OPERATION OR OF RIDING ON C.O.C.V.s INCLUDING WITHOUT LIMITATION, NEGLIGENCE, PRODUCT LIABILITY, WARRANTIES, KNOWN OR UNKNOWN, CONTINGENT OR ABSOLUTE, LIQUIDATED OR UNLIQUIDATED OR FORESEEN OR UNFORESEEN, OR ARISE BY OPERATION OF LAW OR OTHERWISE. THE USER AGREES NOT TO BRING ANY CLAIMS AGAINST THE RELEASED PARTIES FOR INJURIES OR DAMAGES. THIS RELEASE IS INTENDED TO BE AS BROAD AS PERMITTED BY LAW AND IS ENFORCEABLE TO THE MAXIMUM EXTENT POSSIBLE. THE USER ACKNOWLEDGES READING, UNDERSTANDING, AND HAVING THE OPPORTUNITY TO SEEK CLARIFICATION ON THIS RELEASE.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">17. Limitation of Liability</h2>
        <p class="text-gray-600 mb-4">
            TO THE FULLEST EXTENT PERMITTED UNDER LAW, IN NO EVENT SHALL COMPANY BE LIABLE WHETHER IN TORT (INCLUDING FOR NEGLIGENCE OR BREACH OF STATUTORY DUTY), CONTRACT, MISREPRESENTATION, RESTITUTION OR OTHERWISE FOR (I) ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL OR OTHER SUCH LOSS OR DAMAGE, INCLUDING BUT NOT LIMITED TO THOSE SUCH AS AND/OR RESULTING FROM LOSS OF PROFITS, LOSS OF BUSINESS, BUSINESS INTERRUPTION, COMPUTER FAILURE, LOSS OF BUSINESS INFORMATION, DEPLETION OF GOODWILL, LOSS OR CORRUPTION OF DATA OR INFORMATION, PURE ECONOMIC LOSS AND/OR SIMILAR LOSSES OR DAMAGES OF ANY KIND, HOWSOEVER ARISING IN CONNECTION WITH THESE TERMS, (II) FOR YOUR RELIANCE ON THE SERVICES (III) FOR ANY DIRECT DAMAGES EXCEEDING SIX MONTHS OF FEES/SUBSCRIPTION RECEIVED BY THE COMPANY (IV) FOR ANY MATTER BEYOND ITS OR THEIR REASONABLE CONTROL, EVEN IF USER HAS BEEN INFORMED IN ADVANCE OF THE POSSIBILITY OF SUCH DAMAGES.
        </p>
        <p class="text-gray-600 mb-4">
            THE LIMITATIONS OF THIS SECTION WILL NOT APPLY TO ANY LIABILITY THAT CANNOT BE EXCLUDED OR LIMITED BY LAW. Our licensors and service providers will have no liability of any kind under this Terms and Conditions. Unless such restriction is prohibited by applicable law, you may not bring any claim under this Terms and Conditions more than twelve (12) months after the cause of action arises.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">18. Exemptions to Limitation of Liability</h2>
        <p class="text-gray-600 mb-4">
            You further agree and confirm that Company shall not be responsible, in any manner whatsoever, for any delay/unavailability of Services or failure to meet its obligations under the Terms and Conditions, which may be caused, directly or indirectly, due to:
        </p>
        <ul class="list-roman ml-6 text-gray-600 mb-4">
            <li>your failure to cooperate;</li>
            <li>your unavailability and/or unresponsiveness;</li>
            <li>your failure to provide accurate and complete information;</li>
            <li>your failure to provide or facilitate the submission of information in timely manner;</li>
            <li>any event beyond Company’s reasonable control.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">19. Updates</h2>
        <p class="text-gray-600 mb-4">
            We reserve the right, at Our sole discretion, to change, modify, add or remove portions of these Terms of Services, at any time without any prior written notice to you. We suggest that you regularly check these Terms of Services to apprise yourself of any updates. Your continued use of the Platform following the posting of changes will mean that you accept and agree to the revisions. As long as you comply with these Terms of Services, we grant you a personal, non-exclusive, non-transferable, limited privilege to enter and use the Platform.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">20. Severability and Waiver</h2>
        <p class="text-gray-600 mb-4">
            If any of these terms should be determined to be illegal, invalid or otherwise unenforceable by reason of the laws of any state in which these terms are intended to be effective, then to the extent and within the jurisdiction which that term is illegal, invalid or unenforceable, it shall be severed and deleted and the remaining Terms of Services shall survive, remain in full force and effect and continue to be binding and enforceable. The failure of either party to exercise in any respect any right provided for herein shall not be deemed a waiver of any further rights hereunder.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">21. Force Majeure</h2>
        <p class="text-gray-600 mb-4">
            If the performance of the Party’s obligations hereunder is prevented, restricted or interfered with by reason of fire, or by epidemic or pandemic, or other casualty or accident; strike or labour disputes; war or other violence; or any act or condition beyond the reasonable control of the Parties, or an act of God (each a “Force Majeure Event”), then the Parties shall be excused from such performance to the extent of such prevention, restriction or interference; provided, however, that the Parties shall give prompt notice within a period of three (3) days from the date of occurrence of the Force Majeure Event and providing a description to the other Party of such Force Majeure Event in such notice, including a description, in reasonable specificity, of the cause of the Force Majeure Event and the likely duration of the impact or delay cause by the Force Majeure Event; and provided further that the Parties shall use reasonable efforts to avoid or remove such cause of non-performance and shall continue performance hereunder whenever such causes are removed.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">22. Relationship Between the User and Company</h2>
        <p class="text-gray-600 mb-4">
            Nothing in this Terms and Conditions shall be construed to create any relationship between Company and you other than that of a service provider and user. You do not have the authority to bind Company in any manner whatsoever.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">23. Non-Assignment</h2>
        <p class="text-gray-600 mb-4">
            These Terms are personal to you and you shall not assign or transfer or purport to assign or transfer the contract between you and us to any other person.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">24. Governing Law, Jurisdiction and Dispute Resolution</h2>
        <p class="text-gray-600 mb-4">
            These Terms of Use are governed by the laws of India. Any action, suit, or other legal proceeding, which is commenced to resolve any matter arising under or relating to this Platform, shall be subject to the jurisdiction of the courts at Bangalore.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">25. Entire Agreement</h2>
        <p class="text-gray-600 mb-4">
            The Terms and Conditions are the entire agreement and understanding between you and Company with respect to the Services and usage of Platform.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">26. Grievance Redressal Officer</h2>
        <p class="text-gray-600 mb-4">
            In furtherance of the Information Technology Act, 2000 (“IT Act”) and the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021 (“Intermediary Guidelines”) a grievance officer is appointed to ensure compliance with the IT Act and the Intermediary guidelines.
        </p>
        <p class="text-gray-600 mb-4">
            Any discrepancies or grievances with regard to content and or comment or breach of the Terms and Conditions shall be taken up with the designated Grievance Officer as mentioned below via in writing or through email signed with the electronic signature to:
        </p>
        <p class="text-gray-600 mb-4">
            <strong>Attention:</strong> Mr. Dipesh Lokare<br/>
            <strong>Email ID:</strong> <a href="mailto:support@rideaway.in" class="text-blue-600 hover:underline">support@rideaway.in</a><br/>
            <strong>Address:</strong> Sant Tukaram Chowk, Old RTO Office Road, Akola, Maharashtra.
        </p>
        <p class="text-gray-600 mb-4">
            The grievance officer shall revert to every complaint within 24 hours of receipt of the complaint. Further, the Company shall take best possible efforts to redress the complaint within 15 days of receipt of the complaint. Any suggestions by Company regarding use of the Services shall not be construed as a warranty.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">27. Support</h2>
        <p class="text-gray-600 mb-4">
            The Company offers an email, calling and in-app-based support system. In case you require any assistance or support, you may access support resources or contact our support by calling at <a href="tel:+919145103053" class="text-blue-600 hover:underline">+919145103053</a> or use the “Help and Support” function on the Platform or email at <a href="mailto:support@rideaway.in" class="text-blue-600 hover:underline">support@rideaway.in</a>. The Company provides 24x7 Support.
        </p>
        <p class="text-gray-600 mb-4">
            The User agrees and acknowledges that the Company shall address and attempt to resolve the complaint received in accordance with the standard policies and procedures adopted by the Company, the User’s disapproval/discontent with the outcome/mode of redressal shall not be deemed to mean non-redressal of the complaint by the Company. Any suggestions by Company regarding use of the Service shall not be construed as a warranty.
        </p>
        <p class="text-gray-600 mb-4">
            In furtherance of the Consumer Protection Act 2019 (“Consumer Protection Act”) and the Consumer Protection (E-Commerce) Rules 2020 (“E-Commerce Rules”) a nodal officer is appointed to ensure compliance with the Consumer Protection Act and the E-Commerce Rules.
        </p>
        <p class="text-gray-600 mb-4">
            The details of the grievance officer to which consumer grievances can be redressed are as follows:
        </p>
        <p class="text-gray-600 mb-4"> 
            <strong>Attention:</strong>
             Mr. Dipesh Lokare 
            <strong>Email ID:</strong> <a href="mailto:support@rideaway.in" class="text-blue-600 hover:underline">support@rideaway.in</a>
            <strong>Address:</strong> Sant Tukaram Chowk, Old RTO Office Road, Akola, Maharashtra.<br/>
            <strong>Designation of such officer:</strong> Chief Executive Officer (CEO)
        </p>
        <p class="text-gray-600 mb-4">
            The Company shall revert to every complaint within 48 hours of receipt of the complaint. Further, the Company shall take best possible efforts to redress the complaint within 30 days of receipt of the complaint. Any suggestions by Company regarding use of the Services shall not be construed as a warranty.
        </p>
        <p class="text-gray-600 mb-4">
            The User agrees and acknowledges that the Company shall address and attempt to resolve the complaint received in accordance with the standard policies and procedures adopted by the Company, the User’s disapproval/discontent with the outcome/mode of redressal shall not be deemed to mean non-redressal of the complaint by the Company. Any suggestions by Company regarding use of the Service shall not be construed as a warranty.
        </p>

        <h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-4">28. Contact</h2>
        <p class="text-gray-600 mb-4">
            If you have any questions regarding the Services or usage of the Platform, please contact the Company at <a href="mailto:support@rideaway.in" class="text-blue-600 hover:underline">support@rideaway.in</a>. Please note that for the purpose of validation, you shall be required to provide information (including, but not limited to contact number or registered mobile number, etc.) for the purpose of validation and taking your service request.
        </p>
    </div>
</Layout>
  );
};

export default TermsAndConditionPage;
