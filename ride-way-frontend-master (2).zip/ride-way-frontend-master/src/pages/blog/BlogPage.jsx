import Layout from "@/components/layout/Layout";
import BlogPostCard from "@/pages/blog/components/BlogCard";

const BlogPage = () => {
  return (
    <Layout>
      <BlogPostCard />
    </Layout>
  );
};

export default BlogPage;