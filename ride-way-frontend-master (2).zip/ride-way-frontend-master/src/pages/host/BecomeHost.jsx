import React, { useState } from "react";
import toast from "react-hot-toast";
import { useSignUpHostInitiateMutation } from "@/redux/slices/hostApiSlice";
import Layout from "../../components/layout/Layout";
import FAQItem from "../faq/FAQItem";

const BecomeHost = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    city: "",
    vehicleType: "Motorcycle",
    makeModel: "",
    registrationNumber: "",
    ownsVehicle: false,
  });

  const [aadhaarFile, setAadhaarFile] = useState(null);
  const [licenseFile, setLicenseFile] = useState(null);
  const [rcFile, setRcFile] = useState(null);
  const [insuranceFile, setInsuranceFile] = useState(null);
  const [pucFile, setPucFile] = useState(null);

  const [sendHostSignup, { isLoading }] = useSignUpHostInitiateMutation();

  const hostFaqs = [
    // your FAQ contents here ...
  ];

  // Handle normal text change
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    let newValue = value;

    // Restrict full name and city to letters/spaces
    if (name === "fullName" || name === "city") {
      newValue = value.replace(/[^A-Za-z\s]/g, "");
    }

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : newValue,
    }));
  };

  // Handle phone number input separately
  const handlePhoneChange = (e) => {
    let val = e.target.value.replace(/\D/g, ""); // keep digits only
    if (val.length <= 10) {
      setFormData((prev) => ({ ...prev, phone: val }));
    }
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];
    if (name === "aadhaar") setAadhaarFile(file);
    if (name === "license") setLicenseFile(file);
    if (name === "rc") setRcFile(file);
    if (name === "insurance") setInsuranceFile(file);
    if (name === "puc") setPucFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (step === 1) {
      // Validate phone number length
      if (formData.phone.length !== 10) {
        toast.error("Phone number must be exactly 10 digits");
        return;
      }
      setStep(2);
      return;
    }

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      data.append(key, value);
    });

    if (!aadhaarFile || !licenseFile || !rcFile || !insuranceFile || !pucFile) {
      toast.error("All documents are required.");
      return;
    }

    data.append("aadhaar", aadhaarFile);
    data.append("license", licenseFile);
    data.append("rc", rcFile);
    data.append("insurance", insuranceFile);
    data.append("puc", pucFile);

    try {
      const res = await sendHostSignup(data).unwrap();
      toast.success(res?.message || "Host registered successfully!");
      // reset form
      setFormData({
        fullName: "",
        phone: "",
        email: "",
        city: "",
        vehicleType: "Motorcycle",
        makeModel: "",
        registrationNumber: "",
        ownsVehicle: false,
      });
      setStep(1);
    } catch (err) {
      toast.error(err?.data?.error || "Failed to register. Please try again.");
    }
  };

  return (
    <Layout>
      <div className="min-h-screen flex flex-col px-4 py-10 sm:px-6 lg:px-8">
        <div className="w-full max-w-6xl mx-auto flex flex-col lg:flex-row bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="w-full lg:w-1/2 p-4 sm:p-6 lg:p-8">
            <form
              onSubmit={handleSubmit}
              className="space-y-4 sm:space-y-6"
              encType="multipart/form-data"
            >
              <h2 className="text-2xl sm:text-3xl font-bold text-center text-gray-800">
                {step === 1 ? "Join as a Host" : "Upload Documents"}
              </h2>

              {step === 1 ? (
                <div className="grid grid-cols-1 gap-3 sm:gap-4 md:grid-cols-2">
                  <Input
                    label="Full Name*"
                    name="fullName"
                    type="text"
                    value={formData.fullName}
                    onChange={handleChange}
                  />
                  <div>
                    <Input
                      label="Phone Number*"
                      name="phone"
                      type="text"
                      value={formData.phone}
                      onChange={handlePhoneChange}
                    />
                    {/* Optional: show message if >0 and not complete */}
                    {formData.phone && formData.phone.length < 10 && (
                      <p className="text-xs text-red-600 mt-1">
                        Phone number must be exactly 10 digits
                      </p>
                    )}
                  </div>
                  <Input
                    label="Email*"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  <Input
                    label="City*"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                  />
                  <Select
                    label="Vehicle Type*"
                    name="vehicleType"
                    value={formData.vehicleType}
                    onChange={handleChange}
                    options={["Motorcycle", "Scooter"]}
                  />
                  <Input
                    label="Make & Model*"
                    name="makeModel"
                    value={formData.makeModel}
                    onChange={handleChange}
                  />
                  <Input
                    label="Registration Number*"
                    name="registrationNumber"
                    value={formData.registrationNumber}
                    onChange={handleChange}
                  />
                  <div className="col-span-1 md:col-span-2">
                    <label className="flex items-center space-x-2 sm:space-x-3">
                      <input
                        type="checkbox"
                        name="ownsVehicle"
                        checked={formData.ownsVehicle}
                        onChange={handleChange}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">
                        I confirm I own the vehicle and agree to be contacted by
                        RideAway regarding hosting.*
                      </span>
                    </label>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:gap-4">
                  <FileUpload
                    label="Upload Aadhaar Card*"
                    name="aadhaar"
                    onChange={handleFileChange}
                  />
                  <FileUpload
                    label="Upload Driving License*"
                    name="license"
                    onChange={handleFileChange}
                  />
                  <FileUpload
                    label="Upload Registration Certificate (RC)*"
                    name="rc"
                    onChange={handleFileChange}
                  />
                  <FileUpload
                    label="Upload Insurance Document*"
                    name="insurance"
                    onChange={handleFileChange}
                  />
                  <FileUpload
                    label="Upload PUC Certificate*"
                    name="puc"
                    onChange={handleFileChange}
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2 sm:py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300 font-semibold text-base sm:text-lg"
              >
                {isLoading ? "Submitting..." : step === 1 ? "Next" : "Join Us!"}
              </button>
            </form>
          </div>

          <div
            className="w-full h-48 sm:h-64 lg:h-auto lg:w-1/2 bg-cover bg-center bg-no-repeat lg:block"
            style={{
              backgroundImage: `url('/images/key-bike.png')`,
            }}
          ></div>
        </div>

        {/* FAQ Section */}
        <div className="bg-gray-50 py-8 sm:py-12 px-4 mt-8 sm:mt-10">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 text-center mb-4 sm:mb-6">
              Host Frequently Asked Questions
            </h2>
            <div className="bg-white rounded-2xl shadow-lg divide-y divide-gray-200 overflow-hidden">
              {hostFaqs.map((faq) => (
                <FAQItem key={faq.question} question={faq.question} answer={faq.answer} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

const Input = ({ label, name, value, onChange, type = "text" }) => (
  <div className="space-y-1">
    <label className="block text-sm font-medium text-gray-700">{label}</label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      className="w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm sm:text-base"
      required
    />
  </div>
);

const Select = ({ label, name, value, onChange, options }) => (
  <div className="space-y-1">
    <label className="block text-sm font-medium text-gray-700">{label}</label>
    <select
      name={name}
      value={value}
      onChange={onChange}
      className="w-full px-3 sm:px-4 py-2 sm:py-2.5 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm sm:text-base"
    >
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);

const FileUpload = ({ label, name, onChange }) => (
  <div className="space-y-1">
    <label className="block text-sm font-medium text-gray-700">{label}</label>
    <input
      type="file"
      name={name}
      accept=".jpg,.jpeg,.png,.pdf"
      onChange={onChange}
      className="w-full text-sm text-gray-700 file:bg-blue-600 file:text-white file:border-0 file:px-3 sm:file:px-4 file:py-2 sm:file:py-2.5 file:rounded-md file:cursor-pointer"
      required
    />
  </div>
);

export default BecomeHost;
