import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { LoaderIcon } from "lucide-react";
import { useVerifyPaymentMutation } from "@/redux/slices/paymentApiSlice";

const PaymentResult = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // --- START: CORRECTED CODE ---
  const queryParams = new URLSearchParams(location.search);
  const razorpay_payment_id = queryParams.get("razorpay_payment_id");
  const razorpay_payment_link_id = queryParams.get("razorpay_payment_link_id");
  const razorpay_signature = queryParams.get("razorpay_signature");
  // Get the reference ID and status from the URL
  const razorpay_payment_link_reference_id = queryParams.get("razorpay_payment_link_reference_id");
  const razorpay_payment_link_status = queryParams.get("razorpay_payment_link_status");
  // --- END: CORRECTED CODE ---

  const [verifyPayment, { isLoading, isSuccess, isError, error, data }] = useVerifyPaymentMutation();
  const [verificationAttempted, setVerificationAttempted] = useState(false);

  useEffect(() => {
    // Check for all necessary parameters before proceeding
    if (
      razorpay_payment_id &&
      razorpay_payment_link_id &&
      razorpay_signature &&
      razorpay_payment_link_reference_id &&
      razorpay_payment_link_status &&
      !verificationAttempted
    ) {
      setVerificationAttempted(true);

      // --- START: CORRECTED CODE ---
      // Send the complete payload to the backend
      verifyPayment({
        razorpay_payment_id,
        razorpay_payment_link_id,
        razorpay_signature,
        razorpay_payment_link_reference_id,
        razorpay_payment_link_status,
      }).catch((err) => {
        // This catch is for uncaught exceptions in the mutation call itself,
        // the `isError` flag will handle API errors.
        console.error("Verification promise rejected:", err);
      });
      // --- END: CORRECTED CODE ---
    }
  // It's good practice to include all dependencies for the effect
  }, [
      verificationAttempted,
      verifyPayment,
      razorpay_payment_id,
      razorpay_payment_link_id,
      razorpay_signature,
      razorpay_payment_link_reference_id,
      razorpay_payment_link_status
  ]);


  // ... rest of your component logic remains the same ...
  // (The renderMessage and JSX part is perfectly fine)
  
  const renderMessage = () => {
    if (isLoading) {
      return (
        <div className="flex items-center gap-2 text-gray-600">
          <LoaderIcon className="animate-spin" />
          <span>Verifying Payment...</span>
        </div>
      );
    }

    if (!razorpay_payment_id || !razorpay_signature) {
      return (
        <h2 className="text-yellow-600 text-xl font-semibold">
          Payment Was Cancelled or Failed.
        </h2>
      );
    }

    if (isError) {
      const msg = error?.data?.error || "Verification failed.";
      return (
        <h2 className="text-red-600 text-xl font-semibold">
          ❌ {msg}
        </h2>
      );
    }

    if (isSuccess && data?.message) {
      return (
        <h2 className="text-blue-600 text-xl font-semibold">
          ✅ {data.message}
        </h2>
      );
    }

    return (
      <h2 className="text-gray-600 text-xl font-semibold">
        Processing your payment...
      </h2>
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="bg-white shadow-md rounded-xl p-8 text-center max-w-md w-full">
        <h1 className="text-2xl font-bold mb-4">Payment Status</h1>
        {renderMessage()}
        <button
          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => navigate("/")}
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};

export default PaymentResult;