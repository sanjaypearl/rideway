import ShopOwnerLayout from "../../../components/dashboard/shopOwner/ShopOwnerLayout"

const ShopOwnerDashboard = () => {
  return (
    <ShopOwnerLayout></ShopOwnerLayout>
  )
}

export default ShopOwnerDashboard