import ViewVehicle from "../../../../components/common/shopOwner/ViewVehicle"

const ShopOwnerViewVehicle = () => {
  return (
    <div>
        <ViewVehicle/>
    </div>
  )
}

export default ShopOwnerViewVehicle