import Settlements from "../../../../components/common/shopOwner/settlements/Settlements"

const ShopOwnerSettelementPage = () => {
  return (
    <div>
        <Settlements/>
    </div>
  )
}

export default ShopOwnerSettelementPage