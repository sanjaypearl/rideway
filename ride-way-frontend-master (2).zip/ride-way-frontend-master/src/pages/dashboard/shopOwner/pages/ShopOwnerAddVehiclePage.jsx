import AddVehicle from "../../../../components/common/shopOwner/AddVehicle"

const ShopOwnerAddVehiclePage = () => {
  return (
    <div>
        <AddVehicle/>
    </div>
  )
}

export default ShopOwnerAddVehiclePage