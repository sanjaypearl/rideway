import UserProfile from "../../../../components/common/userProfile/UserProfile"

const UserProfilePage = () => {
  return (
    <div>
      <UserProfile/>
    </div>
  )
}

export default UserProfilePage