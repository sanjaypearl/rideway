import ViewAndAddRoleAndDepartment from "../../../../components/common/viewAndAddRoleAndDepartment/ViewAndAddRoleAndDepartment"

const SuperAdminAddRoleAndView = () => {
  return (
    <div>
        <ViewAndAddRoleAndDepartment/>
    </div>
  )
}

export default SuperAdminAddRoleAndView