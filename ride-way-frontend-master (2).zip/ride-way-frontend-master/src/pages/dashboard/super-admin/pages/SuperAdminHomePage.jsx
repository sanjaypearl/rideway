import SuperAdminHomeDashboard from "../../../../components/common/superAdmin/superAdminHomedashboard/SuperAdminHomeDashboard"

const SuperAdminHomePage = () => {
  return (
    <div>
      <SuperAdminHomeDashboard/>
    </div>
  )
}

export default SuperAdminHomePage