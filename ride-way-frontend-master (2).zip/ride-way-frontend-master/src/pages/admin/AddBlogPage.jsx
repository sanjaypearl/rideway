import React, { useState } from "react";
import { Button, Input } from "@material-tailwind/react";
import { toast } from "react-hot-toast";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import Quill styles
import {
  useGetBlogsForAdminQuery,
  useAddBlogMutation,
  useEditBlogMutation,
  useDeleteBlogMutation,
} from "@/redux/slices/blogApi";

const AddBlogPage = () => {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    author: "Admin",
    thumbnail: null,
  });
  const [editId, setEditId] = useState(null);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const limit = 10;

  const { data, isLoading, error } = useGetBlogsForAdminQuery({ search, page, limit });
  const [addBlog, { isLoading: isAdding }] = useAddBlogMutation();
  const [editBlog, { isLoading: isEditing }] = useEditBlogMutation();
  const [deleteBlog] = useDeleteBlogMutation();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleContentChange = (value) => {
    setFormData({ ...formData, content: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, thumbnail: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.content || formData.content === "<p><br></p>") {
      toast.error("Title and content are required.");
      return;
    }
    if (!editId && !formData.thumbnail) {
      toast.error("Thumbnail is required for new blogs.");
      return;
    }

    try {
      if (editId) {
        await editBlog({ id: editId, blogData: formData }).unwrap();
        setEditId(null);
      } else {
        await addBlog(formData).unwrap();
      }
      setFormData({ title: "", content: "", author: "Admin", thumbnail: null });
      document.getElementById("thumbnail-input").value = null; // Reset file input
    } catch (err) {
      console.error(err);
      toast.error(err?.data?.error || "Failed to save blog");
    }
  };

  const handleEdit = (blog) => {
    setFormData({
      title: blog.title,
      content: blog.content,
      author: blog.author,
      thumbnail: null,
    });
    setEditId(blog._id);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this blog?")) {
      try {
        await deleteBlog(id).unwrap();
      } catch (err) {
        console.error(err);
        toast.error(err?.data?.error || "Failed to delete blog");
      }
    }
  };

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(1);
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  // React Quill toolbar configuration
  const quillModules = {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image"],
      ["clean"],
    ],
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Manage Blogs</h1>

      {/* Blog Form */}
      <form onSubmit={handleSubmit} className="mb-8 bg-white p-6 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <Input
            label="Blog Title"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            required
          />
          <Input
            label="Author"
            name="author"
            value={formData.author}
            onChange={handleInputChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 mb-2">Content</label>
          <ReactQuill
            value={formData.content}
            onChange={handleContentChange}
            modules={quillModules}
            theme="snow"
            className="bg-white"
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 mb-2">Thumbnail</label>
          <input
            id="thumbnail-input"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="w-full p-2 border rounded"
          />
        </div>
        <Button
          type="submit"
          disabled={isAdding || isEditing}
          className="bg-gradient-to-r from-blue-500 to-blue-500 hover:from-blue-600 hover:to-blue-600 text-white rounded-full py-2"
        >
          {editId ? "Update Blog" : "Add Blog"}
        </Button>
      </form>

      {/* Search and Blog List */}
      <div className="mb-6">
        <Input
          label="Search Blogs"
          value={search}
          onChange={handleSearch}
          className="mb-4"
        />
        {isLoading && <p>Loading...</p>}
        {error && <p className="text-red-500">Error loading blogs.</p>}
        {data && data.blogs?.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {data.blogs.map((blog) => (
              <div
                key={blog._id}
                className="bg-white p-4 rounded-lg shadow-md flex items-center justify-between"
              >
                <div>
                  <h3 className="text-lg font-semibold">{blog.title}</h3>
                  <p className="text-gray-600">By {blog.author}</p>
                  <p className="text-gray-500 text-sm">
                    {new Date(blog.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => handleEdit(blog)}
                    className="bg-blue-500 hover:bg-blue-600 text-white rounded-full py-1 px-4"
                  >
                    Edit
                  </Button>
                  <Button
                    onClick={() => handleDelete(blog._id)}
                    className="bg-red-500 hover:bg-red-600 text-white rounded-full py-1 px-4"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No blogs found.</p>
        )}
      </div>

      {/* Pagination */}
      {data && data.totalBlogs > limit && (
        <div className="flex justify-center space-x-2">
          <Button
            disabled={page === 1}
            onClick={() => handlePageChange(page - 1)}
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-full py-1 px-4"
          >
            Previous
          </Button>
          <span className="self-center">Page {page}</span>
          <Button
            disabled={page * limit >= data.totalBlogs}
            onClick={() => handlePageChange(page + 1)}
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-full py-1 px-4"
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
};

export default AddBlogPage;