import { useState } from "react";
import { useGetAllContactsQuery } from "../../redux/slices/contactApiSlice";
import Layout from "@/components/layout/Layout";
import { Spinner } from "@material-tailwind/react";

const AllContactsPage = () => {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const limit = 10;

  // correct: pass the params
  const { data, isLoading, error } = useGetAllContactsQuery({
    search,
    page,
    limit,
  });

  const totalPages = Math.ceil(data?.total / limit) || 1;

  const handleSearchChange = (e) => {
    setPage(1);
    setSearch(e.target.value);
  };

  return (
    <Layout>
      <section className="px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">All Contact Messages</h1>

        {/* Search input */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search by name/email/message"
            value={search}
            onChange={handleSearchChange}
            className="px-3 py-2 border rounded w-full md:w-1/3"
          />
        </div>

        {isLoading ? (
          <div className="flex justify-center py-10">
            <Spinner className="h-10 w-10 text-blue-500" />
          </div>
        ) : error ? (
          <div className="text-center text-red-500">
            {error?.data?.error || "Failed to fetch contacts"}
          </div>
        ) : (
          <>
            {/* Table */}
            <div className="overflow-auto">
              <table className="min-w-full border border-gray-200 rounded-lg overflow-hidden text-sm">
                <thead className="bg-gray-100 font-semibold text-gray-700">
                  <tr>
                    <th className="p-3 text-left">Name</th>
                    <th className="p-3 text-left">Email</th>
                    <th className="p-3 text-left">Message</th>
                    <th className="p-3 text-left">Date</th>
                  </tr>
                </thead>
                <tbody className="text-gray-700">
                  {data?.contacts?.length > 0 ? (
                    data.contacts.map((contact) => (
                      <tr key={contact._id} className="border-t">
                        <td className="p-3">{contact.name}</td>
                        <td className="p-3">{contact.email}</td>
                        <td className="p-3">{contact.message}</td>
                        <td className="p-3">
                          {new Date(contact.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4" className="p-4 text-center text-gray-500">
                        No contacts found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center mt-6 gap-2">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`px-3 py-1 border rounded ${
                      p === page ? "bg-indigo-500 text-white" : "bg-white"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </Layout>
  );
};

export default AllContactsPage;
