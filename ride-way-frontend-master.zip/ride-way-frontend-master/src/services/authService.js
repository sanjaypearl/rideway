const TOKEN_KEY = "token";
const USER_KEY  = "user";

/* ---------- low‑level helpers ---------- */
const saveToken   = (token) => localStorage.setItem(TOKEN_KEY, token);
const removeToken = ()       => localStorage.removeItem(TOKEN_KEY);
const getToken    = ()       => localStorage.getItem(TOKEN_KEY);

/* Decode JWT payload safely */
const parseJwt = (token) => {
  if (!token) return null;

  try {
    const base64Url = token.split(".")[1];
    const base64    = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const json      = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join("")
    );
    return JSON.parse(json);
  } catch (e) {
    console.error("Failed to parse JWT", e);
    return null;
  }
};

/* ---------- public API ---------- */
const setUser = (userFromServer = null, token) => {
  if (!token) throw new Error("setUser: token missing");

  /* persist token */
  saveToken(token);

  /* decide where to take user data from */
  const user = userFromServer || parseJwt(token);
  if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));

  return user;
};

const getCurrentUser = () => {
  const token = getToken();
  if (!token) return null;

  /* try to read cached user first */
  const cached = localStorage.getItem(USER_KEY);
  return cached ? JSON.parse(cached) : parseJwt(token);
};

const logout = () => {
  removeToken();
  localStorage.removeItem(USER_KEY);
};

export default {
  setUser,
  getCurrentUser,
  logout,
  getToken,
};
