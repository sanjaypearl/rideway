import MoreButton from "../../common/moreButton/MoreButton";

function ShopOwnerRightNavbar() {

    return (
        <div className=''>
            <div className="rounded-none border-b bg-green-50 border-green-300 border-t-0 border-l-0 border-r-0">
                <div className="flex justify-end px-2 py-3.5">
                </div>
            </div>
        </div>
    );
}

export default ShopOwnerRightNavbar;