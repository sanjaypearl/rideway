import { FiMapPin, FiMail, FiPhone, FiMessageCircle } from "react-icons/fi";
import { FaApple, FaGooglePlay } from "react-icons/fa";

const cities = ["Pune", "Vadodara ", "Dombivli", "Akola", "indore"];

export default function Footer() {
  return (
    <footer className="relative text-gray-800 bg-white drop-shadow-md shadow-black">
      {/* Removed dark overlay */}

      <div className="mx-auto w-full max-w-7xl px-6 py-12">
        {/* logo */}
        <div className="flex justify-center pb-10">
          <img
            src="/logo/logo.png"
            alt="Rideaway Rentals"
            className="h-20 w-auto"
          />
        </div>

        {/* columns */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* COMPANY */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              COMPANY
            </h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <a href="/about" className="hover:text-teal-600">
                  About Us
                </a>
              </li>
              <li>
                <a href="/blog" className="hover:text-teal-600">
                  Blogs
                </a>
              </li>
              <li>
                <a href="/faq" className="hover:text-teal-600">
                  FAQ’s
                </a>
              </li>
            </ul>
          </div>

          {/* SUPPORT */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              RIDEAWAY SUPPORT
            </h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <FiMail className="text-teal-600" />
                <a
                  href="mailto:contact@rideaway.in"
                  className="hover:text-teal-600"
                >
                  contact@rideaway.in
                </a>
              </li>
              <li className="flex items-center gap-2">
                <FiPhone className="text-teal-600" />
                <a href="tel:+91 9145103053" className="hover:text-teal-600">
                  +91 9145103053
                </a>
              </li>
              <li className="flex items-center gap-2">
                <FiMessageCircle className="text-teal-600" />
                <a
                  href="https://wa.me/9145103053" // Replace with your number in international format
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600"
                >
                  Chat With Us
                </a>
              </li>
            </ul>
          </div>

          {/* POLICIES */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              POLICIES
            </h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <a href="/privacy-policy" className="hover:text-teal-600">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms-and-condition" className="hover:text-teal-600">
                  Terms &amp; Conditions
                </a>
              </li>
            </ul>
          </div>

          {/* CONTACT US */}
          <div>
            <h4 className="mb-4 font-semibold tracking-wider text-gray-900">
              CONTACT US
            </h4>
            <address className="not-italic text-sm text-gray-600">
              RideAway,
              <br />
              Shop No.2 , Shree Swami Krupa , Hingane Home Colony, Karve nagar,
              Pune, Maharashtra 411052
            </address>
            <a
              href="/contact"
              className="mt-4 inline-block text-teal-600 hover:text-teal-700 hover:underline"
            >
              Get In Touch
            </a>
          </div>
        </div>

        {/* divider */}
        <div className="my-10 h-px w-full bg-gray-300" />

        {/* cities */}
        <h4 className="mb-6 text-center text-lg font-semibold underline decoration-teal-600/60 underline-offset-4 text-gray-900">
          RIDEAWAY  CITIES
        </h4>
        <ul className="mx-auto grid max-w-4xl grid-cols-[repeat(auto-fit,_minmax(160px,_1fr))] gap-y-3 text-sm text-gray-600">
          {cities.map((city) => (
            <li key={city} className="flex items-center gap-1">
              <FiMapPin className="text-teal-600" />
              <a
                href={`/bike-rent-in-${city.toLowerCase()}`}
                className="hover:text-teal-600 hover:underline"
              >
                Bike rent in <span className="font-semibold">{city}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </footer>
  );
}
