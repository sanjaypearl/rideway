import React, { useContext, useState } from "react";
import AllVehicle from "./AllVehicle";
import myContext from "../../context/myContext";

export default function Vehicle() {
  const [activeTab, setActiveTab] = useState("");
  const [selectedDuration, setSelectedDuration] = useState(1); // default: 1 day

  const { vehicleType, setVehicleType } = useContext(myContext);

  const vehicleData = [
    { label: "All", value: "" },
    { label: "Scooty", value: "scooty" },
    { label: "Bike", value: "bike" },
  ];

  const durations = [
    { label: "1 Day", value: 1 },
    { label: "2 Days", value: 2 },
    { label: "3 Days", value: 3 },
    { label: "4 Days", value: 4 },
    { label: "5 Days", value: 5 },
    { label: "6 Days", value: 6 },
    { label: "7 Days", value: 7 },
    { label: "1 Week", value: 7 },
    { label: "1 Month", value: 30 },
    { label: "3 Months", value: 90 },
    { label: "6 Months", value: 180 },
    { label: "1 Year", value: 365 },
  ];

  return (
    <div className="px-4 mt-5">
      <div className="mb-8">
        <h1 className="text-center app-font text-2xl font-bold">
          Renting Fleet
        </h1>
      </div>

      <div className="container mx-auto flex flex-row justify-center items-center gap-4 flex-wrap">
        {/* Tab Headers */}
        <div className="flex w-[400px] border-b border-blue-gray-50">
          {vehicleData.map(({ label, value }) => (
            <button
              key={value}
              className={`flex-1 py-2 text-center transition-all duration-200 ${
                activeTab === value
                  ? "border-b-4 border-[#82BE23] text-gray-900 font-bold"
                  : "text-gray-600 hover:text-gray-800"
              }`}
              onClick={() => {
                setActiveTab(value);
                setVehicleType(value);
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Duration Selector */}
        <div className="flex w items-center gap-2">
          <label htmlFor="duration" className="text-sm font-medium text-gray-700">
            Select Duration:
          </label>
          <select
            id="duration"
            value={selectedDuration}
            onChange={(e) => setSelectedDuration(Number(e.target.value))}
            className="border rounded px-3 py-1 text-sm"
          >
            {durations.map(({ label, value }) => (
              <option key={value + label} value={value}>
                {label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Vehicle List */}
      <div className="mt-4 px-2">
        <AllVehicle vehicleType={vehicleType} selectedDuration={selectedDuration} />
      </div>
    </div>
  );
}
