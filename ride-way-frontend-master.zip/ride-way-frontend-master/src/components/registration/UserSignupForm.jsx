import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { Button, Input, Radio } from "@material-tailwind/react";
import {
  useSendSignUpOtpMutation,
  useVerifySignUpOtpMutation,
} from "../../redux/slices/userApi";

/* ─────────── Constants ─────────── */
const GENDERS = ["Male", "Female", "Other"];
const FORM_FIELDS = [
  { name: "userName", label: "Full Name *", type: "text" },
  { name: "userEmail", label: "Email *", type: "email" },
  {
    name: "userPhoneNumber",
    label: "Mobile Number *",
    type: "tel",
    maxLength: 10,
  },
];

/* ─────────── Feedback Message ─────────── */
const FeedbackMessage = ({ message, type }) => {
  if (!message) return null;
  const color = type === "error" ? "text-red-600" : "text-green-600";
  return <p className={`text-center text-sm ${color}`}>{message}</p>;
};
FeedbackMessage.propTypes = {
  message: PropTypes.string,
  type: PropTypes.oneOf(["error", "success"]).isRequired,
};

/* ─────────── Main Component ─────────── */
const UserSignupForm = ({ switchToLogin }) => {
  const [formData, setFormData] = useState({
    userName: "",
    userEmail: "",
    userPhoneNumber: "",
    gender: "",
    otp: "",
  });

  const [step, setStep] = useState(1);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const [
    sendOtp,
    { isLoading: isSendingOtp, isError: isSendOtpError, error: sendOtpError },
  ] = useSendSignUpOtpMutation();

  const [
    verifyOtp,
    {
      isLoading: isVerifyingOtp,
      isError: isVerifyError,
      isSuccess: isVerifySuccess,
      error: verifyError,
    },
  ] = useVerifySignUpOtpMutation();

  const handleChange = (field) => (e) => {
    setFormData((prev) => ({ ...prev, [field]: e.target.value }));
    setErrorMessage("");
  };

  const handleInitialSignup = async () => {
    try {
      await sendOtp(formData).unwrap();
      setSuccessMessage("OTP sent successfully. Please enter it to continue.");
      setStep(2);
    } catch (err) {
      setErrorMessage(err?.data?.error || "Failed to send OTP.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (step === 1) return handleInitialSignup();

    try {
      await verifyOtp({
        userPhoneNumber: formData.userPhoneNumber,
        otp: formData.otp,
      }).unwrap();

      setSuccessMessage("Signup successful!");
      const timer = setTimeout(() => switchToLogin(), 1500);
      return () => clearTimeout(timer);
    } catch (err) {
      setErrorMessage(err?.data?.error || "OTP verification failed.");
    }
  };

  useEffect(() => {
    if (isSendOtpError)
      setErrorMessage(sendOtpError?.data?.error || "Failed to send OTP.");
    if (isVerifyError)
      setErrorMessage(verifyError?.data?.error || "OTP verification failed.");
  }, [isSendOtpError, isVerifyError]);

  useEffect(() => {
    if (isVerifySuccess) {
      setSuccessMessage("Signup successful!");
      const t = setTimeout(() => switchToLogin(), 1500);
      return () => clearTimeout(t);
    }
  }, [isVerifySuccess]);

  const isFormValid =
    formData.userName &&
    formData.userEmail &&
    formData.userPhoneNumber &&
    formData.gender;

  const isOtpValid = formData.otp && formData.otp.length === 6;

  const isSubmitDisabled =
    (step === 1 && (!isFormValid || isSendingOtp)) ||
    (step === 2 && (!isOtpValid || isVerifyingOtp));

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <FeedbackMessage message={errorMessage} type="error" />
      <FeedbackMessage message={successMessage} type="success" />

      {/* Step 1: Details */}
      {step === 1 &&
        FORM_FIELDS.map(({ name, label, type, maxLength }) => (
          <Input
            key={name}
            name={name}
            label={label}
            type={type}
            color="green"
            maxLength={maxLength}
            value={formData[name]}
            onChange={handleChange(name)}
          />
        ))}

      {step === 1 && (
        <div className="flex items-center gap-6">
          <div className="text-sm font-medium">
            <span>Gender</span>
            <span className="text-red-500 ml-1">*</span>
          </div>
          {GENDERS.map((g) => (
            <Radio
              key={g}
              label={g}
              name="gender"
              value={g}
              color="green"
              checked={formData.gender === g}
              onChange={handleChange("gender")}
            />
          ))}
        </div>
      )}

      {/* Step 2: OTP */}
      {step === 2 && (
        <Input
          label="Enter OTP *"
          color="green"
          type="text"
          maxLength={6}
          value={formData.otp}
          onChange={handleChange("otp")}
        />
      )}

      {/* Terms notice */}
      {step === 1 && (
        <p className="text-xs text-gray-600 text-center leading-relaxed">
          By signing up, I accept the{" "}
          <a
            href="/terms-and-condition"
            target="_blank"
            rel="noopener noreferrer"
            className="text-green-600 underline hover:text-green-800"
          >
            Terms & Conditions
          </a>{" "}
          &{" "}
          <a
            href="/privacy-policy"
            target="_blank"
            rel="noopener noreferrer"
            className="text-green-600 underline hover:text-green-800"
          >
            Privacy Policy
          </a>
          .
        </p>
      )}

      <Button
        type="submit"
        disabled={isSubmitDisabled}
        className="w-full bg-green-400 shadow-none hover:shadow-none"
      >
        {step === 1
          ? isSendingOtp
            ? "Sending OTP..."
            : "Sign UP"
          : isVerifyingOtp
          ? "Verifying..."
          : "Verify & Complete Sign Up"}
      </Button>

      <p className="pt-2 text-center text-sm">
        ALREADY HAVE AN ACCOUNT?{" "}
        <span
          onClick={switchToLogin}
          className="cursor-pointer font-bold text-green-400"
        >
          SIGN IN
        </span>
      </p>
    </form>
  );
};

UserSignupForm.propTypes = {
  switchToLogin: PropTypes.func.isRequired,
};

export default UserSignupForm;
