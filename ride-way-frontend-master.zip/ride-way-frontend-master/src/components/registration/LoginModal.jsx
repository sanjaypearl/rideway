import { useState, useEffect, useContext } from "react";
import { Button, Dialog } from "@material-tailwind/react";
import { X } from "lucide-react";
import myContext from "../../context/myContext";
import LoginForm from "./LoginForm";
import UserSignupForm from "./UserSignupForm";
import ForgotPassword from "./ForgotPassword";

export default function LoginModal({ autoOpen = false, showLoginButton = true }) {
  const { setAutoOpenLogin } = useContext(myContext);
  const [open, setOpen] = useState(autoOpen);
  const [dialogSize, setSize] = useState("lg");

  const [auth, setAuth] = useState({
    isSignup: false,
    isForgotPassword: false,
  });

  const toggleOpen = () => setOpen(!open);
  const handleAutoClose = () => setAutoOpenLogin(false);

  const switchToSignup = () =>
    setAuth({ isSignup: true, isForgotPassword: false });

  const switchToLogin = () =>
    setAuth({ isSignup: false, isForgotPassword: false });

  const switchToForgotPassword = () =>
    setAuth({ isSignup: false, isForgotPassword: true });

  useEffect(() => {
    if (autoOpen) setOpen(true);
    const updateSize = () => setSize(window.innerWidth < 768 ? "xxl" : "lg");
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, [autoOpen]);

  const renderRight = () => {
    if (auth.isForgotPassword) {
      return <ForgotPassword switchToLogin={switchToLogin} />;
    }

    if (auth.isSignup) {
      return <UserSignupForm switchToLogin={switchToLogin} />;
    }

    return (
      <LoginForm
        switchToSignup={switchToSignup}
        switchToForgotPassword={switchToForgotPassword}
        handleClose={() => {
          toggleOpen();
          handleAutoClose();
        }}
      />
    );
  };

  const headerText = auth.isSignup ? "SIGN UP" : "SIGN IN";

  return (
    <>
      {showLoginButton && !autoOpen && (
        <>
          <p onClick={toggleOpen} className="hidden lg:block text-black">
            <span className="px-8 py-3 text-[10px] font-semibold text-white bg-gradient-to-r from-blue-400 to-green-400 rounded-sm cursor-pointer">
              SIGN IN
            </span>
          </p>
          <Button onClick={toggleOpen} className="lg:hidden bg-green-500">
            SIGN IN 
          </Button>
        </>
      )}

      <Dialog
        open={open}
        handler={toggleOpen}
        size={dialogSize}
        className="rounded-none shadow-none"
      >
        <div className="flex items-center">
          {/* Left side image */}
          <div className="hidden lg:flex w-[40em] h-[33em] items-center justify-center">
            <img
              src={
                auth.isSignup
                  ? "https://img.freepik.com/free-vector/placeholder-concept-illustration_114360-4847.jpg"
                  : "https://img.freepik.com/free-vector/tablet-login-concept-illustration_114360-7893.jpg"
              }
              alt={auth.isSignup ? "signup" : "login"}
            />
          </div>

          {/* Right side form */}
          <div className="relative w-[42em] h-screen lg:h-[33em] bg-green-50/50 p-5 lg:p-10">
            <div
              className="absolute top-0 right-0 p-2 cursor-pointer bg-green-50"
              onClick={() => {
                toggleOpen();
                handleAutoClose();
              }}
            >
              <X size={20} className="text-green-300 hover:text-green-400" />
            </div>

            <div className="flex justify-center mt-10 mb-0 pt-32 lg:pt-0 text-2xl">
              {headerText}
            </div>

            <div className="py-10">{renderRight()}</div>
          </div>
        </div>
      </Dialog>
    </>
  );
}
