/* eslint-disable no-unused-vars */
import { ArrowPathIcon, ListBulletIcon, TableCellsIcon } from "@heroicons/react/24/outline";
import {
    Input,
    Typography,
    Button,
    Spinner,
    Chip,
} from "@material-tailwind/react";
import { useEffect, useState } from "react";
import { Store } from "lucide-react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { useNavigate, useParams } from "react-router-dom";
import { useGetOrdersByShopQuery } from "../../../../redux/slices/orderApiSlice";
import SettelementModal from "./modal/SettelementModal";
import ViewMoreOrderByShopIdModal from "./modal/ViewMoreOrderByShopIdModal";
import CustomDropdown from "./custom/CustomDropDown";
import SettleCustomDropDown from "./custom/SettleCustomDropDown";
import { ArrowsPointingInIcon, ArrowsPointingOutIcon } from "@heroicons/react/24/solid";
import VerifyRideModal from "../../bookedVehicles/modal/VerifyRideModal";

const TABLE_HEAD = ["S.No", "Image", "Name", "Vehicle Number", "Price", "Payment Status", "Settlement Status", "Pickup Confirmed Status",     "Cancel Ride Status",

    "Conformation Otp", "Verify Otp", "Created Date", "Settled", "View"];

export default function ViewShopOwnerTable() {
    const [search, setSearch] = useState('');
    const [page, setPage] = useState(1);
    const [limit, setLimit] = useState(10);
    const [city, setCity] = useState('');
    const [viewType, setViewType] = useState(() => {
        // Initialize from localStorage or default to 'table'
        return localStorage.getItem("viewType") || "table";
    });
    const { shopId } = useParams()
    const navigate = useNavigate();

    const [filters, setFilters] = useState({
        shopId,
        status: "",
        settled: "",
        startDate: '',
        endDate: '',
        limit: limit,
        page: page,
    });
    const [isFullscreen, setIsFullscreen] = useState(false); // Track fullscreen status


    const { data: getOrderByShopId, error, isLoading, refetch } = useGetOrdersByShopQuery(filters);

    // const handlePrevious = () => {
    //     if (page > 1) setPage(page - 1);
    //     refetch()
    // };

    // const handleNext = () => {
    //     const totalPages = Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0) / limit);
    //     if (page < totalPages) setPage(page + 1);
    //     refetch()
    // };

    const handlePrevious = () => {
        if (page > 1) {
            const newPage = page - 1;
            setPage(newPage);
            setFilters((prevFilters) => ({
                ...prevFilters,
                page: newPage,
            }));
        }
    };

    const handleNext = () => {
        const totalPages = Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0) / limit);
        if (page < totalPages) {
            const newPage = page + 1;
            setPage(newPage);
            setFilters((prevFilters) => ({
                ...prevFilters,
                page: newPage,
            }));
        }
    };


    useEffect(() => {
        refetch();
    }, [filters, refetch]);


    const handleFilterChange = (e) => {
        const { name, value } = e.target;
        setFilters((prevFilters) => ({
            ...prevFilters,
            [name]: value,
        }));
    };

    // Function to toggle view type
    const toggleViewType = () => {
        const newViewType = viewType === "table" ? "list" : "table";
        setViewType(newViewType);
        localStorage.setItem("viewType", newViewType); // Save to localStorage
    };

    useEffect(() => {
        // Sync state with localStorage in case of external changes (optional safeguard)
        const storedViewType = localStorage.getItem("viewType");
        if (storedViewType && storedViewType !== viewType) {
            setViewType(storedViewType);
        }
    }, []);

    const toggleFullscreen = () => {
        if (!isFullscreen) {
            document.documentElement.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
        setIsFullscreen(!isFullscreen);
    };

    const formatDate = (isoDate) => {
        const date = new Date(isoDate);
        const options = {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        };
        return new Intl.DateTimeFormat('en-US', options).format(date);
    };

    return (
        <div className="h-full w-full bg-white pt-1 rounded-md border border-green-300">
            <div className="rounded-none border-b border-green-300 px-2 py-1">
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <Typography variant="h5" color="blue-gray">
                            All Shop Order
                        </Typography>
                        <Typography color="gray" className="mt-1 font-normal">
                            See information about all Shop order
                        </Typography>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 mb-2">
                        <div className="">
                            <Input
                                label="Start Date"
                                type="date"
                                name="startDate"
                                value={filters.startDate}
                                onChange={handleFilterChange}
                                color="green"
                            />
                        </div>
                        <div className="">
                            <Input
                                label="End Date"
                                type="date"
                                name="endDate"
                                value={filters.endDate}
                                onChange={handleFilterChange}
                                color="green"
                            />
                        </div>
                        <CustomDropdown filters={filters} setFilters={setFilters} />
                        <SettleCustomDropDown filters={filters} setFilters={setFilters} />

                        <Button
                            variant=""
                            color="green"
                            size="sm"
                            className="flex hover:shadow-none shadow-none items-center gap-2 border-green-200 bg-transparent border text-black"
                            onClick={refetch}
                        >
                            <ArrowPathIcon className="h-5 w-5" />
                        </Button>

                        <Button
                            variant=""
                            color="green"
                            size="sm"
                            className="flex hover:shadow-none shadow-none items-center gap-2 border-green-200 bg-transparent border text-black"
                            onClick={() => navigate('/super-admin-dashboard/view-user-and-shop-owner')}
                        >
                            <Store className="h-5 w-5" />
                            <p>View Shop Owner</p>
                        </Button>

                        <Button
                            variant=""
                            color="green"
                            size="sm"
                            className="flex hover:shadow-none shadow-none items-center gap-2 border-green-200 bg-transparent border text-black"
                            onClick={toggleViewType}
                        >
                            {viewType === "table" ? (
                                <>
                                    <ListBulletIcon className="h-5 w-5" />
                                    {/* <p>List View</p> */}
                                </>
                            ) : (
                                <>
                                    <TableCellsIcon className="h-5 w-5" />
                                    {/* <p>Table View</p> */}
                                </>
                            )}
                        </Button>

                        <Button
                            variant=""
                            size="sm"
                            className="flex items-center gap-2 border hover:shadow-none shadow-none text-black bg-white border-green-200"
                            onClick={toggleFullscreen}
                        >
                            {isFullscreen ? (
                                <ArrowsPointingInIcon className="h-5 w-5" />
                            ) : (
                                <ArrowsPointingOutIcon className="h-5 w-5" />
                            )}
                            {/* <span className=" hidden lg:block sm:block md:block">{isFullscreen ? "Exit Fullscreen" : "Fullscreen"}</span> */}
                        </Button>


                    </div>
                </div>
            </div>

            {/* <pre>{JSON.stringify(getOrderByShopId,null,2)}</pre> */}




            <div className="overflow-scroll p-2">
                {error?.data ? "" : <div className=" mb-1">
                    <div className="flex flex-wrap items-center justify-between border border-green-300 p-2 w-full bg-green-50/50 mb-1">
                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">Shop Name:</h1>
                            <h1>{getOrderByShopId?.shop?.shopName || "N/A"}</h1>
                        </div>

                        {/* <div className=" border-r h-10 border-green-300"></div> */}
                        {/* <pre>{JSON.stringify(getOrderByShopId, null, 2)}</pre> */}

                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">Owner Name:</h1>
                            <h1>{getOrderByShopId?.shop?.ownerName || "N/A"}</h1>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between border border-green-300 p-2 w-full bg-green-50/50 mb-1">
                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">Account holder name:</h1>
                            <h1>{getOrderByShopId?.shop?.account_holder_name || "N/A"}</h1>
                        </div>

                        {/* <div className=" border-r h-10 border-green-300"></div> */}

                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">Account Number:</h1>
                            <h1>{getOrderByShopId?.shop?.account_number || "N/A"}</h1>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between border border-green-300 p-2 w-full bg-green-50/50">
                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">IFSC Code:</h1>
                            <h1>{getOrderByShopId?.shop?.ifsc || "N/A"}</h1>
                        </div>

                        {/* <div className=" border-r h-10 border-green-300"></div> */}

                        <div className="flex items-center gap-1">
                            <h1 className="font-bold">Account verified:</h1>
                            {error?.data ? "N/A" : <Chip
                                size="sm"
                                variant="ghost"
                                value={getOrderByShopId?.shop?.account_verified === false ? "Not Verified" : "Verified"}
                                color={getOrderByShopId?.shop?.account_verified === false ? "red" : "green"}
                                className="px-3 text-center w-28"
                            />}

                        </div>
                    </div>
                </div>}

                {error?.data ? "" :
                    <div className="">
                        {/* <pre>{JSON.stringify(getOrderByShopId?.stats,null,2)}</pre> */}
                        <div className="flex flex-wrap items-center justify-between border border-green-300 p-2 w-full bg-green-50/50 mb-1">
                            <p><b>Total Orders:</b> {getOrderByShopId?.stats?.totalOrders}</p>
                            <p><b>Total Completed:</b> {getOrderByShopId?.stats?.totalCompleted}</p>
                            <p><b>Total Pending:</b> {getOrderByShopId?.stats?.totalPending}</p>
                            <p><b>Total Failed:</b> {getOrderByShopId?.stats?.totalFailed}</p>
                            <p><b>Total Cancelled:</b> {getOrderByShopId?.stats?.totalCancelled}</p>
                        </div>
                    </div>
                }
                {isLoading ? (
                    <div className="flex justify-center p-4">
                        <Spinner className="h-8 w-8 text-green-500" />
                    </div>
                ) : error ? (
                    <div className="p-4">
                        <div className="flex justify-center items-center">
                            <img className="w-20" src="https://cdn-icons-png.flaticon.com/128/9961/9961360.png" alt="" />
                        </div>
                        <h1 className="text-center text-red-500">{error?.data?.error}</h1>
                    </div>
                ) : viewType === "table" ? (
                    <table className="w-full min-w-max table-auto text-left app-font">
                        <thead>
                            <tr>
                                {TABLE_HEAD.map((head) => (
                                    <th
                                        key={head}
                                        className="border-y border-l border-r border-green-200 bg-green-50 p-4"
                                    >
                                        <Typography
                                            variant="small"
                                            color="blue-gray"
                                            className="font-bold leading-none text-green-700"
                                        >
                                            {head}
                                        </Typography>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {getOrderByShopId?.orders?.map((order, index) => {
                                const isLast = index === getOrderByShopId.orders.length - 1;
                                const classes = isLast
                                    ? "px-5 border-l border-r border-b border-green-300"
                                    : "px-5 border-l border-r border-b border-green-300";

                                return (
                                    <tr key={index} className="hover:bg-green-50/50 cursor-pointer">
                                        <td className={classes}>{index + 1 + (page - 1) * limit}.</td>
                                        <td className={classes}>
                                            <LazyLoadImage
                                                alt="img"
                                                src={order?.vehicle?.vehicleImage[0]?.url}
                                                className="w-10 h-10 rounded-full"
                                            />
                                        </td>
                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >{order?.vehicle?.vehicleName}</Typography>

                                        </td>
                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                {order?.vehicle?.vehicleNumber}
                                            </Typography>

                                        </td>
                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                ₹{order?.vehicle?.vehiclePrice}
                                            </Typography>

                                        </td>


                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                <Chip
                                                    size="sm"
                                                    variant="ghost"
                                                    value={order?.status}
                                                    color={
                                                        order?.status === "failed"
                                                            ? "red"
                                                            : order?.status === "pending"
                                                                ? "orange"
                                                                : "green"
                                                    }
                                                    className="px-3 text-center w-28"
                                                />
                                            </Typography>

                                        </td>

                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                <Chip
                                                    size="sm"
                                                    variant="ghost"
                                                    value={order?.settled ? "fulfilled" : "pending"}
                                                    color={order?.settled ? "green" : "red"}
                                                    className="px-3 text-center w-28"
                                                />
                                            </Typography>

                                        </td>

                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                <Chip
                                                    size="sm"
                                                    variant="ghost"
                                                    value={order?.rideConfirmed === false ? "pending" : "success"}
                                                    color={order?.rideConfirmed === true ? "green" : "red"}
                                                    className="px-3 text-center w-28"
                                                />
                                            </Typography>
                                        </td>

                                        <td className={classes}>
                                            {order?.cancellationRefundId ? <Chip
                                                size="sm"
                                                variant="ghost"
                                                value={order?.cancellationRefundStatus && "success"}
                                                color={order?.cancellationRefundId ? "green" : "orange"}
                                                className="px-3 text-center w-28"
                                            /> : <span className=" text-center">N/A</span>}
                                        </td>

                                        <td className={classes}>
                                            <VerifyRideModal orderId={order?._id} refetch={refetch} rideConfirmed={order?.rideConfirmed} />
                                        </td>
                                        {/* conformationOtp, rideConfirmed */}

                                        <td className={classes}>
                                            {order?.conformationOtp}
                                        </td>

                                        <td className={classes}>
                                            {formatDate(order?.createdAt)}
                                        </td>
                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                <SettelementModal id={order?._id} amount={order?.vehicle?.vehiclePrice} refetch={refetch} settled={order?.settled} />
                                            </Typography>

                                        </td>
                                        <td className={classes}>
                                            <Typography
                                                variant="small"
                                                color="blue-gray"
                                                className="font-normal app-font"
                                            >
                                                <ViewMoreOrderByShopIdModal order={order} />
                                            </Typography>

                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                ) : (
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        {getOrderByShopId?.orders?.map((order, index) => (
                            <div
                                key={index}
                                className="p-2 border border-green-300 rounded-md"
                            >
                                <LazyLoadImage
                                    alt="img"
                                    src={order?.vehicle?.vehicleImage[0]?.url}
                                    className="w-full h-40 object-cover rounded-md mb-2"
                                />
                                <Typography variant="h6">{order?.vehicle?.vehicleName}</Typography>
                                <Typography variant="body2" color="black">
                                    <b> Number:</b> {order?.vehicle?.vehicleNumber}
                                </Typography>
                                <Typography variant="body2" color="black">
                                    <b>Price:</b> ₹{order?.vehicle?.vehiclePrice}
                                </Typography>
                                <div className="flex justify-between items-center mt-2" >
                                    <h1 className=" font-bold"> Conformation Otp
                                        : </h1>
                                    <p className=" border px-2 bg-green-50">{order?.conformationOtp}</p>
                                </div>
                                <div className="flex justify-between items-center mt-2">
                                    <h1 className=" font-bold">Payment Status: </h1>
                                    <Chip size="sm" variant="ghost" value={order?.status} color={order?.status === "failed" ? "red" : order?.status === "pending" ? "orange" : "green"} className="px-3 text-center w-28" />
                                </div>

                                <div className="flex justify-between items-center mt-2">
                                    <h1 className=" font-bold">Pickup Confirmed Status
                                        : </h1>
                                    <Chip
                                        size="sm"
                                        variant="ghost"
                                        value={order?.rideConfirmed === false ? "pending" : "success"}
                                        color={order?.rideConfirmed === false ? "red" : "orange"}
                                        className="px-3 text-center w-28"
                                    />
                                </div>


                                <div className="flex justify-between items-center mt-2">
                                    <h1 className=" font-bold">Settlement Status: </h1>
                                    <Chip
                                        size="sm"
                                        variant="ghost"
                                        value={order?.settled === false ? "pending" : "fullfill"}
                                        color={
                                            order?.settled === false ? "red" :
                                                "green"
                                        }

                                        className="px-3 text-center w-28"
                                    />
                                </div>

                                <div className="flex justify-between items-center mt-2">
                                    <h1 className=" font-bold">Ride Cancel Status
                                        : </h1>
                                    {order?.cancellationRefundId ? <Chip
                                        size="sm"
                                        variant="ghost"
                                        value={order?.cancellationRefundStatus && "success"}
                                        color={order?.cancellationRefundId ? "green" : "orange"}
                                        className="px-3 text-center w-28"
                                    /> : "N/A"}
                                </div>


                                <div className="flex justify-between items-center mt-2">
                                    <p className="font-bold">Created Date:</p>
                                    <p className=" app-font">{formatDate(order?.createdAt)}</p>
                                </div>


                                <div className="flex justify-between mt-2 bg-green-50 rounded-b-lg">
                                    <Tooltip text={"Settelement"}>
                                        <SettelementModal id={order?._id} amount={order?.vehicle?.vehiclePrice} refetch={refetch} settled={order?.settled} />

                                    </Tooltip>

                                    <Tooltip text={"Verify Otp"}>
                                        <VerifyRideModal orderId={order?._id} refetch={refetch} rideConfirmed={order?.rideConfirmed} />

                                    </Tooltip>


                                    <Tooltip text={"View More"}>
                                        <ViewMoreOrderByShopIdModal order={order} />
                                    </Tooltip>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* <pre>{JSON.stringify(page)}</pre>

            <pre>{JSON.stringify(Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0)))}</pre>

            <pre>{JSON.stringify(page === Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0) / limit))}</pre> */}
            <div className="flex items-center justify-between border-t border-green-300 p-4">
                <Typography variant="small" color="blue-gray" className="font-normal">
                    Page {page} of {Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0) / limit)}
                </Typography>
                <div className="flex gap-2">
                    <Button
                        variant=""
                        size="sm"
                        className="hover:bg-green-50 active:bg-green-50 focus:bg-green-50 transition-colors duration-300 hover:shadow-none shadow-none bg-transparent border text-black border-green-200 "
                        onClick={handlePrevious} disabled={page === 1}
                    >
                        Previous
                    </Button>



                    <Button
                        variant=""
                        size="sm"
                        className=" hover:shadow-none shadow-none   bg-green-500 "
                        onClick={handleNext}
                        disabled={page === Math.ceil((getOrderByShopId?.stats?.totalOrders ?? 0) / limit)}
                    >
                        Next
                    </Button>
                </div>
            </div>
        </div>
    );
}



const Tooltip = ({ children, text }) => (
    <div className="relative group">
        {children}
        <div className="absolute bottom-full w-[7em] text-center left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block bg-black text-white text-xs rounded px-2 py-1 shadow-lg">
            {text}
        </div>
    </div>
);