
const Settlements = () => {
  return (
    <div>Settlements</div>
  )
}

export default Settlements