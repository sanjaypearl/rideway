/* eslint-disable react-hooks/exhaustive-deps */

import { useState } from "react";
import ChartStatus from "./ChartStatus";
import TodaysOrder from "./TodaysOrder";
import TopCardStatus from "./TopCardStatus";

function ShopOwnerHomeDashboardStatus() {
  // default to current month & year
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());

  return (
    <div>
      <TopCardStatus
        selectedMonth={selectedMonth}
        setSelectedMonth={setSelectedMonth}
        selectedYear={selectedYear}
        setSelectedYear={setSelectedYear}
      />

      {/* equal-width panels */}
      <div className="flex flex-col lg:flex-row gap-4 mt-6">
        <div className="flex-1">
          <TodaysOrder
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
          />
        </div>
        <div className="flex-2">
          <ChartStatus
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
          />
        </div>
      </div>
    </div>
  );
}

export default ShopOwnerHomeDashboardStatus;
