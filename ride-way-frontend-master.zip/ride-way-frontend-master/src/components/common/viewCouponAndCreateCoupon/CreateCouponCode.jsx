import { useEffect, useState } from 'react';
import { useCreateCouponMutation } from '../../../redux/slices/couponApi';
import toast from 'react-hot-toast';
import { Button, Input, CardBody, Typography } from '@material-tailwind/react';

const CreateCouponCode = () => {
    const [code, setCode] = useState('');
    const [discountType, setDiscountType] = useState('');
    const [discountValue, setDiscountValue] = useState('');
    const [expirationDate, setExpirationDate] = useState('');

    const [createCoupon, { isLoading, isSuccess, isError, error, data }] = useCreateCouponMutation();

    const handleCreateCoupon = async () => {
        try {
            await createCoupon({ code, discountType, discountValue, expirationDate }).unwrap();
            setCode('');
            setDiscountType('');
            setDiscountValue('');
            setExpirationDate('');
        } catch (err) {
            console.error('Failed to create coupon:', err);
        }
    };

    useEffect(() => {
        if (isError) {
            toast.error(error?.data?.error || 'An error occurred. Please try again.');
        }
        if (isSuccess) {
            toast.success(data?.message || 'Coupon created successfully');
        }
    }, [isError, isSuccess, error, data]);

    return (
        <div className="flex justify-center items-center">
            <div className="w-full max-w-2xl border border-green-300 bg-white rounded-md">
                <CardBody>
                    <Typography variant="h5" color="blue-gray" className="mb-4">
                        Create Coupon Code
                    </Typography>

                    {/* Hint Box */}
                    <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded">
                        <Typography color="gray" className="text-sm">
                            Hint: Use uppercase alphanumeric codes without spaces. <br />
                            Example formats: <strong>SPRING2025</strong>, <strong>SAVE10</strong>, <strong>WELCOME2025</strong>.
                        </Typography>
                    </div>

                    <div className="mb-4">
                        <Input
                            type="text"
                            label="Coupon Code"
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                            size="lg"
                            color="green"
                            style={{ fontSize: '16px' }}
                        />
                    </div>

                    <div className="mb-4">
                        <Typography variant="small" color="blue-gray" className="mb-1">
                            Discount Type
                        </Typography>
                        <select
                            className="w-full border border-green-300 rounded p-2"
                            value={discountType}
                            onChange={(e) => setDiscountType(e.target.value)}
                        >
                            <option value="">Select discount type</option>
                            <option value="percentage">Percentage</option>
                            <option value="fixed">Fixed Amount</option>
                        </select>
                    </div>

                    <div className="mb-4">
                        <Input
                            type="number"
                            label="Discount Value"
                            value={discountValue}
                            onChange={(e) => setDiscountValue(e.target.value)}
                            size="lg"
                            color="green"
                            style={{ fontSize: '16px' }}
                        />
                    </div>

                    <div className="mb-6">
                        <Input
                            type="date"
                            label="Expiration Date"
                            value={expirationDate}
                            onChange={(e) => setExpirationDate(e.target.value)}
                            size="lg"
                            color="green"
                            style={{ fontSize: '16px' }}
                        />
                    </div>

                    <Button
                        onClick={handleCreateCoupon}
                        disabled={
                            isLoading ||
                            !code.trim() ||
                            !discountType ||
                            !discountValue ||
                            !expirationDate
                        }
                        fullWidth
                        className={`bg-green-500 hover:bg-green-600 text-white hover:shadow-none shadow-none ${isLoading && 'cursor-not-allowed'}`}
                    >
                        {isLoading ? 'Creating...' : 'Create Coupon'}
                    </Button>
                </CardBody>
            </div>
        </div>
    );
};

export default CreateCouponCode;
