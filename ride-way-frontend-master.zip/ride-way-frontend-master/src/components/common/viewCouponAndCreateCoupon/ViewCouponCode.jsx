import { useEffect, useState } from "react";
import {
  Squares2X2Icon,
  TableCellsIcon,
  ArrowPathIcon,
  ArrowsPointingInIcon,
  ArrowsPointingOutIcon,
} from "@heroicons/react/24/outline";
import {
  Typography,
  Button,
  Spinner,
  Chip,
} from "@material-tailwind/react";
import { toast } from "react-hot-toast";

import {
  useGetCouponsQuery,
  useDeactivateCouponMutation,
} from "../../../redux/slices/couponApi";

import DeleteCouponCodeModal from "./modal/DeleteCouponCodeModal";

const TABLE_HEAD = ["S.No", "Code", "Type", "Value", "Expires", "Status", "Delete"];

export default function ViewCouponCode() {
  const [viewType, setViewType] = useState(() => localStorage.getItem("viewType") || "table");
  const [isFullscreen, setIsFullscreen] = useState(false);

  const {
    data: coupons = [],
    isLoading: isFetching,
    isError: fetchError,
    error: fetchErrorData,
    refetch,
  } = useGetCouponsQuery();

  const [
    deactivateCoupon,
    { isLoading: isDeactivating, isSuccess: deactSuccess, isError: deactError, error: deactErrorData },
  ] = useDeactivateCouponMutation();

  // sync viewType with localStorage
  useEffect(() => {
    const stored = localStorage.getItem("viewType");
    if (stored && stored !== viewType) setViewType(stored);
  }, []);

  const toggleViewType = () => {
    const next = viewType === "table" ? "list" : "table";
    setViewType(next);
    localStorage.setItem("viewType", next);
  };

  const toggleFullscreen = () => {
    if (!isFullscreen) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
    setIsFullscreen(!isFullscreen);
  };

  // toasts & refetch on deactivate
  useEffect(() => {
    if (deactError) toast.error(deactErrorData?.data?.error || "Failed to deactivate");
    if (deactSuccess) {
      toast.success("Coupon deactivated");
      refetch();
    }
  }, [deactError, deactSuccess, deactErrorData, refetch]);

  return (
    <div className="h-full w-full overflow-scroll border border-green-300 bg-white pt-1 rounded-md">
      {/* Header */}
      <div className="rounded-none border-b border-green-300 px-2 py-1">
        <div className="flex flex-wrap items-center justify-between gap-4 lg:gap-8">
          <div>
            <Typography variant="h5" color="blue-gray">
              All Coupons
            </Typography>
            <Typography color="gray" className="mt-1 font-normal">
              See information about all coupons
            </Typography>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Button
              variant=""
              color="green"
              size="sm"
              className="flex items-center gap-2 border-green-300 bg-transparent border text-black hover:shadow-none"
              onClick={refetch}
            >
              <ArrowPathIcon className="h-5 w-5" />
              Refresh
            </Button>
            <Button
              variant=""
              color="green"
              size="sm"
              className="flex items-center gap-2 border-green-300 bg-transparent border text-black hover:shadow-none"
              onClick={toggleViewType}
            >
              {viewType === "table" ? (
                <>
                  <Squares2X2Icon className="h-5 w-5" />
                  List View
                </>
              ) : (
                <>
                  <TableCellsIcon className="h-5 w-5" />
                  Table View
                </>
              )}
            </Button>
            <Button
              variant=""
              size="sm"
              className="flex items-center gap-2 border-green-200 bg-white text-black hover:shadow-none"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? (
                <ArrowsPointingInIcon className="h-5 w-5" />
              ) : (
                <ArrowsPointingOutIcon className="h-5 w-5" />
              )}
              <span className="hidden sm:inline">
                {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
              </span>
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="overflow-y-auto p-2">
        {isFetching ? (
          <div className="flex justify-center p-4">
            <Spinner className="h-8 w-8 text-green-500" />
          </div>
        ) : fetchError ? (
          <div className="p-4 text-center">
            <img
              className="mx-auto w-20"
              src="https://cdn-icons-png.flaticon.com/128/9961/9961360.png"
              alt="Error"
            />
            <Typography color="red" className="mt-2">
              {fetchErrorData?.data?.error || "Failed to load coupons"}
            </Typography>
          </div>
        ) : coupons.length === 0 ? (
          <div className="p-4 text-center">
            <img
              className="mx-auto w-20"
              src="https://cdn-icons-png.flaticon.com/128/9961/9961360.png"
              alt="No Data"
            />
            <Typography color="red" className="mt-2">
              No coupons found.
            </Typography>
          </div>
        ) : viewType === "table" ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-max table-auto text-left">
              <thead>
                <tr>
                  {TABLE_HEAD.map((head) => (
                    <th
                      key={head}
                      className="border-green-200 bg-green-50 p-4 border"
                    >
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-bold text-green-700"
                      >
                        {head}
                      </Typography>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {coupons.map((c, i) => {
                  const classes = "border-green-300 px-5 py-2 border";
                  return (
                    <tr
                      key={c._id}
                      className="hover:bg-green-50/50 cursor-pointer"
                    >
                      <td className={classes}>
                        <Typography variant="small" color="blue-gray">
                          {i + 1}.
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Typography variant="small" color="blue-gray">
                          {c.code}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Typography variant="small" color="blue-gray">
                          {c.discountType}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Typography variant="small" color="blue-gray">
                          {c.discountValue}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Typography variant="small" color="blue-gray">
                          {new Date(c.expirationDate).toLocaleDateString()}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Chip
                          value={c.isActive ? "Active" : "Inactive"}
                          color={c.isActive ? "green" : "red"}
                          size="sm"
                          className="w-max uppercase"
                        />
                      </td>
                      <td className={classes}>
                        <div className="flex gap-2">
                          <DeleteCouponCodeModal id={c._id} onSuccess={refetch} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {coupons.map((c) => (
              <div
                key={c._id}
                className="relative p-4 border border-green-300 rounded-md"
              >
                {/* delete button top-right */}
                <div className="absolute top-2 right-2">
                  <DeleteCouponCodeModal id={c._id} onSuccess={refetch} />
                </div>

                <Typography variant="h6" className="mb-2">
                  {c.code}
                </Typography>
                <Typography className="text-sm">
                  Type: {c.discountType}
                </Typography>
                <Typography className="text-sm">
                  Value: {c.discountValue}
                </Typography>
                <Typography className="text-sm mb-2">
                  Expires: {new Date(c.expirationDate).toLocaleDateString()}
                </Typography>
                <Chip
                  value={c.isActive ? "Active" : "Inactive"}
                  color={c.isActive ? "green" : "red"}
                  size="sm"
                  className="w-max uppercase"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
