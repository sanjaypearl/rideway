import React from "react";
import {
    Tabs,
    TabsHeader,
    TabsBody,
    Tab,
    TabPanel,
} from "@material-tailwind/react";
import ViewCouponCode from "./ViewCouponCode";
import CreateCouponCode from "./CreateCouponCode";

export default function ViewCouponCodeAndCreateCouponCode() {
    const [activeTab, setActiveTab] = React.useState("View Coupon Code");

    return (
        <div>
            <Tabs value={activeTab}>
                <TabsHeader
                    className="rounded-none  bg-transparent p-0 mb-4 overflow-x-auto sm:overflow-x-hidden whitespace-nowrap scrollbar-hide bg-green-100 border border-green-300  "
                    indicatorProps={{
                        className:
                            "bg-transparent border-b-2 border-green-500 shadow-none rounded-none",
                    }}
                >



                    <Tab
                        key={'view Coupon Code'}
                        value={"View Coupon Code"}
                        onClick={() => setActiveTab('View Coupon Code')}
                        className={`${activeTab === 'View Coupon Code' ? 'text-green-700' : ''
                            } px-2 sm:px-4 md:px-6 lg:px-8 py-2 font-bold`}
                    >
                        View Coupon Code
                    </Tab>

                    <Tab
                        key={'create Coupon Code'}
                        value={"Create Coupon Code"}
                        onClick={() => setActiveTab('Create Coupon Code')}
                        className={`${activeTab === 'Create Coupon Code' ? 'text-green-700' : ''
                            } px-2 sm:px-4 md:px-6 lg:px-8 py-2  font-bold`}
                    >
                        Create Coupon Code
                    </Tab>
                </TabsHeader>

                <TabsBody className="h-full w-full overflow-scroll scrollbar-hide whitespace-nowrap">
                    <TabPanel key={'view Coupon Code'} value={"View Coupon Code"} className=" -p-9">
                        <ViewCouponCode />
                    </TabPanel>

                    <TabPanel className="h-full w-full overflow-scroll scrollbar-hide whitespace-nowrap -p-9" key={'create Coupon Code'} value={"Create Coupon Code"}>
                        <CreateCouponCode />
                    </TabPanel>
                </TabsBody>
            </Tabs>
        </div>
    );
}