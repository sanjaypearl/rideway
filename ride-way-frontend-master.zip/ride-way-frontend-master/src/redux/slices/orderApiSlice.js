import apiSlice from "./apiSlice";

// Define your API slice
export const orderApiSlice = apiSlice.injectEndpoints({
  tagTypes: "Order",
  endpoints: (builder) => ({
    createOrder: builder.mutation({
      query: ({ vehicleId, body }) => ({
        url: `/order/create-order/${vehicleId}`,
        method: "POST",
        body,
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      invalidatesTags: ["Order"], // Invalidate Order tag on create
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),
    verifyPayment: builder.mutation({
      query: (paymentData) => ({
        url: "/payment/verify",
        method: "PUT",
        body: paymentData,
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      invalidatesTags: ["Order"], // Invalidate Order tag on payment verification
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    getOrders: builder.query({
      query: ({
        status,
        settled,
        startDate,
        endDate,
        limit = 10,
        page = 1,
      }) => {
        // Build query string
        const params = new URLSearchParams();

        if (status) params.append("status", status);
        if (settled !== undefined) params.append("settled", settled);
        if (startDate) params.append("startDate", startDate);
        if (endDate) params.append("endDate", endDate);
        if (limit) params.append("limit", limit);
        if (page) params.append("page", page);

        return {
          url: `/order/get-orders?${params.toString()}`, // API endpoint with query params
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")),
          },
        };
      },
      providesTags: (result) =>
        result?.orders
          ? result.orders.map(({ _id }) => ({ type: "Order", id: _id })) // Update based on orders
          : [{ type: "Order" }],
      keepUnusedDataFor: 3600, // Cache data for 5 minutes
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    getOrderById: builder.query({
      query: (orderId) => ({
        url: `/order/get-order/${orderId}`,
        method: "GET",
        credentials: "include", // Include credentials if required for authentication
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      providesTags: (result, error, orderId) =>
        result ? [{ type: "Order", id: orderId }] : [{ type: "Order" }],
      keepUnusedDataFor: 3600, // Cache data for 5 minutes
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    getOrdersByShop: builder.query({
      query: ({ shopId, status, settled, startDate, endDate, limit, page }) => {
        // Build the query string dynamically
        const queryParams = new URLSearchParams();
        if (status) queryParams.append("status", status);
        if (settled !== undefined) queryParams.append("settled", settled);
        if (startDate) queryParams.append("startDate", startDate);
        if (endDate) queryParams.append("endDate", endDate);
        queryParams.append("limit", limit);
        queryParams.append("page", page);

        // Construct the final URL and include headers
        return {
          url: `/order/get-orders/${shopId}?${queryParams.toString()}`,
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")), // Retrieve the token from localStorage
          },
        };
      },
      providesTags: (result, error, { shopId }) =>
        result
          ? [
              { type: "Order", id: shopId },
              ...result.orders.map(({ _id }) => ({ type: "Order", id: _id })),
            ]
          : [{ type: "Order", id: shopId }],
      keepUnusedDataFor: 60, // Cache duration
      refetchOnFocus: true,
      refetchOnReconnect: true,
      refetchOnMountOrArgChange: true,
    }),

    confirmOrder: builder.mutation({
      query: ({ orderId, otp }) => {
        // console.log('Order ID:', orderId);
        // console.log('OTP:', otp);
        return {
          url: `/order/confirm-order/${orderId}`,
          method: "PUT",
          body: { otp },
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")),
          },
        };
      },
      keepUnusedDataFor: 60, // Cache duration in seconds
      refetchOnFocus: true, // Automatically refetch data when the browser regains focus
      refetchOnReconnect: true, // Automatically refetch data when the network connection is restored
      refetchOnMountOrArgChange: true, // Refetch when the component remounts or arguments change
    }),

    cancelOrder: builder.mutation({
      query: ({ orderId }) => ({
        url: `/order/cancel-order/${orderId}`,
        method: "POST",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      invalidatesTags: ["Order"], // Invalidate Order tag on cancellation
      keepUnusedDataFor: 3600, // Keep unused data for 5 minutes
      refetchOnMountOrArgChange: true, // Refetch on argument change
      refetchOnReconnect: true, // Refetch on reconnect
      refetchOnFocus: true, // Refetch when the window regains focus
      onQueryStarted: async ({ orderId }, { queryFulfilled, dispatch }) => {
        try {
          const { data } = await queryFulfilled;
          console.log("Refund initiated successfully:", data);
        } catch (error) {
          console.error("Error initiating refund:", error);
        }
      },
    }),

    uploadAdharCard: builder.mutation({
      query: (formData) => ({
        url: "/order/upload-adharcard",
        method: "POST",
        body: formData,
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
    }),
    getOrderStatus: builder.query({
      query: (referenceId) => ({
        url: `/order/get-order-status/${referenceId}`,
        method: "GET",
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")) || "",
        },
      }),
      providesTags: (result, error, referenceId) => [
        { type: "Order", id: referenceId },
      ],
      keepUnusedDataFor: 60, // Cache for 1 minute
      refetchOnMountOrArgChange: true, // Refetch when arguments change or component mounts
      refetchOnReconnect: true, // Refetch on reconnect
      refetchOnFocus: true, // Refetch when window regains focus
    }),
  }),
});

export const {
  useCreateOrderMutation,
  useVerifyPaymentMutation,
  useGetOrdersQuery,
  useGetOrderByIdQuery,
  useGetOrdersByShopQuery,
  useConfirmOrderMutation,
  useCancelOrderMutation,
  useUploadAdharCardMutation,
  useGetOrderStatusQuery,
} = orderApiSlice;
