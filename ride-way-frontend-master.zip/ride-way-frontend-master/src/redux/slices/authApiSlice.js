/* eslint-disable no-unused-vars */
import apiSlice from "./apiSlice";
import authService from "../../services/authService";

export const authApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    /* ───────────────────────── EMAIL / PASSWORD ───────────────────────── */
    login: builder.mutation({
      query: (credentials) => ({
        url: "auth/login",
        method: "POST",
        body: credentials,
      }),
      async onQueryStarted(_, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (err) {
          console.error("Login error:", err);
        }
      },
    }),

    /* ───────────────────────── OTP LOGIN ───────────────────────── */
    sendOtp: builder.mutation({
      // expects: { identifier, role }
      query: ({ identifier, role }) => ({
        url: "auth/login/request-otp",
        method: "POST",
        body: { identifier, role },
      }),
    }),

    verifyOtp: builder.mutation({
      // expects: { identifier, otp, role }
      query: ({ identifier, otp, role }) => ({
        url: "auth/login/verify-otp",
        method: "POST",
        body: { identifier, otp, role },
      }),
      async onQueryStarted(_, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          authService.setUser(data.user, JSON.stringify(data.token));
        } catch (err) {
          console.error("OTP login error:", err);
        }
      },
    }),

    /* ───────────────────────── LOGOUT & OTHER MUTATIONS ───────────────── */
    logout: builder.mutation({
      queryFn: () => {
        localStorage.removeItem("token");
        return { data: null };
      },
    }),

    firstPasswordChange: builder.mutation({
      query: ({ id, passwordState }) => ({
        url: `/auth/first-password-change/${id}`,
        method: "PUT",
        body: passwordState,
      }),
    }),
  }),
});

/* hooks */
export const {
  useLoginMutation,
  useSendOtpMutation,
  useVerifyOtpMutation,
  useLogoutMutation,
  useFirstPasswordChangeMutation,
} = authApiSlice;
