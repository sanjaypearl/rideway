// src/services/couponApi.js
import apiSlice from "./apiSlice";

export const couponApi = apiSlice.injectEndpoints({
  tagTypes: ['Coupon'],
  endpoints: (builder) => ({
    // Get all coupons
    getCoupons: builder.query({
      query: () => '/coupenCode/get-coupenCodes',
      providesTags: ['Coupon'],
    }),
    createCoupon: builder.mutation({
      query: (newCoupon) => ({
        url: '/coupenCode/create-coupenCode',
        method: 'POST',
        body: newCoupon,
      }),
      invalidatesTags: ['Coupon'],
    }),
    validateCoupon: builder.mutation({
      query: (code) => ({
        url: '/coupenCode/validate',
        method: 'POST',
        body: { code },
      }),
    }),
    deactivateCoupon: builder.mutation({
      query: ({ coupenId }) => ({
        url: `/coupenCode/deactivate/${coupenId}`,
        method: 'PUT',
      }),
      invalidatesTags: ['Coupon'],
    }),
    deleteCoupon: builder.mutation({
      query: (coupenId) => ({
        url: `/coupenCode/delete/${coupenId}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Coupon'],
    }),
  }),
});

export const {
  useGetCouponsQuery,
  useCreateCouponMutation,
  useValidateCouponMutation,
  useDeactivateCouponMutation,
  useDeleteCouponMutation,
} = couponApi;
