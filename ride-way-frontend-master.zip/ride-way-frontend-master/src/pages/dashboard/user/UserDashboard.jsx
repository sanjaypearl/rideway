import UserLayout from "../../../components/dashboard/user/UserLayout"

const UserDashboard = () => {
  return (
    <UserLayout></UserLayout>
  )
}

export default UserDashboard