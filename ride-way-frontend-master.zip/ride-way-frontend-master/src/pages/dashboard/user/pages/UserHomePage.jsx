const UserHomePage = () => {
  return (
    <div>UserHomePage</div>
  )
}

export default UserHomePage