import BookedVehicles from "../../../../components/common/bookedVehicles/BookedVehicles"

const ShopOwnerVehicleBookPage = () => {
  return (
    <div>
        <BookedVehicles/>
    </div>
  )
}

export default ShopOwnerVehicleBookPage