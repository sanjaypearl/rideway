import ViewAndAddCity from "../../../../components/common/viewAndAddCity/ViewAndAddCity"

const SuperAdminViewAndAddCityPage = () => {
  return (
    <div>
        <ViewAndAddCity/>
    </div>
  )
}

export default SuperAdminViewAndAddCityPage