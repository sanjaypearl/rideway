import ViewUserAndShopOwner from "../../../../components/common/viewUserAndShopOwner/ViewUserAndShopOwner"

const SuperAdminViewUserAndShopOwnerPage = () => {
  return (
    <div>
        <ViewUserAndShopOwner/>
    </div>
  )
}

export default SuperAdminViewUserAndShopOwnerPage