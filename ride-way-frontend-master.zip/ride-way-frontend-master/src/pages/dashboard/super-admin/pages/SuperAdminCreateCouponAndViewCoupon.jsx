import ViewCouponCodeAndCreateCouponCode from "../../../../components/common/viewCouponAndCreateCoupon/ViewCouponCodeAndCreateCouponCode"

const SuperAdminCreateCouponAndViewCoupon = () => {
  return (
    <div>
        <ViewCouponCodeAndCreateCouponCode/>
    </div>
  )
}

export default SuperAdminCreateCouponAndViewCoupon