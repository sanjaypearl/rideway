// src/pages/ShippingAndDelivery.jsx
import { Link } from "react-router-dom";
import Layout from "../../../components/layout/Layout";
import { motion } from "framer-motion";

export default function ShippingAndDelivery() {
  return (
    <Layout>
      <div className="bg-gradient-to-b from-green-50 to-white flex items-center justify-center py-6 px-4">
        <motion.div
          className="max-w-4xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <div className="bg-gradient-to-r from-teal-500 to-blue-500 px-8 py-6">
            <h1 className="text-3xl font-extrabold text-white text-center">
              Shipping & Delivery
            </h1>
          </div>
          <div className="prose prose-gray px-8 py-10 max-w-none text-center">
            <p className="text-lg font-medium">
              We currently do not offer shipping or delivery services at Rideaway.
            </p>
            <p>
              Rideaway specializes in connecting you with local bike owners for
              convenient rental pick-up and drop-off services. We encourage
              customers to pick up and return rentals at designated locations.
            </p>
            <p>
              For any questions regarding pick-up or drop-off options, please
              feel free to contact our support team. We’re here to make your
              rental experience smooth and hassle-free.
            </p>
            <div className="mt-8">
              <Link
                to="/contact"
                className="inline-block px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-semibold rounded-full shadow-lg hover:from-green-600 hover:to-blue-600 transition-colors"
              >
                Contact Support
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
