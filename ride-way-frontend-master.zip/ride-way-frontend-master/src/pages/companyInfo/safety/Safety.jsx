/* src/pages/SafetyPage.jsx */
import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../../../components/layout/Layout';

const sectionVariant = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function SafetyPage() {
  return (
    <Layout>
      <div className="bg-gray-50 py-12 px-4">
        <div className="max-w-5xl mx-auto space-y-12">
          <motion.h1
            className="text-4xl font-extrabold text-gray-900 text-center"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
          >
            Safety & Responsibility
          </motion.h1>

          {/* Safety Section */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
          >
            <div className="bg-teal-100 px-6 py-4">
              <h2 className="text-2xl font-semibold text-teal-800">Safety</h2>
            </div>
            <div className="px-8 py-6 prose prose-gray max-w-none">
              <ol className="list-decimal list-inside space-y-4">
                <li>At Rideaway, your safety is our top priority! As a rider, you’re responsible for your own well-being while on the road.</li>
                <li>Just bring a copy of your driving license for rentals (except bicycles), and remember that helmets are mandatory. Safe riding is our policy—no drinking, and always follow the traffic rules.</li>
                <li>Helmets are mandatory. Drinking and driving or using any intoxicants while driving is strictly against our company policies. The rider must adhere to all rules and regulations of the Motor Vehicle Department of the Government of India.</li>
                <li>In rare cases like extreme weather or emergencies, we’re here to help, but generally, riders should bring the vehicle back in the same condition it was rented.</li>
                <li>The vehicle should be returned in the same safe and sound condition as it was when rented.</li>
              </ol>
            </div>
          </motion.section>

          {/* Damage and Loss Section */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
            transition={{ delay: 0.2 }}
          >
            <div className="bg-teal-100 px-6 py-4">
              <h2 className="text-2xl font-semibold text-teal-800">Damage and Loss</h2>
            </div>
            <div className="px-8 py-6 prose prose-gray max-w-none">
              <ol className="list-decimal list-inside space-y-4">
                <li>Before each ride, you and our team will inspect the vehicle together to ensure everything is good to go.</li>
                <li>We take care of any maintenance issues, but for any damages or losses that happen during your rental, you’re responsible for covering repair costs.</li>
                <li>Treat the vehicle as if it’s your own. Our goal is for every rider to enjoy a smooth, safe experience with RideAway!</li>
                <li>You are responsible for paying repair charges or any other charges if there is any damage or loss to the rented vehicle.</li>
                <li>Once the rider complies with all the terms and conditions, the vehicle is handed over for use.</li>
              </ol>
            </div>
          </motion.section>

          {/* Safety Tips Grid */}
          <motion.section
            className="space-y-6"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-2xl font-semibold text-gray-800">Safety Tips</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {[
                { title: 'Wear Protective Gear', desc: 'Always wear a helmet and other protective gear to ensure your safety.' },
                { title: 'Follow Traffic Rules',   desc: 'Obey speed limits and traffic signals to avoid accidents.' },
                { title: 'Stay Alert',             desc: 'Stay aware of your surroundings and avoid distractions while riding.' },
                { title: 'Check Bike Condition',   desc: 'Before starting your ride, inspect the bike’s brakes, tires, and fuel.' },
              ].map((tip) => (
                <motion.div
                  key={tip.title}
                  className="p-6 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition transform hover:-translate-y-1"
                  variants={sectionVariant}
                >
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{tip.title}</h3>
                  <p className="text-gray-700">{tip.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.section>
        </div>
      </div>
    </Layout>
  );
}
