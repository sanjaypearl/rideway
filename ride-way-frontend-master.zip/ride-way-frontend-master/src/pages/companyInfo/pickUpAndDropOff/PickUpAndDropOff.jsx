// src/pages/PickUpAndDropOff.jsx
import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../../../components/layout/Layout';

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
};

export default function PickUpAndDropOff() {
  return (
    <Layout>
      <div className="bg-gradient-to-b from-green-50 to-white py-16 px-6 min-h-screen">
        <motion.div
          className="max-w-5xl mx-auto space-y-12"
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.2 } } }}
        >
          {/* Header */}
          <motion.h1
            className="text-4xl font-extrabold text-gray-900 text-center"
            variants={fadeInUp}
          >
            Rental Pick-Up & Drop-Off
          </motion.h1>

          {/* Overview */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            variants={fadeInUp}
          >
            <div className="bg-gradient-to-r from-teal-500 to-blue-500 px-8 py-6">
              <h2 className="text-2xl font-semibold text-white text-center">Overview</h2>
            </div>
            <div className="prose prose-gray px-8 py-6 max-w-none text-center">
              <p>
                At Rideaway, we make renting a bike as convenient and seamless as possible.
                Our service connects you with local bike owners, allowing you to pick up a
                rental at convenient locations and return it with ease. Here’s how our
                pick-up and drop-off process works and what you need to know.
              </p>
            </div>
          </motion.section>

          {/* Pick-Up Process */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            variants={fadeInUp}
          >
            <div className="bg-gradient-to-r from-green-500 to-teal-400 px-8 py-6">
              <h2 className="text-2xl font-semibold text-white text-center">Pick-Up Process</h2>
            </div>
            <div className="px-8 py-6">
              <ol className="list-decimal list-inside space-y-4 text-gray-700">
                <li>
                  <strong>Booking Confirmation:</strong> After placing a booking, you’ll
                  receive a confirmation email with all the details of your rental.
                </li>
                <li>
                  <strong>Convenient Pick-Up Points:</strong> Choose a location close to you
                  during the booking process.
                </li>
                <li>
                  <strong>Check-In Requirements:</strong> Bring a valid photo ID, sign any
                  rental agreements if required, and inspect the bike.
                </li>
                <li>
                  <strong>Rental Duration Starts:</strong> Your rental begins as soon as you
                  pick up the bike. Be on time to maximize your rental period.
                </li>
              </ol>
            </div>
          </motion.section>

          {/* Drop-Off Process */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            variants={fadeInUp}
          >
            <div className="bg-gradient-to-r from-blue-500 to-indigo-500 px-8 py-6">
              <h2 className="text-2xl font-semibold text-white text-center">Drop-Off Process</h2>
            </div>
            <div className="px-8 py-6">
              <ol className="list-decimal list-inside space-y-4 text-gray-700">
                <li>
                  <strong>Return Location:</strong> Return the bike to the same location, or
                  as agreed with the bike owner.
                </li>
                <li>
                  <strong>Return Timing:</strong> Return the bike on time to avoid
                  additional charges.
                </li>
                <li>
                  <strong>Condition Check:</strong> Ensure the bike is in the same condition
                  as when picked up. Report any issues if needed.
                </li>
                <li>
                  <strong>Payment & Closing:</strong> Finalize any outstanding payments or
                  charges based on the rental agreement.
                </li>
              </ol>
            </div>
          </motion.section>

          {/* FAQ */}
          <motion.section variants={fadeInUp}>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 px-8 py-6">
                <h2 className="text-2xl font-semibold text-white text-center">Frequently Asked Questions</h2>
              </div>
              <div className="px-8 py-6 space-y-6">
                {[
                  {
                    q: 'Can I pick up a bike at one location and drop it off at another?',
                    a: 'Currently, all rentals must be returned to the same location unless otherwise agreed upon with the bike owner.',
                  },
                  {
                    q: 'What should I do if I’m running late for drop-off?',
                    a: 'If you’re unable to return the bike on time, please contact the bike owner directly or reach out to RideAway support. Additional charges may apply for late returns.',
                  },
                  {
                    q: 'Do I need to bring my own helmet?',
                    a: 'Helmets are generally provided with each rental. However, you’re welcome to bring your own if you prefer.',
                  },
                  {
                    q: 'What if the bike breaks down during my rental period?',
                    a: 'In case of mechanical issues, please contact Rideaway support or the bike owner immediately. We will help coordinate assistance or a replacement if possible.',
                  },
                  {
                    q: 'Are there extra charges for early or late pick-ups?',
                    a: 'Early pick-ups or late returns are subject to availability and may incur extra fees. Contact RideAway or the bike owner to confirm any timing changes.',
                  },
                ].map(({ q, a }) => (
                  <div key={q}>
                    <h3 className="text-lg font-medium text-gray-800">{q}</h3>
                    <p className="text-gray-600 pl-4">{a}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Contact */}
          <motion.section variants={fadeInUp}>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-teal-500 to-blue-500 px-8 py-6">
                <h2 className="text-2xl font-semibold text-white text-center">Contact Us</h2>
              </div>
              <div className="px-8 py-6 text-center text-gray-700">
                <p>
                  If you have any questions regarding our pick-up and drop-off policies, or if you need
                  assistance with a rental, don’t hesitate to reach out. We’re here to ensure your
                  experience with RideAway is enjoyable and convenient.
                </p>
              </div>
            </div>
          </motion.section>
        </motion.div>
      </div>
    </Layout>
  );
}
