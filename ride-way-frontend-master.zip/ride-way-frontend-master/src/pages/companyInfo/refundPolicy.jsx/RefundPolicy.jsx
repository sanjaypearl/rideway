/* src/pages/policies/RefundPolicy.jsx */
import React from "react";
import { motion } from "framer-motion";
import Layout from "../../../components/layout/Layout";

const sectionVariant = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const RefundPolicy = () => {
  return (
    <Layout>
      <div className="py-8 px-4 bg-gray-50">
        <div className="max-w-3xl mx-auto space-y-8">

          {/* Cancellation and Refund */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
          >
            <div className="bg-teal-50 px-6 py-4">
              <h2 className="text-xl font-semibold text-teal-700">
                Cancellation and Refund Policy
              </h2>
            </div>
            <div className="p-6 prose prose-teal">
              <ul className="list-disc list-inside space-y-3">
                <li>
                  <strong>Standard Cancellations:</strong> Cancellations made within 1 hour of the booking time are eligible for a 50% refund of the rental fee. Note that platform fees, service fees, and any additional charges are non refundable.
                </li>
                <li>
                  <strong>Processing Time:</strong> Refunds will be processed within 2-3 working days, subject to bank processing times and the renter's payment method.
                </li>
                <li>
                  <strong>Non-Refundable Circumstances:</strong> Cancellations due to failure to present ID, license, or other required documentation, late arrival for pickup, or violating these terms will not be eligible for refunds.
                </li>
              </ul>
            </div>
          </motion.section>

          {/* Booking and Collection */}
          <motion.section
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            initial="hidden"
            animate="show"
            variants={sectionVariant}
            transition={{ delay: 0.2 }}
          >
            <div className="bg-teal-50 px-6 py-4">
              <h2 className="text-xl font-semibold text-teal-700">
                Booking and Collection Policy
              </h2>
            </div>
            <div className="p-6 prose prose-teal">
              <ul className="list-disc list-inside space-y-3">
                <li>
                  <strong>Timely Pickup:</strong> Renters are required to pick up the vehicle at least one hour prior to the booking start time. Failure to collect the vehicle within this period will forfeit the booking, and no refund will be issued.
                </li>
                <li>
                  <strong>Verification on Collection:</strong> Renters must present a valid ID and booking confirmation at the time of pickup. Failure to provide necessary identification may result in denied access to the vehicle without a refund.
                </li>
                <li>
                  <strong>Return Policy:</strong> The vehicle must be returned by the specified end time to avoid additional charges or penalties.
                </li>
              </ul>
            </div>
          </motion.section>

        </div>
      </div>
    </Layout>
  );
};

export default RefundPolicy;
