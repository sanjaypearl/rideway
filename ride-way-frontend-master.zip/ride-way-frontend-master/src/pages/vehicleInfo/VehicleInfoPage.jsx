/* eslint-disable react/no-unescaped-entities */
import { BsWhatsapp } from "react-icons/bs";
import { FaFacebook } from "react-icons/fa";
import { RiInstagramFill } from "react-icons/ri";
import { Button } from "@material-tailwind/react";
import { useContext, useState } from "react";
import Layout from "../../components/layout/Layout";
import { useNavigate, useParams } from "react-router-dom";
import { useGetVehicleByIdQuery } from "../../redux/slices/vehicleApiSlice";
import { TicketMinus } from "lucide-react";
import VehicleReview from "../../components/review/VehicleReview";
import RatingStar from "../../components/review/RatingStar";
import VehicleAvailbilityModal from "./modal/VehicleAvailbilityModal";
import Meta from "../../components/seo/Meta";
import myContext from "../../context/myContext";

function ProductInfo() {
  const { id } = useParams();
  const { data: vehicle, error, isLoading } = useGetVehicleByIdQuery(id);
  const navigate = useNavigate();
  const [slideImage, setSlideImage] = useState("");
  const [selectedPlan, setSelectedPlan] = useState(null);
  const {
    lat,
    setLat,
    lng,
    setLng,
    vehicleType,
    vehicleCity,
    setVehicleCity,
    selectedCity,
    setSelectedCity,
    currentLocationName,
    setCurrentLocationName,
  } = useContext(myContext);

  const imageData = {
    image1: vehicle?.vehicleImage[0]?.url,
    image2: vehicle?.vehicleImage[1]?.url,
  };

  const { image1, image2 } = imageData;

  // Set default plan to the first pricing plan if available
  useState(() => {
    if (vehicle?.pricingPlans?.length > 0 && !selectedPlan) {
      setSelectedPlan(vehicle.pricingPlans[0]);
    }
  }, [vehicle]);

  return (
    <Layout>
      <Meta
        title={`Rental in ${selectedCity} - RideAway`}
        description={
          "Affordable rental services in India. Flexible booking options available."
        }
      />
      <section className="sm:py-1">
        <div className="container mx-auto px-4">
          <div className="lg:col-gap-12 xl:col-gap-16 mt-[0.9em] grid grid-cols-1 lg:mt-7 lg:grid-cols-1 lg:gap-1 w-full">
            <div className="lg:col-span-3 lg:row-end-1">
              <div className="lg:flex lg:items-start">
                <div className="lg:order-2 lg:ml-5">
                  <div className="overflow-hidden rounded-lg border flex justify-center">
                    <div className="flex justify-center">
                      {slideImage ? (
                        <img
                          style={{
                            filter: `${isLoading ? "blur(20px)" : ""}`,
                            transition: "1s filter linear",
                            background: "transparent",
                          }}
                          className="h-[20.2em] lg:h-[28em] w-96 lg:w-[32em] md:w-[15em]"
                          src={slideImage}
                          alt=""
                        />
                      ) : (
                        <img
                          style={{
                            filter: `${isLoading ? "blur(20px)" : ""}`,
                            transition: "1s filter linear",
                            background: "transparent",
                          }}
                          className="h-[20.2em] lg:h-[28em] w-96 lg:w-[32em] md:w-[15em]"
                          src={image1}
                          alt=""
                        />
                      )}
                    </div>
                  </div>
                </div>
                <div className="mt-3 hidden lg:block lg:mt-0 w-full lg:order-1 lg:w-32 lg:flex-shrink-0">
                  <div className="flex flex-row items-start lg:flex-col space-x-2 lg:space-x-0 justify-center">
                    {image1 && (
                      <button
                        type="button"
                        className="flex-0 aspect-square mb-3 h-16 overflow-hidden rounded-lg focus:border focus:border-[#b88ef6] border text-center"
                      >
                        <img
                          style={{
                            filter: `${isLoading ? "blur(20px)" : ""}`,
                            transition: "1s filter linear",
                            background: "transparent",
                          }}
                          onClick={() => setSlideImage(image1)}
                          className="h-full w-full"
                          src={image1}
                          alt=""
                        />
                      </button>
                    )}
                    {image2 && (
                      <button
                        type="button"
                        className="flex-0 aspect-square mb-3 h-16 overflow-hidden rounded-lg focus:border focus:border-[#b88ef6] border text-center"
                      >
                        <img
                          style={{
                            filter: `${isLoading ? "blur(20px)" : ""}`,
                            transition: "1s filter linear",
                            background: "transparent",
                          }}
                          onClick={() => setSlideImage(image2)}
                          className="h-full w-full object-cover"
                          src={image2}
                          alt=""
                        />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2 lg:row-span-2 lg:row-end-2 cursor-text">
              <h2 className="app-font mt-2 tracking-widest">RideAway</h2>
              <h1 className="sm:text-2xl font-bold text-gray-900 sm:text-3xl">
                {vehicle?.vehicleName}
              </h1>
              <div className="mt-2">
                <RatingStar
                  rating={vehicle?.vehicleRatings}
                  totalRating={vehicle?.numOfReviews}
                />
              </div>
              <div className="flex flex-wrap mt-5 items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div>
                    <h1 className="fontPara text-2xl">
                      ₹{" "}
                      {selectedPlan
                        ? selectedPlan.price
                        : vehicle?.pricingPlans[0].price}
                    </h1>
                  </div>
                  <div className="bg-green-600 px-2 app-font text-white text-sm animate-pulse">
                    {vehicle?.vehicleAvailability && "Available"}
                  </div>
                </div>
                <div className="flex items-center gap-2 cursor-pointer">
                  <BsWhatsapp size={24} />
                  <FaFacebook size={24} color="#316FF6" />
                  <RiInstagramFill size={24} color="#cd486b" />
                </div>
              </div>
              {/* Pricing Plans Selection */}
              <div className="mt-4">
                <h2 className="fontPara text-lg font-bold">Select Plan:</h2>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {vehicle?.pricingPlans?.map((plan) => (
                    <button
                      key={plan._id}
                      onClick={() => setSelectedPlan(plan)}
                      className={`border rounded-lg p-2 w-24 text-center ${
                        selectedPlan?._id === plan._id
                          ? "border-[#b88ef6] bg-purple-100"
                          : "border-gray-300 hover:border-[#b88ef6]"
                      }`}
                    >
                      <span className="fontPara text-sm">{plan.label}</span>
                      <br />
                      <span className="font-bold">₹ {plan.price}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="mb-2 mt-5">
                <div className="mb-4 border-b" />
                <div className="flex gap-4">
                  <VehicleAvailbilityModal vehicleId={vehicle?._id} />
                  <Button
                    onClick={() =>
                      navigate(
                        `/checkout/${vehicle?._id}?planId=${selectedPlan?._id}`
                      )
                    }
                    className="flex items-center justify-center rounded-md bg-slate-900 py-2.5 lg:px-5 lg:py-2 text-center text-[0.6em] lg:text-sm font-medium text-white primaryBgColor w-full hover:shadow-none shadow-none bg-green-500"
                  >
                    <TicketMinus className="mr-2 w-5 h-5 lg:h-6 lg:w-6" />
                    <span className="fontPara">Book Now</span>
                  </Button>
                </div>
                <div className="mt-4 mb-2 lg:mb-2 border-b" />
                <div className="lg:w-[36em] text-justify">
                  <div className="mb-2">
                    <h2 className="fontPara text-lg font-bold">Information:</h2>
                    <div className="flex items-center gap-2 mt-2 border p-2 border-green-300">
                      <h1 className="font-bold">VehicleType :</h1>
                      <h1 className="capitalize">{vehicle?.vehicleType}</h1>
                    </div>
                    <div className="flex items-center gap-2 mt-2 border p-2 border-green-300">
                      <h1 className="font-bold">VehicleModel :</h1>
                      <h1 className="capitalize">{vehicle?.vehicleModel}</h1>
                    </div>
                    <div className="flex items-center gap-2 mt-2 border p-2 border-green-300">
                      <h1 className="font-bold">SittingCapacity :</h1>
                      <h1 className="capitalize">{vehicle?.sittingCapacity}</h1>
                    </div>
                  </div>
                  <div>
                    <h2 className="fontPara text-lg font-bold">Description:</h2>
                    <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit.
                      Deserunt reiciendis ad eum consectetur velit alias quae id
                      laborum ea. Doloribus eveniet consectetur reiciendis. Ut,
                      quia corrupti. Modi, nisi? Voluptatibus, dicta!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <VehicleReview
              vehicleId={id}
              vehicle={vehicle}
              error={error}
              isLoading={isLoading}
            />
          </div>
        </div>
      </section>
    </Layout>
  );
}

export default ProductInfo;
