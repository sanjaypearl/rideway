import React, { useState } from "react";
import { CheckCircle, XCircle, ChevronDown, ChevronUp } from "lucide-react";
import Layout from "../../components/layout/Layout";

const SubscriptionPage = () => {
  const [openFAQ, setOpenFAQ] = useState(null);

  const toggleFAQ = (index) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  const faqs = [
    {
      question: "What is a RideAway subscription?",
      answer:
        "A subscription gives you access to a two-wheeler for a fixed monthly or quarterly period. It includes vehicle usage, maintenance, insurance, and customer support—just fuel it and ride.",
    },
    {
      question: "Who should choose a subscription over rental?",
      answer:
        "Subscriptions are ideal for students, gig workers, daily commuters, or anyone needing a two-wheeler for regular use without the burden of ownership or EMIs.",
    },
    {
      question: "What’s included in the subscription plan?",
      answer:
        "Your subscription covers the vehicle, insurance, periodic maintenance, and support. You’ll get a ready-to-ride two-wheeler with documents, helmet (optional), and roadside assistance in select plans.",
    },
    {
      question: "Is there a security deposit?",
      answer:
        "Yes, a fully refundable security deposit is collected based on the vehicle model and subscription duration. It’s returned at the end of the term after inspection.",
    },
    {
      question: "Can I switch or cancel my subscription?",
      answer:
        "Yes, you can upgrade, downgrade, or cancel your subscription with prior notice. Cancellation terms and refund details will be shared in your plan policy.",
    },
    {
      question: "What if the vehicle breaks down during my subscription?",
      answer:
        "We provide support for breakdowns, repairs, and maintenance. Contact us, and we’ll assist you with a quick resolution or replacement where available.",
    },
  ];

  return (
    <Layout>
      <div className="bg-white text-gray-800">
        {/* Hero */}
        <section className="py-12 px-4 md:px-16 bg-gradient-to-br from-[#e6f4ff] to-white">
          <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-10 items-center">
            <div className="bg-white shadow-lg rounded-2xl p-8 border">
              <h2 className="text-3xl font-bold mb-4">
                Your Ride, Your Way—Every Month
              </h2>
              <p className="mb-6">
                Get your own two-wheeler without buying one. With{" "}
                <strong>FlexiRide</strong>, pay once a month and cover all your
                ride essentials—hassle-free riding and support included.
              </p>
            </div>
            <div className="relative bg-[#d6f0ff] p-8 rounded-2xl shadow-lg">
              <p className="text-xl font-semibold">
                Na Loan ka Shor,
                <br />
                Na CIBIL ka Zor,
                <br />
                <span className="text-3xl text-red-600 font-bold">
                  Sirf ₹ 3999/-
                </span>
                <br />
                mein bike apni banaye with FlexiRide
              </p>
              <div className="mt-4 flex gap-2 flex-wrap text-sm">
                <span className="bg-red-500 text-white px-3 py-1 rounded-full">
                  Brand New!
                </span>
                <span className="bg-green-100 px-3 py-1 rounded-full">
                  ✅ Insurance Included
                </span>
                <span className="bg-yellow-100 px-3 py-1 rounded-full">
                  🔧 Free Servicing
                </span>
                <span className="bg-blue-100 px-3 py-1 rounded-full">
                  💳 No Down Payment
                </span>
              </div>
            </div>
          </div>
          <p className="text-center text-sm mt-8">
            Say goodbye to paperwork, service costs, and EMI stress
          </p>
        </section>

        {/* Comparison Table 2 */}
        <section className="py-12 px-4 md:px-16">
          <h3 className="text-2xl font-bold text-center mb-6">
            Why Leasing a Bike from Us is a Better Choice
          </h3>
          <div className="overflow-auto">
            <table className="min-w-full bg-white shadow-md rounded-lg text-left">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-4">Features</th>
                  <th className="p-4">Lease with Us</th>
                  <th className="p-4">Buying a Bike</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Easy monthly plans", true, true],
                  ["No loan or CIBIL check", true, false],
                  ["Instant online booking", true, false],
                  ["Doorstep delivery", true, true],
                  ["No resale worries", true, false],
                  ["Short- or long-term plans available", true, false],
                  ["Support via call/WhatsApp", true, true],
                ].map(([feature, lease, buy], i) => (
                  <tr key={i} className="border-t">
                    <td className="p-4">{feature}</td>
                    <td className="p-4">
                      {lease ? (
                        <CheckCircle size={18} className="text-green-600" />
                      ) : (
                        <XCircle size={18} className="text-red-600" />
                      )}
                    </td>
                    <td className="p-4">
                      {buy ? (
                        <CheckCircle size={18} className="text-green-600" />
                      ) : (
                        <XCircle size={18} className="text-red-600" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* reviws  */}
        <section className="py-12 px-4 md:px-16 bg-white">
          <h3 className="text-2xl font-bold mb-8 text-center">
            Here’s why customers choose us
          </h3>
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
            {[
              {
                name: "Javed Khan",
                role: "Tailor",
                review:
                  "I'm Javed Khan, a tailor from Faridabad, and I'm thrilled to share my amazing experience with RideAway! I stumbled upon their flexible plans and haven’t looked back.",
              },
              {
                name: "Neeresh",
                role: "Executive",
                review:
                  "I'm absolutely thrilled with my experience at RideAway! The subscription model is incredibly convenient and affordable. Everything from booking to delivery was smooth.",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-gray-50 shadow-sm rounded-xl p-6 relative border border-gray-200"
              >
                <div className="text-3xl text-cyan-400 absolute top-3 left-4">
                  “
                </div>
                <div className="pt-6 pl-6">
                  <div className="flex items-center mb-3">
                    {Array(5)
                      .fill(0)
                      .map((_, index) => (
                        <svg
                          key={index}
                          className="w-5 h-5 text-yellow-400"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.2 3.684a1 1 0 00.95.69h3.905c.969 0 1.371 1.24.588 1.81l-3.158 2.295a1 1 0 00-.364 1.118l1.2 3.684c.3.921-.755 1.688-1.54 1.118l-3.158-2.295a1 1 0 00-1.176 0l-3.158 2.295c-.784.57-1.838-.197-1.539-1.118l1.2-3.684a1 1 0 00-.364-1.118L2.316 9.111c-.783-.57-.38-1.81.588-1.81h3.905a1 1 0 00.95-.69l1.2-3.684z" />
                        </svg>
                      ))}
                  </div>
                  <p className="text-gray-700 mb-4">{item.review}</p>
                  <div className="font-semibold">{item.name}</div>
                  <div className="text-sm text-gray-500">{item.role}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* FAQs */}
        <section className="py-12 px-4 md:px-16 bg-gray-50">
          <h3 className="text-2xl font-bold mb-6 text-center">
            Subscription FAQs – RideAway
          </h3>
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white shadow-sm rounded-md">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex justify-between items-center px-6 py-4 text-left font-semibold text-gray-800"
                >
                  {faq.question}
                  {openFAQ === index ? (
                    <ChevronUp size={20} />
                  ) : (
                    <ChevronDown size={20} />
                  )}
                </button>
                {openFAQ === index && (
                  <div className="px-6 pb-4 text-gray-600">{faq.answer}</div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default SubscriptionPage;
