/* pages/AdminLoginPage.jsx */
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import LoginForm from "@/components/registration/LoginForm";
import authService from "../../services/authService";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const user = authService.getCurrentUser();

  useEffect(() => {
    // If already logged in and role is admin, redirect directly
    if (user && user.role === "admin") {
      navigate("/admin-dashboard/admin-home-page");
    }
  }, [user, navigate]);

  const noop = () => {};

  const handleClose = () => {
    // After successful OTP verification, go to dashboard
    navigate("/admin-dashboard/admin-home-page");
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="w-full max-w-sm rounded-xl bg-white shadow-lg p-6 space-y-6">
        <h1 className="text-center text-2xl font-bold text-green-600">
          Admin Sign In
        </h1>

        <LoginForm
          role="admin"
          switchToSignup={noop}
          switchToForgotPassword={noop}
          handleClose={handleClose}
        />
      </div>
    </main>
  );
}
