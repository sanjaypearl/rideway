import {
  useGetAllHostsQuery,
  useVerifyHostMutation,
  useDeleteHostMutation,
} from "@/redux/slices/adminApiSlice";
import Layout from "@/components/layout/Layout";
import { Spinner } from "@material-tailwind/react";
import { useState } from "react";
import { Eye, Trash, CheckCircle2 } from "lucide-react";

const AllHostsPage = () => {
  const [search, setSearch] = useState("");
  const [verifiedFilter, setVerifiedFilter] = useState("");
  const [cityFilter, setCityFilter] = useState("");
  const [page, setPage] = useState(1);
  const limit = 9;

  const { data, isLoading, error } = useGetAllHostsQuery({
    page,
    limit,
    approved: verifiedFilter,
    city: cityFilter,
    search,
  });

  const [verifyHost, { isLoading: isVerifying }] = useVerifyHostMutation();
  const [deleteHost, { isLoading: isDeleting }] = useDeleteHostMutation();

  const handleFilterChange = (setter) => (e) => {
    setPage(1);
    setter(e.target.value);
  };

  const handleVerify = async (id) => {
    if (!confirm("Confirm host verification?")) return;
    await verifyHost(id);
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this host?")) return;
    await deleteHost(id);
  };

  const totalPages = Math.ceil(data?.total / limit) || 1;

  return (
    <section className="px-4 py-6">
      <h1 className="text-2xl font-bold mb-4">All Host Applications</h1>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <input
          type="text"
          placeholder="Search by name/email"
          value={search}
          onChange={handleFilterChange(setSearch)}
          className="px-3 py-2 border rounded w-full md:w-1/3"
        />
        <input
          type="text"
          placeholder="Filter by city"
          value={cityFilter}
          onChange={handleFilterChange(setCityFilter)}
          className="px-3 py-2 border rounded w-full md:w-1/3"
        />
        <select
          value={verifiedFilter}
          onChange={handleFilterChange(setVerifiedFilter)}
          className="px-3 py-2 border rounded w-full md:w-1/3"
        >
          <option value="">All</option>
          <option value="true">Verified</option>
          <option value="false">Pending</option>
        </select>
      </div>

      {/* Loading/Error */}
      {isLoading ? (
        <div className="flex justify-center py-10">
          <Spinner className="h-10 w-10 text-green-500" />
        </div>
      ) : error ? (
        <div className="text-center text-red-500">
          {error?.data?.error || "Failed to fetch hosts"}
        </div>
      ) : (
        <>
          {/* Table View */}
          <div className="overflow-auto">
            <table className="min-w-full border border-gray-200 rounded-lg overflow-hidden text-sm">
              <thead className="bg-gray-100 font-semibold text-gray-700">
                <tr>
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">Email</th>
                  <th className="p-3 text-left">Phone</th>
                  <th className="p-3 text-left">City</th>
                  <th className="p-3 text-left">Vehicle</th>
                  <th className="p-3 text-left">Model</th>
                  <th className="p-3 text-left">Reg. No.</th>
                  <th className="p-3 text-left">Owns</th>
                  <th className="p-3 text-left">Aadhaar</th>
                  <th className="p-3 text-left">License</th>
                  <th className="p-3 text-left">RC</th>
                  <th className="p-3 text-left">Insurance</th>
                  <th className="p-3 text-left">PUC</th>
                  <th className="p-3 text-left">Status</th>
                  <th className="p-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody className="text-gray-700">
                {data?.hosts?.length > 0 ? (
                  data.hosts.map((host) => (
                    <tr key={host._id} className="border-t">
                      <td className="p-3">{host.fullName}</td>
                      <td className="p-3">{host.email}</td>
                      <td className="p-3">{host.phone}</td>
                      <td className="p-3">{host.city}</td>
                      <td className="p-3">{host.vehicleType}</td>
                      <td className="p-3">{host.makeModel}</td>
                      <td className="p-3">{host.registrationNumber}</td>
                      <td className="p-3">{host.ownsVehicle ? "Yes" : "NO"}</td>
                      <td className="p-3">
                        {host.aadhaarUrl ? (
                          <a
                            href={host.aadhaarUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="View Aadhaar"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="p-3">
                        {host.licenseUrl ? (
                          <a
                            href={host.licenseUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="View License"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="p-3">
                        {host.rcUrl ? (
                          <a
                            href={host.rcUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="View RC"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="p-3">
                        {host.insuranceUrl ? (
                          <a
                            href={host.insuranceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="View Insurance"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>
                      <td className="p-3">
                        {host.pucUrl ? (
                          <a
                            href={host.pucUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="View PUC"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>

                      <td className="p-3">
                        <span
                          className={
                            host.approved
                              ? "text-green-600 font-medium"
                              : "text-yellow-600 font-medium"
                          }
                        >
                          {host.approved ? "Verified" : "Pending"}
                        </span>
                      </td>
                      <td className="p-3 flex items-center gap-2">
                        {!host.approved && (
                          <button
                            onClick={() => handleVerify(host._id)}
                            disabled={isVerifying}
                            title="Verify Host"
                            className="text-green-600 hover:text-green-800 disabled:opacity-50"
                          >
                            <CheckCircle2 className="w-5 h-5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(host._id)}
                          disabled={isDeleting}
                          title="Delete Host"
                          className="text-red-600 hover:text-red-800 disabled:opacity-50"
                        >
                          <Trash className="w-5 h-5" />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="15" className="text-center p-4 text-gray-500">
                      No hosts found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-6 gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`px-3 py-1 border rounded ${
                    p === page ? "bg-indigo-500 text-white" : "bg-white"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default AllHostsPage;
