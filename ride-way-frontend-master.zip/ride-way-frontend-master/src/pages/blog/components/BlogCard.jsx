import React from "react";
import { motion } from "framer-motion";
import { Button } from "@material-tailwind/react";
import { Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";
import parse from "html-react-parser";
import { useGetBlogsQuery } from '@/redux/slices/blogApi';

const FALLBACK_IMAGE = "https://via.placeholder.com/400x200?text=No+Thumbnail";

const BlogPostCard = () => {
  const navigate = useNavigate();
  const { data, isLoading, error } = useGetBlogsQuery();

  const containerVariants = {
    hidden: {},
    show: { transition: { staggerChildren: 0.1 } },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
  };

  // Function to strip HTML tags for preview
  const getPreviewText = (html) => {
    const text = parse(html, {
      replace: (domNode) => {
        if (domNode.type === "text") return domNode.data;
        return "";
      },
    });
    return typeof text === "string" ? text.slice(0, 100) + "..." : "";
  };

  if (isLoading) return <p className="text-center text-gray-600">Loading blogs...</p>;

  if (error)
    return (
      <p className="text-center text-red-500">
        Error loading blogs: {error?.data?.error || "Please try again later."}
      </p>
    );

  const blogList = data || [];
  return (
    <section className="bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="flex flex-wrap -mx-4"
          variants={containerVariants}
          initial="hidden"
          animate="show"
        >
          {blogList.length > 0 ? (
            blogList.map((item) => (
              <motion.div
                key={item._id}
                className="w-full md:w-1/2 lg:w-1/3 px-4 mb-8"
                variants={cardVariants}
              >
                <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transform hover:-translate-y-2 transition">
                  <div
                    className="h-48 w-full overflow-hidden rounded-t-2xl cursor-pointer"
                    onClick={() => navigate(`/bloginfo/${item._id}`)}
                    role="button"
                    aria-label={`View blog: ${item.title}`}
                  >
                    <img
                      src={item.thumbnail?.url || FALLBACK_IMAGE}
                      alt={item.title || "Blog thumbnail"}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6 flex flex-col h-full">
                    <div className="flex justify-between items-center mb-4 text-gray-600">
                      <div className="flex items-center space-x-4">
                        <span className="flex items-center space-x-1 text-sm">
                          <Eye className="w-5 h-5 text-blue-500" />
                          <span>BY Rideway </span>
                        </span>
                      </div>
                      <time className="text-xs text-gray-400">
                        {new Date(item.date).toLocaleDateString()}
                      </time>
                    </div>
                    <h2 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h2>
                    <p className="text-gray-700 flex-1 mb-6">
                      {/* You can replace item.content with a real field if your API includes it */}
                      {getPreviewText(item.content || "No content available.")}
                    </p>
                    <Button
                      onClick={() => navigate(`/bloginfo/${item._id}`)}
                      className="mt-auto bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white rounded-full py-2 transition"
                      aria-label={`Read more about ${item.title}`}
                    >
                      Read More
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <p className="text-center w-full text-gray-500">No posts found.</p>
          )}
        </motion.div>
      </div>
    </section>
  );
};

export default BlogPostCard;
