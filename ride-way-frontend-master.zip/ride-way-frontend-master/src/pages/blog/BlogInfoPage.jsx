import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@material-tailwind/react";
import parse from "html-react-parser";
import { useGetSingleBlogQuery } from "@/redux/slices/blogApi";
import Layout from "../../components/layout/Layout";

const FALLBACK_IMAGE = "https://via.placeholder.com/400x200?text=No+Thumbnail";

const BlogInfoPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading, error } = useGetSingleBlogQuery(id);

  const blog = data;

  if (isLoading)
    return <p className="text-center text-gray-600">Loading blog...</p>;

  if (error)
    return (
      <p className="text-center text-red-500">
        Error loading blog: {error?.data?.error || "Please try again."}
      </p>
    );

  if (!blog)
    return <p className="text-center text-gray-500">Blog not found.</p>;

  return (
    <Layout>
      <section className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-md p-8">
            <img
              src={blog.thumbnail?.url || FALLBACK_IMAGE}
              alt={blog.title || "Blog thumbnail"}
              className="w-full h-64 object-cover rounded-lg mb-6"
            />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {blog.title}
            </h1>
            <div className="flex justify-between items-center mb-6 text-gray-600">
              <div className="flex items-center space-x-4">
                <span className="text-sm">By {blog.author}</span>
                {/* <span className="text-sm">{blog.views || 0} Views</span> */}
              </div>
              <time className="text-sm">
                {new Date(blog.date).toLocaleDateString()}
              </time>
            </div>
            <div className="text-gray-700 mb-6 prose max-w-none">
              {parse(blog.content)}
            </div>
            <Button
              onClick={() => navigate("/blog")}
              className="bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white rounded-full py-2 transition"
              aria-label="Back to blogs"
            >
              Back to Blogs
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BlogInfoPage;
