import { useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import ReactGA from "react-ga";
import { Toaster } from "react-hot-toast";

// Layout & Common Components
import ScrollTop from "./components/scrollTop/scrollTop";
import TopAlert from "./components/alert/TopAlert";
import Schema from "./components/seo/Schema";

// Pages
import HomePage from "./pages/home/HomePage";
import AboutPage from "./pages/about/AboutPage";
import ContactPage from "./pages/contact/ContactPage";
import NoPage from "./pages/noPage/NoPage";
import ListShopPage from "./pages/listShop/ListShopPage";
import ListShopMessage from "./pages/listShop/ListShopMessage";
import VehicleInfoPage from "./pages/vehicleInfo/VehicleInfoPage";
import AllVehiclePage from "./pages/allVehicles/AllVehiclePage";
import CheckoutPage from "./pages/checkoutPage/CheckoutPage";
import PaymentSuccessPage from "./pages/paymentSuccessPage/PaymentSuccessPage";
import PaymentCancelPage from "./pages/paymentSuccessPage/PaymentCancelPage";
import PaymentCanceledByUser from "./pages/paymentSuccessPage/PaymentCanceledByUser";
import BlogPage from "./pages/blog/BlogPage";
import BlogInfoPage from "./pages/blog/BlogInfoPage";
import ResetPasswordPage from "./pages/resetPassword/ResetPasswordPage";

// Company Info Pages
import PrivacyPolicy from "./pages/companyInfo/privacyPolicy/PrivacyPolicy";
import RefundPolicy from "./pages/companyInfo/refundPolicy.jsx/RefundPolicy";
import TermsAndConditionPage from "./pages/companyInfo/termsAndConditionPage/TermsAndConditionPage";
import ShippingAndDelivery from "./pages/companyInfo/shippingAndDelivery/ShippingAndDelivery";
import WhyRideroz from "./pages/companyInfo/whyRideroz/WhyRideroz";
import HowItWorks from "./pages/companyInfo/howItWorks/HowItWorks";
import Safety from "./pages/companyInfo/safety/Safety";
import DiscountCoupon from "./pages/companyInfo/discountCoupon/DiscountCoupon";
import PickUpAndDropOff from "./pages/companyInfo/pickUpAndDropOff/PickUpAndDropOff";

// FAQs
import FAQSection from "./pages/faq/FAQSection";
import AllFAQs from "./pages/faq/AllFaq";

// Context
import MyState from "./context/myState";

// Protected Route Wrapper
import { ProtectedRoute } from "./protectedRoutes/ProtectedRoute";

// Dashboards
import SuperAdminDashboard from "./pages/dashboard/super-admin/SuperAdminDashboard";
import SuperAdminHomePage from "./pages/dashboard/super-admin/pages/SuperAdminHomePage";
import SuperAdminAddRoleAndView from "./pages/dashboard/super-admin/pages/SuperAdminAddRoleAndView";
import SuperAdminViewAndAddCityPage from "./pages/dashboard/super-admin/pages/SuperAdminViewAndAddCityPage";
import SuperAdminAddAndViewEmployeePage from "./pages/dashboard/super-admin/pages/SuperAdminAddAndViewEmployeePage";
import SuperAdminViewUserAndShopOwnerPage from "./pages/dashboard/super-admin/pages/SuperAdminViewUserAndShopOwnerPage";
import SuperAdminUserProfilePage from "./pages/dashboard/super-admin/pages/SuperAdminUserProfilePage";
import SuperAdminGetOrderByShopOwner from "./pages/dashboard/super-admin/pages/SuperAdminGetOrderByShopOwner";
import SuperAdminViewShopOwnerVehiclePage from "./pages/dashboard/super-admin/pages/SuperAdminViewShopOwnerVehiclePage";
import SuperAdminCreateCouponAndViewCoupon from "./pages/dashboard/super-admin/pages/SuperAdminCreateCouponAndViewCoupon";

import UserDashboard from "./pages/dashboard/user/UserDashboard";
import UserHomePage from "./pages/dashboard/user/pages/UserHomePage";
import UserVehicleBookPage from "./pages/dashboard/user/pages/UserVehicleBookPage";
import UserProfilePage from "./pages/dashboard/user/pages/UserProfilePage";

import ShopOwnerDashboard from "./pages/dashboard/shopOwner/ShopOwnerDashboard";
import ShopOwnerHomePage from "./pages/dashboard/shopOwner/pages/ShopOwnerHomePage";
import ShopOwnerAddVehiclePage from "./pages/dashboard/shopOwner/pages/ShopOwnerAddVehiclePage";
import ShopOwnerViewVehicle from "./pages/dashboard/shopOwner/pages/ShopOwnerViewVehicle";
import ShopOwnerUserProfilePage from "./pages/dashboard/shopOwner/pages/ShopOwnerUserProfilePage";
import ShopOwnerVehicleBookPage from "./pages/dashboard/shopOwner/pages/ShopOwnerVehicleBookPage";
import ShopOwnerSettelementPage from "./pages/dashboard/shopOwner/pages/ShopOwnerSettelementPage";

import ViewUserBookingInvoice from "./components/common/bookedVehicles/pages/ViewUserBookingInvoice";
import AdminLoginPage from "./pages/admin/AdminLoginPage";
import BecomeHost from "./pages/host/BecomeHost";
import AllHostsPage from "./pages/admin/AllHostsPage";
import PaymentResult from "./pages/checkoutPage/PaymentResult";
import AddBlogPage from "./pages/admin/AddBlogPage";
import SubscriptionPage from "./pages/subscription/SubscriptionPage";
import AllContactsPage from "./pages/admin/AllContactsPage";

// Page View Tracker
function usePageViews() {
  const location = useLocation();
  useEffect(() => {
    ReactGA.pageview(location.pathname + location.search);
  }, [location]);
}

function App() {
  ReactGA.initialize("UA-XXXXXX-X"); // Replace with your actual GA ID
  usePageViews();

  return (
    <MyState>
      <Schema />
      <Toaster />
      <ScrollTop />
      <TopAlert />

      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/become-host" element={<BecomeHost />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/host" element={<ListShopPage />} />
        <Route path="/subscription" element={<SubscriptionPage />} />
        <Route path="/list-shop-message" element={<ListShopMessage />} />
        <Route path="/vehicle-info/:city/:id" element={<VehicleInfoPage />} />
        <Route
          path="/all-vehicles/:city?/:currentLocation?"
          element={<AllVehiclePage />}
        />

        <Route
          path="/checkout/:id"
          element={
            <ProtectedRoute requiredRole="user">
              <CheckoutPage />
            </ProtectedRoute>
          }
        />

        <Route path="/payment/result" element={<PaymentResult />} />
        <Route
          path="/success-payment/:paymentId"
          element={<PaymentSuccessPage />}
        />
        <Route path="/payment-cancel" element={<PaymentCancelPage />} />
        <Route
          path="/payment-cancel-by-user"
          element={<PaymentCanceledByUser />}
        />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/refund-policy" element={<RefundPolicy />} />
        <Route
          path="/terms-and-condition"
          element={<TermsAndConditionPage />}
        />
        <Route
          path="/shipping-and-delivery"
          element={<ShippingAndDelivery />}
        />
        <Route path="/why-rideroz" element={<WhyRideroz />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/safety" element={<Safety />} />
        <Route path="/discount-coupons" element={<DiscountCoupon />} />
        <Route path="/faqs" element={<AllFAQs />} />
        <Route
          path="/rental-pickup-and-drop-off"
          element={<PickUpAndDropOff />}
        />
        <Route path="/reset-password/:token" element={<ResetPasswordPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/bloginfo/:id" element={<BlogInfoPage />} />
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route path="/*" element={<NoPage />} />

        {/* User Protected Routes */}
        <Route
          path="user-dashboard"
          element={
            <ProtectedRoute requiredRole={"user"}>
              <UserDashboard />
            </ProtectedRoute>
          }
        >
          <Route path="user-home-page" element={<UserHomePage />} />
          <Route path="user-vehicle-book" element={<UserVehicleBookPage />} />
          <Route
            path="user-home-page/user-vehicle-book/vehicle-book-invoice/:id"
            element={<ViewUserBookingInvoice />}
          />

          <Route
            path="user-profile"
            element={
              <ProtectedRoute requiredRole={"user"}>
                <UserProfilePage />
              </ProtectedRoute>
            }
          ></Route>

        </Route>
        <Route
          path="admin-dashboard"
          element={
            <ProtectedRoute requiredRole="admin">
              <SuperAdminDashboard />
            </ProtectedRoute>
          }
        >
          {/* Home & Profile */}
          <Route path="admin-home-page" element={<SuperAdminHomePage />} />
          <Route path="admin-blog-page" element={<AddBlogPage />} />
          <Route path="get-all-contact" element={<AllContactsPage />} />
          <Route path="admin-profile" element={<SuperAdminUserProfilePage />} />

          {/* Host Management */}
          <Route path="get-all-host" element={<AllHostsPage />} />

          {/* Cities */}
          <Route
            path="view-and-add-city"
            element={<SuperAdminViewAndAddCityPage />}
          />

          {/* Roles & Employees */}
          <Route
            path="view-and-add-roles-and-department"
            element={<SuperAdminAddRoleAndView />}
          />
          <Route
            path="add-and-view-employee"
            element={<SuperAdminAddAndViewEmployeePage />}
          />

          {/* Users & Shop Owners */}
          <Route
            path="view-user-and-shop-owner"
            element={<SuperAdminViewUserAndShopOwnerPage />}
          />
          <Route
            path="view-user-and-shop-owner/admin-get-order-by-shop-owner/:shopId"
            element={<SuperAdminGetOrderByShopOwner />}
          />
          <Route
            path="view-user-and-shop-owner/admin-view-shop-owner-vehicle/:shopId"
            element={<SuperAdminViewShopOwnerVehiclePage />}
          />

          {/* Bookings & Coupons */}
          <Route
            path="admin-vehicle-book"
            element={<ShopOwnerVehicleBookPage />}
          />
          <Route
            path="admin-home-page/admin-vehicle-book/vehicle-book-invoice/:id"
            element={<ViewUserBookingInvoice />}
          />
          <Route
            path="create-coupon-code-and-view-coupon-code"
            element={<SuperAdminCreateCouponAndViewCoupon />}
          />

          {/* Shop Management */}
          <Route
            path="admin-add-vehicle"
            element={<ShopOwnerAddVehiclePage />}
          />
          <Route path="admin-all-vehicle" element={<ShopOwnerViewVehicle />} />
          <Route
            path="admin-vehicle-book"
            element={<ShopOwnerVehicleBookPage />}
          />
        </Route>
      </Routes>
    </MyState>
  );
}

export default App;
