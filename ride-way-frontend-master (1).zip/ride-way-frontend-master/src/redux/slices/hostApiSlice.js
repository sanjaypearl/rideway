// features/api/hostApiSlice.js
import apiSlice from "./apiSlice";

export const hostApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    // ✅ Step 1: Initiate host sign-up (send OTP, upload Aadhaar + License)
    signUpHostInitiate: builder.mutation({
      query: (formData) => ({
        url: "/auth/host/signup-initiate",
        method: "POST",
        body: formData,
      }),
    }),

    // ✅ Step 2: Verify OTP and complete registration
    signUpHostVerify: builder.mutation({
      query: (body) => ({
        url: "/auth/host/signup-verify",
        method: "POST",
        body,
      }),
    }),
  }),
});

export const {
  useSignUpHostInitiateMutation,
  useSignUpHostVerifyMutation,
} = hostApiSlice;
