import apiSlice from "../slices/apiSlice";

export const paymentApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    verifyPayment: builder.mutation({
      query: ({ razorpay_payment_id = "", razorpay_payment_link_id = "", razorpay_signature = "", reference_id }) => {
        if (!reference_id) throw new Error("Missing reference_id");

        return {
          url: `/payment/verify?reference_id=${reference_id}`,
          method: "PUT",
          body: {
            razorpay_payment_id,
            razorpay_payment_link_id,
            razorpay_signature,
          },
          headers: {
            "auth-token": JSON.parse(localStorage.getItem("token")) || "",
          },
        };
      },
      keepUnusedDataFor: 3600,
      onQueryStarted: async (paymentData, { queryFulfilled }) => {
        try {
          const { data } = await queryFulfilled;
          console.log("✅ Payment verified:", data.message);
        } catch (error) {
          console.error("❌ Payment verification failed:", error);
        }
      },
    }),
  }),
  overrideExisting: false,
});

export const { useVerifyPaymentMutation } = paymentApiSlice;
