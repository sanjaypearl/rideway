import toast from 'react-hot-toast';
import apiSlice from './apiSlice';

export const userApi = apiSlice.injectEndpoints({
  tagTypes: ['User'],
  endpoints: (builder) => ({

    // ──────────────────────────────── SIGNUP
    signUpUser: builder.mutation({
      query: (newUser) => ({
        url: '/user/signUp',
        method: 'POST',
        body: newUser,
      }),
      invalidatesTags: ['User'],
      async onQueryStarted(arg, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          toast.success(data?.message || 'Signup successful');
        } catch (err) {
          toast.error(err?.error?.data?.error || 'Signup failed');
        }
      },
    }),

    // ──────────────────────────────── SEND OTP
    sendOtp: builder.mutation({
      query: ({ mobile }) => ({
        url: '/auth/send-otp',
        method: 'POST',
        body: { mobile },
      }),
    }),

    // ──────────────────────────────── VERIFY OTP
    verifyOtp: builder.mutation({
      query: ({ mobile, otp }) => ({
        url: '/auth/verify-otp',
        method: 'POST',
        body: { mobile, otp },
      }),
    }),

    // ──────────────────────────────── GET USERS
    getUsers: builder.query({
      query: ({ search = '', page = 1, limit = 10 }) => ({
        url: '/user/get-users',
        params: { search, page, limit },
        headers: {
          'auth-token': JSON.parse(localStorage.getItem('token')),
        },
      }),
      providesTags: (result) =>
        result
          ? [
              ...result.users.map(({ _id }) => ({ type: 'User', id: _id })),
              { type: 'User', id: 'LIST' },
            ]
          : [{ type: 'User', id: 'LIST' }],
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),

    // ──────────────────────────────── EDIT USER
    editUser: builder.mutation({
      query: ({ id, updatedData }) => ({
        url: `/user/edit-user/${id}`,
        method: 'PUT',
        body: updatedData,
        headers: {
          'auth-token': JSON.parse(localStorage.getItem('token')),
        },
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'User', id }],
      onQueryStarted: async ({ id, updatedData }, { dispatch, queryFulfilled }) => {
        const patchResult = dispatch(
          userApi.util.updateQueryData('getUsers', { page: 1, limit: 10 }, (draft) => {
            if (draft?.users) {
              const userToUpdate = draft.users.find((user) => user._id === id);
              if (userToUpdate) Object.assign(userToUpdate, updatedData);
            }
          })
        );
        try {
          await queryFulfilled;
        } catch {
          patchResult.undo();
        }
      },
    }),

    // ──────────────────────────────── DELETE USER
    deleteUser: builder.mutation({
      query: (id) => ({
        url: `/user/delete-user/${id}`,
        method: 'DELETE',
        headers: {
          'auth-token': JSON.parse(localStorage.getItem('token')),
        },
      }),
      invalidatesTags: (result, error, id) => [{ type: 'User', id }],
      onQueryStarted: async (id, { dispatch, queryFulfilled }) => {
        const patchResult = dispatch(
          userApi.util.updateQueryData('getUsers', { page: 1, limit: 10 }, (draft) => {
            if (draft?.users) {
              draft.users = draft.users.filter((user) => user._id !== id);
            }
          })
        );
        try {
          const { data } = await queryFulfilled;
          toast.success(data?.message || 'User deleted');
        } catch (err) {
          toast.error(err?.error?.data?.error || 'Delete failed');
          patchResult.undo();
        }
      },
    }),

    // ──────────────────────────────── GET USER BY ID
    getUserById: builder.query({
      query: (id) => ({
        url: `/user/get-user/${id}`,
        headers: {
          'auth-token': JSON.parse(localStorage.getItem('token')),
        },
      }),
      providesTags: (result, error, id) => [{ type: 'User', id }],
      keepUnusedDataFor: 3600,
      refetchOnFocus: true,
      refetchOnReconnect: true,
      refetchOnMountOrArgChange: true,
    }),
  }),
});

export const {
  useSignUpUserMutation,
  useSendOtpMutation,
  useVerifyOtpMutation,
  useGetUsersQuery,
  useEditUserMutation,
  useDeleteUserMutation,
  useGetUserByIdQuery,
} = userApi;
