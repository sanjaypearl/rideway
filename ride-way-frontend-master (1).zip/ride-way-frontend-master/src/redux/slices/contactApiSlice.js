import toast from "react-hot-toast";
import apiSlice from "./apiSlice";

export const contactApi = apiSlice.injectEndpoints({
  tagTypes: ["Contact"],
  endpoints: (builder) => ({
    // POST /contact (public submit form)
    createContact: builder.mutation({
      query: (contactData) => ({
        url: "contacts",
        method: "POST",
        body: contactData,
      }),
      onQueryStarted: async (_, { queryFulfilled }) => {
        try {
          const { data } = await queryFulfilled;
          toast.success(data?.message || "Message sent successfully");
        } catch (error) {
          toast.error(error?.error?.data?.error || "Failed to send message");
        }
      },
    }),

    getAllContacts: builder.query({
      query: ({ search = "", page = 1, limit = 10 } = {}) => ({
        url: "contacts", // your route is "/contact"
        method: "GET",
        params: { search, page, limit },
        headers: {
          "auth-token": JSON.parse(localStorage.getItem("token")),
        },
      }),
      transformResponse: (data) => data,
      providesTags: ["Contact"],
      keepUnusedDataFor: 3600,
      refetchOnMountOrArgChange: true,
      refetchOnReconnect: true,
      refetchOnFocus: true,
    }),
  }),
});

export const { useCreateContactMutation, useGetAllContactsQuery } = contactApi;
