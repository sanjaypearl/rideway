const PaymentAndSecurity = () => {
  return (
    <div>PaymentAndSecurity</div>
  )
}

export default PaymentAndSecurity