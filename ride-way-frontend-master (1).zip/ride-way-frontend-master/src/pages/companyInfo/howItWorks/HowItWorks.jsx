import Layout from '../../../components/layout/Layout';

const HowItWorks = () => {
  return (
    <Layout>
      <div className="py-12 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-extrabold mb-12 text-gray-900">How It Works</h1>

          {/* User Section */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold mb-6 text-gray-800">For Users</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[ 
                { step: '1', title: 'Register', desc: 'Create an account to start exploring our bike options.' },
                { step: '2', title: 'Choose Your Bike', desc: 'Select a bike that suits your needs from our wide range.' },
                { step: '3', title: 'Book & Confirm', desc: 'Pick a rental duration and confirm your booking.' },
                { step: '4', title: 'Enjoy the Ride', desc: 'Pick up the bike and hit the road! Enjoy your trip.' },
              ].map(({ step, title, desc }) => (
                <div
                  key={step}
                  className="relative p-6 bg-white rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition"
                >
                  <div className="absolute -top-4 left-6 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {step}
                  </div>
                  <div className="mt-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
                    <p className="text-gray-600">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dealer Section */}
          <div className="mb-16">
            <h2 className="text-2xl font-semibold mb-6 text-gray-800">For Dealers</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { step: '1', title: 'Sign Up', desc: 'Register as a dealer to start listing your bikes.' },
                { step: '2', title: 'List Your Bikes', desc: 'Add details and photos of your rental bikes.' },
                { step: '3', title: 'Manage Bookings', desc: 'Stay on top of user bookings and availability.' },
                { step: '4', title: 'Earn & Grow', desc: 'Earn revenue and expand your business with us.' },
              ].map(({ step, title, desc }) => (
                <div
                  key={step}
                  className="relative p-6 bg-white rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition"
                >
                  <div className="absolute -top-4 left-6 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {step}
                  </div>
                  <div className="mt-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
                    <p className="text-gray-600">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HowItWorks;
