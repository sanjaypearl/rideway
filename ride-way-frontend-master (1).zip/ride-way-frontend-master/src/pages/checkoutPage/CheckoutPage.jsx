import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@material-tailwind/react";
import Layout from "../../components/layout/Layout";
import RatingStar from "../../components/review/RatingStar";
import UploadAdharImage from "./UploadAdharImage";
import LoginModal from "../../components/registration/LoginModal";
import authService from "../../services/authService";
import myContext from "../../context/myContext";
import dayjs from "dayjs";
import toast from "react-hot-toast";
import { BadgeIndianRupee } from "lucide-react";
import { useGetVehicleByIdQuery } from "../../redux/slices/vehicleApiSlice";
import { useCreateOrderMutation } from "../../redux/slices/orderApiSlice";
import { useGetCouponsQuery } from "../../redux/slices/couponApi";

const CartPage = () => {
  const user = authService.getCurrentUser();
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: vehicle } = useGetVehicleByIdQuery(id);
  const { data: coupons = [] } = useGetCouponsQuery();
  const [createOrder, { isLoading }] = useCreateOrderMutation();

  const {
    lat,
    setLat,
    lng,
    setLng,
    selectedCity,
    setSelectedCity,
    currentLocationName,
    setCurrentLocationName,
    showAlert,
    autoOpenLogin,
    setAutoOpenLogin,
  } = useContext(myContext);

  const [selectedPlan, setSelectedPlan] = useState(null);
  const [bookedDates, setBookedDates] = useState([]);
  const [formData, setFormData] = useState({
    startDate: "",
    startTime: "",
    endDate: "",
    endTime: "",
    shopAmount: 0,
    platformAmount: 0,
    miscAmount: 0,
    couponCode: "",
    discountAmount: 0,
    rentDuration: 0,
  });
  const [isCouponApplied, setIsCouponApplied] = useState(false);

  useEffect(() => {
    const storedCity = localStorage.getItem("selectedCity");
    const storedLat = localStorage.getItem("lat");
    const storedLng = localStorage.getItem("lng");
    const storedLocationName = localStorage.getItem("currentLocationName");

    if (storedCity) {
      setSelectedCity(storedCity);
      setLat(Number(storedLat));
      setLng(Number(storedLng));
      setCurrentLocationName(storedLocationName);
    }

    if (vehicle?.bookedDates) {
      setBookedDates(vehicle.bookedDates);
    }

    if (vehicle?.pricingPlans?.length > 0 && !selectedPlan) {
      const defaultPlan = vehicle.pricingPlans.find(p => p.durationInDays === 1) || vehicle.pricingPlans[0];
      setSelectedPlan(defaultPlan);
      setFormData((prev) => ({
        ...prev,
        shopAmount: defaultPlan.price,
      }));
    }
  }, [vehicle, setSelectedCity, setLat, setLng, setCurrentLocationName]);

  const handleDateTimeChange = (e, fieldName) => {
    const newDateTime = e.target.value;
    setFormData((prev) => {
      const updatedFormData = { ...prev };
      const dateTime = dayjs(newDateTime);
      if (fieldName === "startDateTime") {
        updatedFormData.startDate = dateTime.format("YYYY-MM-DD");
        updatedFormData.startTime = dateTime.format("HH:mm");
        if (selectedPlan?.durationInDays !== 1) {
          const endDateTime = dateTime.add(selectedPlan.durationInDays, "day");
          updatedFormData.endDate = endDateTime.format("YYYY-MM-DD");
          updatedFormData.endTime = endDateTime.format("HH:mm");
        }
      } else {
        updatedFormData.endDate = dateTime.format("YYYY-MM-DD");
        updatedFormData.endTime = dateTime.format("HH:mm");
      }

      // Calculate rentDuration in days
      if (updatedFormData.startDate && updatedFormData.endDate) {
        const start = dayjs(updatedFormData.startDate);
        const end = dayjs(updatedFormData.endDate);
        updatedFormData.rentDuration = end.diff(start, "day") + 1; // Include end date

        // Select appropriate plan or calculate price
        const matchingPlan = vehicle?.pricingPlans.find(
          (p) => p.durationInDays === updatedFormData.rentDuration
        );
        if (matchingPlan) {
          setSelectedPlan(matchingPlan);
          updatedFormData.shopAmount = matchingPlan.price;
        } else {
          const oneDayPlan = vehicle?.pricingPlans.find((p) => p.durationInDays === 1);
          if (oneDayPlan) {
            updatedFormData.shopAmount = oneDayPlan.price * updatedFormData.rentDuration;
          }
        }
      }

      return updatedFormData;
    });
  };

  const applyCoupon = () => {
    if (isCouponApplied) {
      showAlert("Coupon already applied!", "error");
      return;
    }

    const coupon = coupons.find(
      (c) => c.code === formData.couponCode && c.isActive
    );
    if (!coupon) {
      showAlert("Invalid Coupon Code", "error");
      return;
    }

    const discount =
      coupon.discountType === "percentage"
        ? formData.shopAmount * (coupon.discountValue / 100)
        : coupon.discountValue;

    setFormData((prev) => ({
      ...prev,
      discountAmount: Math.round(discount),
    }));
    setIsCouponApplied(true);
    showAlert("Coupon applied successfully!", "success");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (dayjs(`${formData.endDate}T${formData.endTime}`).isBefore(dayjs(`${formData.startDate}T${formData.startTime}`))) {
      showAlert("End date must be after start date.", "error");
      return;
    }

    try {
      const payload = {
        shopAmount: formData.shopAmount,
        platformAmount: formData.platformAmount,
        miscAmount: formData.miscAmount,
        couponCode: formData.couponCode,
        startDate: formData.startDate,
        startTime: formData.startTime,
        endDate: formData.endDate,
        endTime: formData.endTime,
        discountAmount: formData.discountAmount,
        rentDuration: formData.rentDuration,
      };

      const orderResponse = await createOrder({
        vehicleId: id,
        body: payload,
      }).unwrap();
      if (orderResponse.success && orderResponse.paymentLink) {
        window.location.href = orderResponse.paymentLink;
      }
    } catch (error) {
      if (
        error.status === 500 &&
        error.data?.error === "Access denied. Re-login"
      ) {
        setAutoOpenLogin(true);
      } else if (
        error.status === 404 &&
        error.data?.error === "User not found"
      ) {
        setAutoOpenLogin(true);
      }
      showAlert(
        error.data?.error || "Something went wrong during booking.",
        "error"
      );
    }
  };

  // Calculate total amount for display
  const totalAmount =
    formData.shopAmount +
    formData.platformAmount +
    formData.miscAmount -
    formData.discountAmount;

  return (
    <Layout>
      <div className="container mx-auto max-w-7xl px-2 lg:px-0">
        <div className="mx-auto max-w-2xl lg:max-w-7xl">
          <form className="lg:mt-10 lg:grid lg:grid-cols-12 lg:items-start lg:gap-x-12">
            <section className="mt-2.5 mb-5 lg:mt-0 lg:mb-0 rounded-md lg:col-span-4 bg-white shadow p-5 order-first lg:order-last">
              <div className="hidden lg:block">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900">
                  Checkout
                </h1>
              </div>
              <div className="mb-4">
                <h2 className="text-lg font-bold">Select Plan:</h2>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {vehicle?.pricingPlans?.map((plan) => (
                    <button
                      type="button"
                      key={plan._id}
                      onClick={() => {
                        setSelectedPlan(plan);
                        setFormData((prev) => ({
                          ...prev,
                          shopAmount: plan.price,
                          discountAmount: 0,
                          couponCode: "",
                        }));
                        setIsCouponApplied(false);
                      }}
                      className={`border rounded-lg p-2 w-24 text-center ${
                        selectedPlan?._id === plan._id
                          ? "border-purple-400 bg-purple-100"
                          : "border-gray-300 hover:border-purple-400"
                      }`}
                    >
                      <span className="text-sm">{plan.label}</span>
                      <br />
                      <span className="font-bold">₹ {plan.price}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2">
                  <label className="text-xs">Pickup Date & Time</label>
                  <input
                    type="datetime-local"
                    value={`${formData.startDate}T${formData.startTime}`}
                    onChange={(e) => handleDateTimeChange(e, "startDateTime")}
                    min={dayjs().format("YYYY-MM-DDTHH:mm")}
                    className="text-xs sm:text-sm p-2 w-full outline-none rounded border-gray-500 border"
                  />
                </div>
                <div className="mb-2">
                  <label className="text-xs">Drop off Date & Time</label>
                  <input
                    type="datetime-local"
                    value={`${formData.endDate}T${formData.endTime}`}
                    onChange={(e) => handleDateTimeChange(e, "endDateTime")}
                    min={dayjs().format("YYYY-MM-DDTHH:mm")}
                    disabled={selectedPlan?.durationInDays !== 1}
                    className={`text-xs sm:text-sm border p-2 w-full outline-none rounded border-gray-500 ${
                      selectedPlan?.durationInDays !== 1
                        ? "bg-gray-200 cursor-not-allowed"
                        : ""
                    }`}
                  />
                </div>
                <div>
                  <UploadAdharImage
                    formData={formData}
                    setFormData={setFormData}
                  />
                </div>
              </div>
              <div className="bg-blue-50 p-2 mt-4 border border-blue-100 rounded">
                <div className="flex justify-between items-center mb-1">
                  <p className="text-black">Coupons</p>
                  <p className="text-blue-700">
                    {formData.couponCode
                      ? `${
                          coupons.find((c) => c.code === formData.couponCode)
                            ?.discountValue || 0
                        }% OFF`
                      : "—"}
                  </p>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <img
                      className="w-8 h-8"
                      src="https://cdn-icons-png.flaticon.com/128/1041/1041885.png"
                      alt="coupon"
                    />
                    <h1 className="text-blue-500">Apply Coupon</h1>
                  </div>
                  <button
                    type="button"
                    onClick={applyCoupon}
                    disabled={
                      isCouponApplied ||
                      !formData.startDate ||
                      !formData.endDate ||
                      !formData.couponCode
                    }
                    className="bg-blue-600 px-2 text-white text-sm py-[2px] rounded-md"
                  >
                    Apply Now
                  </button>
                </div>
                <div className="mt-2">
                  <select
                    name="couponCode"
                    value={formData.couponCode}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        couponCode: e.target.value,
                      }))
                    }
                    disabled={
                      isCouponApplied ||
                      !formData.startDate ||
                      !formData.endDate
                    }
                    className="w-full p-2 border rounded text-sm"
                  >
                    <option value="">Select Coupon Code</option>
                    {coupons
                      .filter((c) => c.isActive)
                      .map((c) => (
                        <option key={c._id} value={c.code}>
                          {c.code} ({c.discountValue}
                          {c.discountType === "percentage" ? "%" : "₹"} OFF)
                        </option>
                      ))}
                  </select>
                </div>
                {formData.couponCode && (
                  <div className="flex items-center gap-2 mt-2">
                    <h1 className="text-sm text-blue-900">Coupon Code:</h1>
                    <h1 className="text-sm text-blue-600 animate-pulse">
                      {formData.couponCode}
                    </h1>
                  </div>
                )}
              </div>
              <div className="border mt-4 p-2 px-4 rounded-md shadow border-blue-400 text-black">
                <h1>
                  <span className="font-bold">Base Price ({formData.rentDuration || 1} {formData.rentDuration === 1 ? "day" : "days"}):</span> ₹ {formData.shopAmount}
                </h1>
                {formData.discountAmount > 0 && (
                  <p className="text-blue-500 text-sm">
                    Discount Amount: ₹ {formData.discountAmount}
                  </p>
                )}
                <h1 className="mt-2">
                  <span className="font-bold">Total Amount:</span> ₹ {totalAmount}
                </h1>
              </div>
              <div className="mt-4">
                <Button
                  className="hover:shadow-none shadow-none w-full bg-blue-500"
                  onClick={handleSubmit}
                  disabled={
                    isLoading || !formData.startDate || !formData.endDate
                  }
                >
                  Confirm
                </Button>
              </div>
            </section>
            <section className="shadow bg-white py-4 border px-4 lg:col-span-8 rounded">
              <div className="hidden lg:block">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900">
                  Checkout
                </h1>
              </div>
              <div className="bg-white shadow mb-4 px-4 py-4">
                <h1 className="mb-2">
                  <span className="font-bold">City:</span> {selectedCity}
                </h1>
                <h1>
                  <span className="font-bold">Current Location:</span>{" "}
                  {currentLocationName || "N/A"}
                </h1>
              </div>
              <div className="bg-white shadow mb-2">
                <ul role="list" className="divide-y divide-gray-200">
                  <li className="flex py-6">
                    <div className="flex-shrink-0">
                      <img
                        src={vehicle?.vehicleImage[0]?.url}
                        alt={vehicle?.vehicleName}
                        className="h-24 w-24 rounded-md object-contain object-center sm:h-38 sm:w-38"
                      />
                    </div>
                    <div className="ml-4 flex flex-1 flex-col justify-between sm:ml-6">
                      <div className="relative pr-9 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:pr-0">
                        <div>
                          <div className="flex justify-between">
                            <h3 className="text-sm">
                              <a className="font-semibold text-black">
                                {vehicle?.vehicleName}
                              </a>
                            </h3>
                          </div>
                          <div className="mt-1 flex items-center space-x-2">
                            <p className="text-sm font-medium text-gray-900">
                              ₹{" "}
                              {selectedPlan
                                ? selectedPlan.price
                                : vehicle?.vehiclePrice}
                            </p>
                            {vehicle?.vehicleAvailability && (
                              <div className="bg-blue-600 px-2 text-white animate-pulse text-[10px]">
                                Available
                              </div>
                            )}
                          </div>
                          <div className="mt-2">
                            <RatingStar
                              rating={vehicle?.vehicleRatings}
                              totalRating={vehicle?.numOfReviews}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-white shadow mb-2 p-2">
                <div className="flex items-center gap-1">
                  <h1 className="font-bold">Shop Times:</h1>
                  <p>
                    {vehicle?.shop?.shop_OpeningTime} -{" "}
                    {vehicle?.shop?.shop_ClosedTime}
                  </p>
                </div>
              </div>
            </section>
          </form>
        </div>
        {!user && (
          <LoginModal
            showLoginButton={false}
            autoOpen={autoOpenLogin}
            onClose={() => setAutoOpenLogin(false)}
          />
        )}
      </div>
    </Layout>
  );
};

export default CartPage;