import React, { useState } from "react";
import { FaLinkedin, FaInstagram } from "react-icons/fa";
import { motion } from "framer-motion";
import Layout from "../../components/layout/Layout";
import { Button, Input, Textarea } from "@material-tailwind/react";
import Schema from "../../components/seo/Schema";
import { useCreateContactMutation } from "../../redux/slices/contactApiSlice";  

const container = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { staggerChildren: 0.15 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  // RTK Query mutation hook
  const [createContact, { isLoading }] = useCreateContactMutation();

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createContact(formData).unwrap();
      setFormData({ name: "", email: "", message: "" }); // reset form on success
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <Schema />
      <div className="py-12 px-6 bg-gradient-to-b from-white to-blue-50">
        <div className="max-w-7xl mx-auto">
          <motion.h1
            className="text-5xl font-extrabold text-gray-900 mb-12 text-center"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            Get in Touch
          </motion.h1>

          <motion.div
            className="flex flex-col lg:flex-row gap-10"
            variants={container}
            initial="hidden"
            animate="show"
          >
            {/* Contact Info */}
            <motion.div
              className="flex-1 bg-white bg-opacity-60 backdrop-blur-md rounded-3xl p-8 shadow-xl"
              variants={item}
            >
              <h2 className="text-2xl font-semibold mb-6">Contact Information</h2>
              <p className="text-gray-700 mb-8">
                We're here to help. Reach out anytime!
              </p>

              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-gray-800">Address</h3>
                  <p className="text-gray-600">
                    Bhalekar plaza, Matoshree colony, Karve nagar, Pune, Maharashtra 411052
                  </p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Phone</h3>
                  <p className="text-gray-600">+91 9145103053</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Email</h3>
                  <p className="text-gray-600">contact@rideaway.in</p>
                </div>
              </div>

              <div className="mt-10 flex space-x-4">
                <motion.a
                  href="https://www.linkedin.com/company/rideawaysolutionsprivatelimited"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                  whileHover={{ scale: 1.2 }}
                >
                  <FaLinkedin />
                </motion.a>
                <motion.a
                  href="https://www.instagram.com/rideaway.rentals/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-pink-500 text-white rounded-full hover:bg-pink-600"
                  whileHover={{ scale: 1.2 }}
                >
                  <FaInstagram />
                </motion.a>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              className="flex-1 bg-white bg-opacity-60 backdrop-blur-md rounded-3xl p-8 shadow-xl"
              variants={item}
            >
              <h2 className="text-2xl font-semibold mb-6">Send Us a Message</h2>
              <motion.form
                onSubmit={handleSubmit}
                className="space-y-6"
                variants={container}
                initial="hidden"
                animate="show"
              >
                <motion.div variants={item}>
                  <Input
                    name="name"
                    label="Full Name"
                    value={formData.name}
                    onChange={handleChange}
                    className="bg-white/80"
                  />
                </motion.div>
                <motion.div variants={item}>
                  <Input
                    name="email"
                    label="Email Address"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="bg-white/80"
                  />
                </motion.div>
                <motion.div variants={item}>
                  <Textarea
                    name="message"
                    label="Your Message"
                    value={formData.message}
                    onChange={handleChange}
                    className="bg-white/80"
                  />
                </motion.div>
                <motion.div variants={item}>
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-500 hover:from-blue-600 hover:to-blue-600 text-white font-semibold py-3 rounded-full shadow-lg"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isLoading ? "Sending..." : "Send Message"}
                  </Button>
                </motion.div>
              </motion.form>
            </motion.div>
          </motion.div>

          <motion.div
            className="mt-16 rounded-3xl overflow-hidden shadow-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.6 }}
          >
            <iframe
              className="w-full h-96"
              frameBorder="0"
              scrolling="no"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.8692635809284!2d73.80833997509724!3d18.489580170120384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf0da5dd49ef%3A0xa8f6e6fd7c8e54ee!2sRideAway%20Rentals!5e0!3m2!1sen!2sin!4v1755240741614!5m2!1sen!2sin"
            />
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
