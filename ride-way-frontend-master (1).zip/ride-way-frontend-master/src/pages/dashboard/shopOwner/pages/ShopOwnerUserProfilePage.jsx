import UserProfile from "../../../../components/common/userProfile/UserProfile"

const ShopOwnerUserProfilePage = () => {
  return (
    <div>
      <UserProfile/>
    </div>
  )
}

export default ShopOwnerUserProfilePage