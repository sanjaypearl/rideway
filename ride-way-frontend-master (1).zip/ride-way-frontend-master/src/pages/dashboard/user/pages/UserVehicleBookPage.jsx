import BookedVehicles from "../../../../components/common/bookedVehicles/BookedVehicles"

const UserVehicleBookPage = () => {
  return (
    <div>
      <BookedVehicles/>
    </div>
  )
}

export default UserVehicleBookPage