import UserProfile from "../../../../components/common/userProfile/UserProfile"

const SuperAdminUserProfilePage = () => {
  return (
    <div>
        <UserProfile/>
    </div>
  )
}

export default SuperAdminUserProfilePage