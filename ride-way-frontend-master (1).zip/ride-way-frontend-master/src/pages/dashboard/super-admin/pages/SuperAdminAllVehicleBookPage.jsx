import BookedVehicles from "../../../../components/common/bookedVehicles/BookedVehicles"

const SuperAdminAllVehicleBookPage = () => {
  return (
    <div>
        <BookedVehicles/>
    </div>
  )
}

export default SuperAdminAllVehicleBookPage