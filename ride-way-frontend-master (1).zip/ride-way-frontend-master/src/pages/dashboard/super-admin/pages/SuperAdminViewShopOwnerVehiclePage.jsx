import ViewShopOwnerVehicle from "../../../../components/common/shopOwner/viewShopOwnerVehicle/ViewShopOwnerVehicle"

const SuperAdminViewShopOwnerVehiclePage = () => {
  return (
    <div>
        <ViewShopOwnerVehicle/>
    </div>
  )
}

export default SuperAdminViewShopOwnerVehiclePage