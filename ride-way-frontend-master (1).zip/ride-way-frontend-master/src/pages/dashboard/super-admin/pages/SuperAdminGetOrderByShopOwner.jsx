import GetOrderByShopId from "../../../../components/common/shopOwner/getOrderByShopId/GetOrderByShopId"

const SuperAdminGetOrderByShopOwner = () => {
  return (
    <div>
        <GetOrderByShopId/>
    </div>
  )
}

export default SuperAdminGetOrderByShopOwner