import AddAndViewEmployee from "../../../../components/common/addAndViewEmployee/AddAndViewEmployee"

const SuperAdminAddAndViewEmployeePage = () => {
  return (
    <div>
        <AddAndViewEmployee/>
    </div>
  )
}

export default SuperAdminAddAndViewEmployeePage