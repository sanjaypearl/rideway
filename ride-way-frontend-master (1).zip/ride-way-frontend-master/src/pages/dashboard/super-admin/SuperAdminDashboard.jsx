import SuperAdminLayout from "../../../components/dashboard/super-admin/SuperAdminLayout"

const SuperAdminDashboard = () => {
  return (
    <SuperAdminLayout>

    </SuperAdminLayout>
  )
}

export default SuperAdminDashboard