import React from "react";
import {
  Navbar,
  Typography,
  IconButton,
  Collapse,
  Button,
} from "@material-tailwind/react";
import { Link, useNavigate } from "react-router-dom";
import LoginModal from "../registration/LoginModal";
import authService from "../../services/authService";

export default function Navbars() {
  const [openNav, setOpenNav] = React.useState(false);
  const user = authService.getCurrentUser();
  console.log("user is", user);
  const navigate = useNavigate();

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 960) {
        setOpenNav(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleLogout = () => {
    authService.logout();
    navigate("/");
  };

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/about", label: "About Us" },
    { to: "/blog", label: "Blogs" },
    { to: "/become-host", label: "Host" },
  ];

  const navList = (
    <ul className="flex  flex-row items-center gap-6">
      {navLinks.map((item, index) => (
        <Typography
          key={index}
          as="li"
          variant="small"
          className="text-gray-800 font-medium text-lg transition-colors duration-300 hover:text-blue-500 focus:text-blue-500 focus:outline-none"
        >
          <Link to={item.to} className="flex items-center px-3 py-2">
            {item.label}
          </Link>
        </Typography>
      ))}
    </ul>
  );

  const mobileNavList = (
    <ul className="flex flex-col gap-4 p-1 my-3  rounded-b-2xl shadow-xl transition-all duration-300">
      {navLinks.map((item, index) => (
        <Typography
          key={index}
          as="li"
          variant="small"
          className="text-gray-800 font-medium text-base transition-colors duration-300 hover:text-blue-500 focus:text-blue-500 focus:outline-none"
        >
          <Link to={item.to} className="flex items-center px-3 py-2">
            {item.label}
          </Link>
        </Typography>
      ))}
      {user ? (
        <>
          <li className="flex items-center px-3 py-2">
            <Link
              to={user.role === "admin" ? "/admin" : "/user-dashboard"}
              className="text-blue-500 font-semibold text-base hover:text-blue-600 focus:text-blue-600 focus:outline-none"
            >
              Dashboard
            </Link>
          </li>
          <li className="flex items-center px-3 py-2">
            <button
              onClick={handleLogout}
              className="text-red-500 font-semibold text-base hover:text-red-600 focus:text-red-600 focus:outline-none"
            >
              Logout
            </button>
          </li>
        </>
      ) : (
        <li className="flex items-center lg:px-3 py-2">
          <LoginModal showLoginButton={true} />
        </li>
      )}
    </ul>
  );

  return (
    <div className="sticky top-0 z-50 w-full bg-[#dcf1fc]">
      <nav className="max-w-full rounded-none px-4 py-3 lg:px-8 lg:py-4 bg-gradient-to-r from-blue-500/10 to-blue-500/10 shadow-md border-none">
        <div className="flex items-center justify-between  text-gray-800">
          <div className="flex gap-8">
            <Link to="/">
              <Typography
                as="a"
                className="flex items-center gap-3 cursor-pointer"
              >
                <img
                  className="h-9 lg:h-11 transition-transform duration-300 hover:scale-105"
                  src="/logo/logo.png"
                  alt="RideAway Logo"
                />
              </Typography>
            </Link>
            <Link to="/subscription">
              <button className="relative border-none overflow-hidden rounded-full p-[2px] transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300/50">
                {/* Rotating gradient border with glow */}
                <span className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,cyan,blue,purple,cyan)] animate-[spin_4s_linear_infinite] shadow-[0_0_15px_rgba(0,191,255,0.8),0_0_30px_rgba(0,191,255,0.6),0_0_45px_rgba(0,191,255,0.4)]"></span>

                {/* Inner button with layered shadow */}
                <span className="relative flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-blue-800 px-5 py-2 text-sm font-semibold text-white shadow-[0_0_15px_rgba(0,191,255,0.7)] transition-all duration-300 hover:from-blue-500 hover:to-blue-700 hover:shadow-[0_0_25px_rgba(0,191,255,0.9)]">
                  Subscription
                </span>
              </button>
            </Link>
          </div>

          <div className="flex items-center gap-4 lg:gap-8">
            <div className="hidden lg:block">{navList}</div>

            <div className="hidden lg:flex items-center gap-4">
              {user ? (
                <>
                  <Link
                    to={
                      user.role === "admin"
                        ? "/admin-dashboard/admin-home-page"
                        : "/user-dashboard/user-vehicle-book"
                    }
                  >
                    <Button
                      variant="outlined"
                      className="text-sm font-semibold border-blue-500 text-blue-500 hover:bg-blue-50 focus:ring-2 focus:ring-blue-400 rounded-full px-5 py-2"
                    >
                      Dashboard
                    </Button>
                  </Link>

                  <Button
                    onClick={handleLogout}
                    className="bg-red-500 text-white text-sm font-semibold hover:bg-red-600 focus:ring-2 focus:ring-red-400 rounded-full px-5 py-2"
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <LoginModal showLoginButton={true} />
              )}
            </div>

            <IconButton
              variant="text"
              className="lg:hidden h-10 w-10 text-gray-800 hover:bg-gray-100/50 rounded-full"
              ripple={false}
              onClick={() => setOpenNav(!openNav)}
            >
              {openNav ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  className="h-6 w-6"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              )}
            </IconButton>
          </div>
        </div>
        <Collapse open={openNav} className="lg:hidden">
          {mobileNavList}
        </Collapse>
      </nav>
    </div>
  );
}
