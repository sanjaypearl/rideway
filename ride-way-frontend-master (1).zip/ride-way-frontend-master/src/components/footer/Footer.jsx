/* eslint-disable react/prop-types */
import { FiMapPin, FiMail, FiPhone, FiMessageCircle } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { useDispatch } from "react-redux";
import { Spinner } from "@material-tailwind/react";
import myContext from "../../context/myContext";
import { useGetCitiesQuery } from "../../redux/slices/cityApiSlice";
import { vehicleApi } from "../../redux/slices/vehicleApiSlice";

export default function Footer({ refetch }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    selectedCity,
    setSelectedCity,
    setVehicleCity,
    setLat,
    setLng,
    setCurrentLocationName,
  } = useContext(myContext);

  // Fetching dynamic city list
  const { data: cities = [], isLoading: isCitiesLoading } = useGetCitiesQuery();

  const handleCityChange = (city) => {
    setSelectedCity(city.cityName);
    setVehicleCity(city._id);
    setLat(null);
    setLng(null);
    setCurrentLocationName("");

    localStorage.setItem("selectedCity", city.cityName);
    localStorage.setItem("vehicleCity", city._id);
    localStorage.removeItem("lat");
    localStorage.removeItem("lng");
    localStorage.removeItem("currentLocationName");

    dispatch(vehicleApi.util.resetApiState());
    if (refetch) {
      refetch();
    }

    navigate("/");
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 0);
  };

  return (
    <footer className="relative text-gray-800 bg-white drop-shadow-md shadow-black">
      <div className="mx-auto w-full max-w-7xl px-6 py-12">
        {/* Logo */}
        <div className="flex justify-center pb-10">
          <img
            src="/logo/logo.png"
            alt="RideAway Rentals"
            className="h-20 w-auto"
          />
        </div>

        {/* Divider */}
        <div className="my-10 h-px w-full bg-gray-300" />

        {/* CITIES */}
        <h4 className="mb-6 text-center text-lg font-semibold underline decoration-blue-600/60 underline-offset-4 text-gray-900">
          RIDEAWAY CITIES
        </h4>

        {isCitiesLoading ? (
          <div className="flex justify-center py-4">
            <Spinner color="blue" />
          </div>
        ) : (
          <ul className="grid grid-cols-2 md:grid-cols-5 md:place-items-center flex-wrap gap-y-3 text-sm text-gray-600">
            {cities?.map((city) => (
              <li key={city._id} className="flex items-center gap-1">
                <FiMapPin className="text-blue-600" />
                <button
                  onClick={() => handleCityChange(city)}
                  className={`hover:text-blue-600 hover:underline ${
                    selectedCity === city.cityName ? "font-bold text-blue-600" : ""
                  }`}
                >
                  Bike rent in <span>{city.cityName}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </footer>
  );
}
