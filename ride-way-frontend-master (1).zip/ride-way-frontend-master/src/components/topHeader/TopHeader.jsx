import { FaEnvelope, FaPhoneAlt } from "react-icons/fa";

const Header = () => {
  return (
    <div className="bg-white py-2 px-4 flex justify-center items-center text-white relative">
      <div className="absolute left-1/2 transform -translate-x-1/2">
        <span className="bg-gradient-to-r from-blue-400 to-blue-900 text-white font-semibold rounded-sm px-3 py-2 text-[10px] animate-pulse ">
          Book your vehicle now!
        </span>
      </div>
      <div className="flex items-center space-x-4 ml-auto">
        <div className="flex items-center space-x-2">
          <FaEnvelope className="text-white-700" />
          <span className="app-font text-blue-900">support@rideaway.in</span>
        </div>
        <div className="flex items-center space-x-2">
          <FaPhoneAlt className="text-blue-900" />
          <span className="app-font text-blue-900">+919145103053 </span>
        </div>
      </div>
    </div>
  );
};

export default Header;
