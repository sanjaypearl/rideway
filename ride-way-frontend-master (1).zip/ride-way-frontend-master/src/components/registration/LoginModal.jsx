import { useState, useEffect, useContext } from "react";
import { Button, Dialog } from "@material-tailwind/react";
import { X } from "lucide-react";
import myContext from "../../context/myContext";
import LoginForm from "./LoginForm";
import UserSignupForm from "./UserSignupForm";
import ForgotPassword from "./ForgotPassword";

export default function LoginModal({ autoOpen = false, showLoginButton = true }) {
  const { setAutoOpenLogin } = useContext(myContext);
  const [open, setOpen] = useState(autoOpen);
  const [dialogSize, setSize] = useState("lg");

  const [auth, setAuth] = useState({
    isSignup: false,
    isForgotPassword: false,
  });

  const toggleOpen = () => setOpen(!open);
  const handleAutoClose = () => setAutoOpenLogin(false);

  const switchToSignup = () =>
    setAuth({ isSignup: true, isForgotPassword: false });

  const switchToLogin = () =>
    setAuth({ isSignup: false, isForgotPassword: false });

  const switchToForgotPassword = () =>
    setAuth({ isSignup: false, isForgotPassword: true });

  useEffect(() => {
    if (autoOpen) setOpen(true);
    const updateSize = () => setSize(window.innerWidth < 768 ? "xxl" : "lg");
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, [autoOpen]);

  const renderRight = () => {
    if (auth.isForgotPassword) {
      return <ForgotPassword switchToLogin={switchToLogin} />;
    }

    if (auth.isSignup) {
      return <UserSignupForm switchToLogin={switchToLogin} />;
    }

    return (
      <LoginForm
        switchToSignup={switchToSignup}
        switchToForgotPassword={switchToForgotPassword}
        handleClose={() => {
          toggleOpen();
          handleAutoClose();
        }}
      />
    );
  };

  const headerText = auth.isSignup ? "SIGN UP" : "SIGN IN";

  return (
    <>
      {showLoginButton && !autoOpen && (
        <>
          <p onClick={toggleOpen} className="hidden lg:block text-black">
            <span className="md:px-8 py-3 text-[10px] bg-blue-700 font-semibold text-white bg-blue-7000 rounded-sm cursor-pointer">
              SIGN IN
            </span>
          </p>
          <Button onClick={toggleOpen} className="lg:hidden bg-blue-700">
            SIGN IN 
          </Button>
        </>
      )}

      <Dialog
        open={open}
        handler={toggleOpen}
        size={dialogSize}
        className="rounded-none shadow-none"
      >
        <div className="flex items-center">
          {/* Left side image */}
          <div className="hidden lg:flex w-[40em] h-[33em] items-center justify-center">
            <img
              src={
                auth.isSignup
                  ? "/register.png"
                  : "/login.png"
              }
              alt={auth.isSignup ? "signup" : "login"}
            />
          </div>

          {/* Right side form */}
          <div className="relative w-full h-screen lg:h-[33em] bg-blue-50/50 p-5 lg:p-10">
            <div
              className="absolute top-0 right-0 p-2 cursor-pointer bg-blue-50"
              onClick={() => {
                toggleOpen();
                handleAutoClose();
              }}
            >
              <X size={20} className="text-blue-300 hover:text-blue-400" />
            </div>

            <div className="flex justify-center mt-10 mb-0 pt-32 lg:pt-0 text-2xl">
              {headerText}
            </div>

            <div className="py-10">{renderRight()}</div>
          </div>
        </div>
      </Dialog>
    </>
  );
}
