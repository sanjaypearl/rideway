import { useGetVehiclesNearbyQuery } from "../../redux/slices/vehicleApiSlice";
import { Button, Spinner } from "@material-tailwind/react";
import { useCallback, useContext, useEffect, useState } from "react";
import { motion } from "framer-motion";
import myContext from "../../context/myContext";
import { useNavigate } from "react-router-dom";
import RatingBadge from "./RatingBadge";

const AllVehicle =  ({ vehicleType, selectedDuration }) => {
  const navigate = useNavigate();
  const [maxDistance, setMaxDistance] = useState(1000);

  const {
    lat,
    lng,
    vehicleCity,
    selectedCity,
    startDate,
    endDate,
  } = useContext(myContext);

  const {
    data: vehicles,
    error,
    isLoading,
    refetch,
  } = useGetVehiclesNearbyQuery({
    lat,
    lng,
    vehicleCity,
    vehicleType,
    maxDistance,
    startDate,
    endDate,
  });

  const sortedVehicles = vehicles?.vehicles?.slice().sort((a, b) => {
    if (a.distance && b.distance) return a.distance - b.distance;
    return 0;
  });

  const resetFilters = useCallback(() => {
    setMaxDistance(1000);
    refetch();
  }, [refetch]);

  const handleScroll = useCallback(() => {
    if (
      vehicles?.vehicles?.length > 0 &&
      window.innerHeight + window.scrollY >= document.body.offsetHeight - 500 &&
      maxDistance < 10000
    ) {
      setMaxDistance((prev) => Math.min(prev + 100, 10000));
    }
  }, [vehicles, maxDistance]);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  useEffect(() => {
    resetFilters();
  }, [vehicleCity, vehicleType, startDate, endDate, resetFilters]);

  useEffect(() => {
    refetch();
  }, [refetch, maxDistance]);

  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (index) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.1,
        type: "spring",
        stiffness: 50,
      },
    }),
  };

  return (
    <section className="py-5">
      <div className="container mx-auto">
        <div className="flex flex-wrap -m-4 justify-center">
          {isLoading ? (
            <div className="flex justify-center p-4">
              <Spinner className="h-8 w-8 text-blue-500" />
            </div>
          ) : error ? (
            <motion.div
              className="p-4 w-full"
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              custom={0}
            >
              <div className="flex justify-center items-center">
                <img
                  className="w-20"
                  src="https://cdn-icons-png.flaticon.com/128/9961/9961360.png"
                  alt="Error"
                />
              </div>
              <h1 className="text-center text-red-500 mt-2">
                {error?.data?.error || "An unexpected error occurred."}
              </h1>
            </motion.div>
          ) : sortedVehicles?.length > 0 ? (
            sortedVehicles.map((item, index) => {
              const {
                _id,
                vehicleName,
                vehicleImage,
                vehicleRatings,
                distance,
                pricingPlans,
                shop,
              } = item;

              return (
                <motion.div
                  key={_id}
                  className="p-2 w-full sm:w-1/2 md:w-1/3 lg:w-1/4"
                  custom={index}
                  variants={cardVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <div className="bg-white rounded-lg border border-gray-300 drop-shadow hover:shadow-lg transition-shadow duration-200">
                    <div
                      className="relative cursor-pointer"
                      onClick={() =>
                        navigate(`/vehicle-info/${selectedCity}/${_id}`)
                      }
                    >
                      <img
                        className="w-full h-48 object-cover rounded-t-xl"
                        src={
                          vehicleImage?.[0]?.url ??
                          "https://via.placeholder.com/300x200?text=No+Image"
                        }
                        alt={vehicleName}
                      />
                    </div>
                    <div className="p-4">
                      <h2 className="tracking-widest text-sm app-font text-gray-600 mb-1">
                        RideAway
                      </h2>

                      <div className="flex justify-between items-center mb-2">
                        <h1 className="text-xl font-bold text-gray-900">
                          {vehicleName.length > 20
                            ? `${vehicleName.slice(0, 20)}...`
                            : vehicleName}
                        </h1>
                      </div>

                      <div className="space-y-1 mb-2">
                        {(() => {
                          // find exact match
                          const exactPlan = pricingPlans?.find(
                            (plan) => plan.durationInDays === selectedDuration
                          );

                          if (exactPlan) {
                            return (
                              <p className="text-gray-600 text-sm">
                                <span className="font-semibold text-black">
                                  ₹{exactPlan.price}
                                </span>{" "}
                                / <span>{exactPlan.label}</span>
                              </p>
                            );
                          }

                          // if no exact match, find lowest plan and multiply
                          const sortedPlans = pricingPlans
                            ?.slice()
                            .sort(
                              (a, b) => a.durationInDays - b.durationInDays
                            );

                          if (sortedPlans?.length) {
                            const perDay =
                              sortedPlans[0].price /
                              sortedPlans[0].durationInDays;
                            const estimatedPrice = Math.round(
                              perDay * selectedDuration
                            );

                            return (
                              <p className="text-gray-600 text-sm">
                                <span className="font-semibold text-black">
                                  ₹{estimatedPrice}
                                </span>{" "}
                                / <span>{selectedDuration} Days (est.)</span>
                              </p>
                            );
                          }

                          return (
                            <p className="text-gray-500 text-sm">
                              No pricing available
                            </p>
                          );
                        })()}
                      </div>

                      <div className="flex w-full gap-2 mt-3">
                        <Button
                          onClick={() =>
                            navigate(
                              `/checkout/${_id}?startDate=${startDate}&endDate=${endDate}`
                            )
                          }
                          className="bg-indigo-500 text-white w-full py-2 rounded shadow-none hover:bg-indigo-600 transition duration-300"
                        >
                          Book Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })
          ) : (
            <p className="text-center text-gray-500 mt-8">No vehicles found.</p>
          )}
        </div>
      </div>
    </section>
  );
};

export default AllVehicle;
