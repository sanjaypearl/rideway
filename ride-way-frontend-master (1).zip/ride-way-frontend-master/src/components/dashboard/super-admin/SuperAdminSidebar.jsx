import { List, ListItem, ListItemPrefix } from "@material-tailwind/react";
import { HomeIcon, UserCircleIcon, PowerIcon } from "@heroicons/react/24/solid";
import {
  Users,
  TicketCheck,
  ClipboardPlus,
  MapPin,
  Tag,
  CarFront,
  CirclePlus,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useLogoutMutation } from "../../../redux/slices/authApiSlice";
import apiSlice from "../../../redux/slices/apiSlice";

export default function AdminSidebar() {
  const dispatch = useDispatch();
  const [logout] = useLogoutMutation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    dispatch(apiSlice.util.resetApiState());
    navigate("/");
  };

  return (
    <aside className="fixed h-screen w-full max-w-[16rem] p-4 border-r border-blue-300 bg-blue-50">
      {/* Logo */}
      <div className="mb-6 px-4">
        <Link to="/">
          <div className="py-6">
            <div className="flex justify-center mb-2">
              <img
                src="https://cdn-icons-png.flaticon.com/128/8899/8899687.png"
                alt="Admin Logo"
                className="w-24"
              />
            </div>
            <h1 className="text-center text-xl font-bold app-font text-black">
              Admin Dashboard
            </h1>
          </div>
        </Link>
      </div>

      {/* Sidebar Navigation */}
      <List>
        <Link to="admin-home-page">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <HomeIcon className="h-5 w-5" />
            </ListItemPrefix>
            Home
          </ListItem>
        </Link>

        <Link to="get-all-host">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <Users className="h-5 w-5" />
            </ListItemPrefix>
            Hosts
          </ListItem>
        </Link>

        <Link to="view-and-add-city">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <MapPin className="h-5 w-5" />
            </ListItemPrefix>
            Cities
          </ListItem>
        </Link>

        <Link to="admin-blog-page">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <MapPin className="h-5 w-5" />
            </ListItemPrefix>
            Blogs
          </ListItem>
        </Link>

        <Link to="view-user-and-shop-owner">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <Users className="h-5 w-5" />
            </ListItemPrefix>
            Users & Shop Owners
          </ListItem>
        </Link>

        <Link to="get-all-contact">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <Users className="h-5 w-5" />
            </ListItemPrefix>
            Contacts
          </ListItem>
        </Link>

        <Link to="admin-vehicle-book">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <TicketCheck className="h-5 w-5" />
            </ListItemPrefix>
            Vehicle Bookings
          </ListItem>
        </Link>

        <Link to="create-coupon-code-and-view-coupon-code">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <Tag className="h-5 w-5" />
            </ListItemPrefix>
            Coupons
          </ListItem>
        </Link>

        <Link to="admin-all-vehicle">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <CarFront className="h-5 w-5" />
            </ListItemPrefix>
            All Vehicles
          </ListItem>
        </Link>

        <Link to="admin-add-vehicle">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <CirclePlus className="h-5 w-5" />
            </ListItemPrefix>
            Add Vehicle
          </ListItem>
        </Link>

        <Link to="admin-profile">
          <ListItem className="hover:bg-blue-100 transition-colors">
            <ListItemPrefix>
              <UserCircleIcon className="h-5 w-5" />
            </ListItemPrefix>
            Profile
          </ListItem>
        </Link>

        <ListItem
          onClick={handleLogout}
          className="hover:bg-blue-100 transition-colors cursor-pointer"
        >
          <ListItemPrefix>
            <PowerIcon className="h-5 w-5" />
          </ListItemPrefix>
          Log Out
        </ListItem>
      </List>
    </aside>
  );
}
