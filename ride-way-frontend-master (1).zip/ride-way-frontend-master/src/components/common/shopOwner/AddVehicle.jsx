import { useContext, useEffect, useRef, useState } from 'react';
import { useAddVehicleMutation } from '../../../redux/slices/vehicleApiSlice';
import { useGetCitiesQuery } from '../../../redux/slices/cityApiSlice'
import { Button, Input, Textarea } from '@material-tailwind/react';
import myContext from '../../../context/myContext';

const vehicleTypes = ['Car', 'Bike', 'Scooty'];
const durationOptions = [1, 7, 30, 90, 180, 270, 365];

const durationToLabel = {
  1: '1 Day',
  7: '1 Week',
  30: '1 Month',
  90: '3 Months',
  180: '6 Months',
  270: '9 Months',
  365: '12 Months',
};

const AddVehicleForm = () => {
  const [formData, setFormData] = useState({
    vehicleType: '',
    vehicleName: '',
    vehicleNumber: '',
    vehicleModel: '',
    sittingCapacity: '',
    vehicalDetails: '',
    vehicleImage: [],
    vehicleAvailability: true,
    city: '', // ✅ New city field
  });

  const [pricingPlans, setPricingPlans] = useState([{ durationInDays: 1, price: '' }]);

  const { showAlert } = useContext(myContext);
  const [addVehicle, { isLoading, isSuccess, isError, error, data }] = useAddVehicleMutation();
  const { data: cities, isLoading: isCitiesLoading } = useGetCitiesQuery(); // ✅ Get cities
  const [imagePreview, setImagePreview] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const fileInputRef = useRef(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleFileChange = (e) => {
    const newFiles = Array.from(e.target.files);
    setFormData((prevData) => ({
      ...prevData,
      vehicleImage: [...prevData.vehicleImage, ...newFiles],
    }));
    setImagePreview((prevPreviews) => [
      ...prevPreviews,
      ...newFiles.map((file) => URL.createObjectURL(file)),
    ]);
  };

  const handleRemoveImage = (index) => {
    setFormData((prevData) => ({
      ...prevData,
      vehicleImage: prevData.vehicleImage.filter((_, i) => i !== index),
    }));
    setImagePreview((prevPreviews) => {
      const newPreviews = prevPreviews.filter((_, i) => i !== index);
      URL.revokeObjectURL(prevPreviews[index]);
      return newPreviews;
    });
  };

  const handleAvailabilityChange = (e) => {
    setFormData((prevData) => ({
      ...prevData,
      vehicleAvailability: e.target.checked,
    }));
  };

  const handlePricingChange = (index, field, value) => {
    setPricingPlans((prevPlans) =>
      prevPlans.map((plan, i) =>
        i === index ? { ...plan, [field]: Number(value) } : plan
      )
    );
  };

  const addPricingPlan = () => {
    setPricingPlans([...pricingPlans, { durationInDays: 1, price: '' }]);
  };

  const removePricingPlan = (index) => {
    setPricingPlans(pricingPlans.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const vehicleData = new FormData();

    Object.entries(formData).forEach(([key, value]) => {
      if (key === 'vehicleImage') {
        value.forEach((file) => vehicleData.append('vehicleImage', file));
      } else {
        vehicleData.append(key, value);
      }
    });

    const enrichedPlans = pricingPlans.map(plan => ({
      ...plan,
      label: durationToLabel[plan.durationInDays] || '',
    }));

    vehicleData.append('pricingPlans', JSON.stringify(enrichedPlans));

    await addVehicle(vehicleData);
  };

  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  const handleVehicleTypeSelect = (vehicleType) => {
    setFormData((prevData) => ({
      ...prevData,
      vehicleType,
      sittingCapacity: vehicleType === 'bike' || vehicleType === 'scooty' ? 2 : '',
    }));
    setIsDropdownOpen(false);
  };

  useEffect(() => {
    if (isError) {
      showAlert(error?.data?.error || 'Failed to add vehicle. Please try again.', 'error');
    }

    if (isSuccess) {
      showAlert(data?.message, 'success', 2000);
      setFormData({
        vehicleType: '',
        vehicleName: '',
        vehicleNumber: '',
        vehicleModel: '',
        sittingCapacity: '',
        vehicalDetails: '',
        vehicleImage: [],
        vehicleAvailability: true,
        city: '', // ✅ Reset city
      });
      setPricingPlans([{ durationInDays: 1, price: '' }]);
      imagePreview.forEach((url) => URL.revokeObjectURL(url));
      setImagePreview([]);
      if (fileInputRef.current) fileInputRef.current.value = null;
    }

    return () => {
      imagePreview.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [isError, isSuccess]);

  return (
    <form onSubmit={handleSubmit} className="max-w-6xl mx-auto p-4 bg-white border border-blue-400 rounded-md space-y-4">
      <div className="text-center">
        <img src="../../logo/rideroz.png" alt="RideAway Logo" className="h-20 w-48 mx-auto mb-2" />
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="w-full sm:w-1/2">
          <div className="relative">
            <div
              className="w-full px-4 py-2 border border-[#b0bec5] text-gray-600 rounded-md cursor-pointer"
              onClick={toggleDropdown}
            >
              {formData.vehicleType ? formData.vehicleType : 'Select Vehicle Type'}
            </div>
            {isDropdownOpen && (
              <ul className="absolute w-full bg-white border border-[#b0bec5] rounded-md mt-1 z-10">
                {vehicleTypes.map((type, index) => (
                  <li
                    key={index}
                    className="px-4 py-2 hover:bg-gray-100 rounded-md cursor-pointer"
                    onClick={() => handleVehicleTypeSelect(type.toLowerCase())}
                  >
                    {type}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="w-full sm:w-1/2">
          <Input label="Vehicle Name" name="vehicleName" value={formData.vehicleName} onChange={handleChange} color="blue" />
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <Input label="Vehicle Number" name="vehicleNumber" value={formData.vehicleNumber} onChange={handleChange} color="blue" />
        <Input label="Vehicle Model" name="vehicleModel" value={formData.vehicleModel} onChange={handleChange} color="blue" />
      </div>

      <div className="w-full">
        <label className="block text-sm font-medium text-gray-700 mb-1">Select City</label>
        <select
          name="city"
          value={formData.city}
          onChange={handleChange}
          disabled={isCitiesLoading}
          className="w-full px-4 py-2 border border-gray-300 rounded-md"
        >
          <option value="">-- Select a City --</option>
          {cities?.map((city) => (
            <option key={city._id} value={city._id}>
              {city.cityName}
            </option>
          ))}
        </select>
      </div>

      <div>
        {formData.vehicleType === 'car' ? (
          <select
            name="sittingCapacity"
            value={formData.sittingCapacity}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-md mt-2"
          >
            <option value="">Select Capacity</option>
            <option value="5">5</option>
            <option value="8">8</option>
            <option value="10">10</option>
          </select>
        ) : (
          <Input
            label="Sitting Capacity"
            type="number"
            name="sittingCapacity"
            value={formData.sittingCapacity}
            readOnly
            color="blue"
          />
        )}
      </div>

      <div className="border border-blue-300 p-3 rounded-md">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-semibold text-blue-700">Pricing Plans (₹)</h3>
          <Button size="sm" onClick={addPricingPlan} color="blue">+ Add</Button>
        </div>
        {pricingPlans.map((plan, index) => (
          <div key={index} className="flex gap-2 mb-2">
            <select
              value={plan.durationInDays}
              onChange={(e) => handlePricingChange(index, 'durationInDays', e.target.value)}
              className="w-1/2 border border-gray-300 px-2 py-1 rounded-md"
            >
              {durationOptions.map((d) => (
                <option key={d} value={d}>
                  {d} day{d > 1 ? 's' : ''}
                </option>
              ))}
            </select>
            <Input
              type="number"
              label="Price (₹)"
              value={plan.price}
              onChange={(e) => handlePricingChange(index, 'price', e.target.value)}
              color="blue"
            />
            {pricingPlans.length > 1 && (
              <Button size="sm" color="red" onClick={() => removePricingPlan(index)}>
                Remove
              </Button>
            )}
          </div>
        ))}
      </div>

      <Textarea label="Vehicle Details" name="vehicalDetails" value={formData.vehicalDetails} onChange={handleChange} color="blue" />

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Upload Vehicle Images</label>
        <input
          type="file"
          multiple
          accept="image/*"
          ref={fileInputRef}
          name="vehicleImage"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </div>

      {imagePreview.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
          {imagePreview.map((src, i) => (
            <div key={i} className="relative">
              <img src={src} className="w-full h-40 object-cover rounded-md" />
              <button
                type="button"
                onClick={() => handleRemoveImage(i)}
                className="absolute top-1 right-1 bg-red-500 text-white rounded-full px-2 py-1 text-xs"
              >
                X
              </button>
            </div>
          ))}
        </div>
      )}

      <Button type="submit" disabled={isLoading} className="w-full bg-blue-600 text-white font-semibold py-3 rounded-md">
        {isLoading ? 'Adding...' : 'Add Vehicle'}
      </Button>
    </form>
  );
};

export default AddVehicleForm;
