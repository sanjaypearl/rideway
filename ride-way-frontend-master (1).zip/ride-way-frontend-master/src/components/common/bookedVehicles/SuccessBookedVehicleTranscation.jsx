import {
  ArrowPathIcon,
  ArrowsPointingInIcon,
  ArrowsPointingOutIcon,
  ListBulletIcon,
  TableCellsIcon,
} from "@heroicons/react/24/outline";
import {
  Input,
  Typography,
  Button,
  Spinner,
  Chip,
  IconButton,
} from "@material-tailwind/react";
import { useEffect, useState } from "react";
import { useGetOrdersQuery } from "../../../redux/slices/orderApiSlice";
import { useConfirmBookingMutation } from "../../../redux/slices/adminApiSlice";
import { useNavigate } from "react-router-dom";
import { Eye } from "lucide-react";
import CancelRideModal from "./modal/CancelRideModal";
import ShowLocationModal from "./modal/ShowLocationModal";
import authService from "../../../services/authService";
import VerifyRideModal from "./modal/VerifyRideModal";
import RatingBadge from "../../vehicle/RatingBadge";
import ViewSettlementProofModal from "./modal/ViewSettlementProofModal";
import CustomDropdown from "../shopOwner/getOrderByShopId/custom/CustomDropDown";
import SettleCustomDropDown from "../shopOwner/getOrderByShopId/custom/SettleCustomDropDown";

// Define Tooltip component if not imported from a library
const Tooltip = ({ children, text }) => (
  <div className="relative group">
    {children}
    <div
      className="absolute bottom-full w-[7em] text-center left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block bg-black text-white text-xs rounded px-2 py-1 shadow-lg"
      role="tooltip"
    >
      {text}
    </div>
  </div>
);

export default function SuccessBookedVehicleTransaction() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [viewType, setViewType] = useState(() => {
    return localStorage.getItem("viewType") || "table";
  });
  const [filters, setFilters] = useState({
    status: "",
    settled: false,
    startDate: "",
    endDate: "",
    limit: 10,
    page: 1,
  });
  const [isFullscreen, setIsFullscreen] = useState(false);

  const user = authService.getCurrentUser();
  const navigate = useNavigate();

  const { data, error, isLoading, refetch, isError } = useGetOrdersQuery(filters);
  const [confirmBooking, { isLoading: isConfirming }] = useConfirmBookingMutation();

  // Updated TABLE_HEAD to include Confirmation OTP for admin
  const TABLE_HEAD = [
    "S.No",
    "Vehicle Image",
    "Vehicle Name",
    "Vehicle Number",
    "Payment Status",
    "Pickup Confirmed Status",
    "View Location",
    ...(user?.role === "admin" ? ["Cancel Ride"] : []),
    ...(user?.role === "admin" ? ["Confirm Booking"] : []),
    "Created Date",

  ];

  const toggleViewType = () => {
    const newViewType = viewType === "table" ? "list" : "table";
    setViewType(newViewType);
    localStorage.setItem("viewType", newViewType);
  };

  useEffect(() => {
    const storedViewType = localStorage.getItem("viewType");
    if (storedViewType && storedViewType !== viewType) {
      setViewType(storedViewType);
    }
  }, [viewType]);

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error("Failed to enter fullscreen:", err);
      });
    } else {
      document.exitFullscreen().catch((err) => {
        console.error("Failed to exit fullscreen:", err);
      });
    }
    setIsFullscreen(!isFullscreen);
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
      page: 1, // Reset page to 1 when filters change
    }));
    setPage(1);
  };

  const handlePrevious = () => {
    if (page > 1) {
      const newPage = page - 1;
      setPage(newPage);
      setFilters((prevFilters) => ({
        ...prevFilters,
        page: newPage,
      }));
    }
  };

  const handleNext = () => {
    const totalPages = Math.ceil((data?.stats?.totalOrders ?? 0) / limit);
    if (page < totalPages) {
      const newPage = page + 1;
      setPage(newPage);
      setFilters((prevFilters) => ({
        ...prevFilters,
        page: newPage,
      }));
    }
  };

  const handleConfirmBooking = async (orderId) => {
    try {
      await confirmBooking(orderId).unwrap();
      refetch();
      alert("Booking confirmed successfully!");
    } catch (err) {
      console.error("Error confirming booking:", err);
      alert(`Failed to confirm booking: ${err?.data?.message || "Unknown error"}`);
    }
  };

  // Optimize refetch to avoid unnecessary calls
  useEffect(() => {
    refetch();
  }, [filters.page, filters.status, filters.settled, filters.startDate, filters.endDate, filters.limit, refetch]);

  const formatDate = (isoDate) => {
    if (!isoDate) return "N/A";
    const date = new Date(isoDate);
    const options = {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    };
    return new Intl.DateTimeFormat("en-US", options).format(date);
  };



  return (
    <div className="h-full w-full bg-white pt-1 rounded-md border border-blue-300">
      <div className="rounded-none border-b border-blue-300 px-2 py-1">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <Typography variant="h5" color="blue-gray">
              All Vehicle Orders
            </Typography>
            <Typography color="gray" className="mt-1 font-normal app-font">
              See information about all vehicle orders
            </Typography>
          </div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <div className="w-full lg:w-56">
              <Input
                label="Start Date"
                type="date"
                name="startDate"
                value={filters.startDate}
                onChange={handleFilterChange}
                color="blue"
              />
            </div>
            <div className="w-full lg:w-56">
              <Input
                label="End Date"
                type="date"
                name="endDate"
                value={filters.endDate}
                onChange={handleFilterChange}
                color="blue"
              />
            </div>
            <CustomDropdown filters={filters} setFilters={setFilters} />
            {user?.role === "admin" && (
              <SettleCustomDropDown filters={filters} setFilters={setFilters} />
            )}
            <Button
              variant="outlined"
              color="blue"
              size="sm"
              className="flex hover:shadow-none shadow-none items-center gap-2 border-blue-200 bg-transparent border text-black"
              onClick={refetch}
            >
              <ArrowPathIcon className="h-5 w-5" />
              Refresh
            </Button>
            <Button
              variant="outlined"
              size="sm"
              className="flex items-center gap-2 border hover:shadow-none shadow-none text-black bg-white border-blue-200"
              onClick={toggleViewType}
            >
              {viewType === "table" ? (
                <ListBulletIcon className="h-5 w-5" />
              ) : (
                <TableCellsIcon className="h-5 w-5" />
              )}
              <span>{viewType === "table" ? "List View" : "Table View"}</span>
            </Button>
            <Button
              variant="outlined"
              size="sm"
              className="flex items-center gap-2 border hover:shadow-none shadow-none text-black bg-white border-blue-200"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? (
                <ArrowsPointingInIcon className="h-5 w-5" />
              ) : (
                <ArrowsPointingOutIcon className="h-5 w-5" />
              )}
              <span className="hidden lg:block sm:block md:block">
                {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
              </span>
            </Button>
          </div>
        </div>
      </div>

      <div className="overflow-scroll p-2">
        {isLoading ? (
          <div className="flex justify-center p-4">
            <Spinner className="h-8 w-8 text-blue-500" />
          </div>
        ) : isError ? (
          <div className="p-4">
            <div className="flex justify-center items-center">
              <img
                className="w-20"
                src="https://cdn-icons-png.flaticon.com/128/9961/9961360.png"
                alt="Error"
              />
            </div>
            <Typography className="text-center text-red-500">
              {error?.data?.error || "An error occurred while fetching orders."}
            </Typography>
            <Button
              variant="outlined"
              color="blue"
              size="sm"
              className="mt-4 mx-auto block"
              onClick={refetch}
            >
              Retry
            </Button>
          </div>
        ) : viewType === "table" ? (
          <table className="w-full min-w-max table-auto text-left bg-blue-50">
            <thead>
              <tr>
                {TABLE_HEAD.map((head) => (
                  <th
                    key={head}
                    scope="col"
                    className="border-y border-l border-r border-blue-200 bg-blue-50 p-4"
                  >
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-bold leading-none text-blue-700"
                    >
                      {head}
                    </Typography>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data?.orders?.map(
                (
                  {
                    _id,
                    vehicle,
                    status,
                    settlementProofImage,
                    settlementAmount,
                    settlementDate,
                    settlementPlatformUsed,
                    settlementTransactionId,
                    settled,
                    createdAt,
                    rideConfirmed,
                  },
                  index
                ) => {
                  const {
                    vehicleImage,
                    vehicleNumber,
                    vehicleName,
                    vehiclePrice,
                  } = vehicle || {};
                  const isLast = index === data?.orders?.length - 1;
                  const classes = isLast
                    ? "px-5 border-l border-r border-b border-blue-300"
                    : "px-5 border-l border-r border-b border-blue-300";

                  return (
                    <tr
                      key={index}
                      className="hover:bg-blue-50/50 cursor-pointer"
                    >
                      <td className={classes}>
                        <Typography variant="small" className="font-normal app-font">
                          {index + 1 + (page - 1) * limit}.
                        </Typography>
                      </td>
                      <td className={classes}>
                        <img
                          className="w-10 h-10"
                          src={vehicleImage?.[0]?.url || "/placeholder-image.png"}
                          alt={vehicleName || "Vehicle"}
                        />
                      </td>
                      <td className={classes}>
                        <Typography
                          variant="small"
                          className="font-normal app-font capitalize text-black"
                        >
                          {vehicleName || "N/A"}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Typography
                          variant="small"
                          color="blue-gray"
                          className="font-normal app-font capitalize text-black"
                        >
                          {vehicleNumber || "N/A"}
                        </Typography>
                      </td>
                      <td className={classes}>
                        <Chip
                          size="sm"
                          variant="ghost"
                          value={status}
                          color={
                            status === "failed"
                              ? "red"
                              : status === "pending"
                              ? "orange"
                              : "blue"
                          }
                          className="px-3 text-center w-28"
                        />
                      </td>
                      <td className={classes}>
                        <Chip
                          size="sm"
                          variant="ghost"
                          value={rideConfirmed === false ? "pending" : "success"}
                          color={rideConfirmed === false ? "red" : "orange"}
                          className="px-3 text-center w-28"
                        />
                      </td>
                   
                      <td className={classes}>
                        <ShowLocationModal vehicle={vehicle} />
                      </td>
                      {user?.role === "admin" && (
                        <td className={classes}>
                          <CancelRideModal
                            orderId={_id}
                            vehicleBasePrice={vehiclePrice}
                            refetch={refetch}
                          />
                        </td>
                      )}
                    
                    
                  
                      {user?.role === "admin" && (
                        <td className={classes}>
                          <Button
                            size="sm"
                            color="blue"
                            disabled={
                              rideConfirmed ||
                              !["pending", "completed"].includes(status) ||
                              isConfirming
                            }
                            onClick={() => handleConfirmBooking(_id)}
                          >
                            {isConfirming ? "Confirming..." : "Confirm"}
                          </Button>
                        </td>
                      )}
                      <td className={classes}>{formatDate(createdAt)}</td>
                  
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data?.orders?.map(
              (
                {
                  _id,
                  vehicle,
                  status,
                  settlementProofImage,
                  settlementAmount,
                  settlementDate,
                  settlementPlatformUsed,
                  settlementTransactionId,
                  settled,
                  createdAt,
                  confirmationOtp,
                  rideConfirmed,
                  cancellationRefundId,
                  cancellationRefundStatus,
                  shopAmount,
                },
                index
              ) => {
                const {
                  vehicleImage,
                  vehicleNumber,
                  vehicleName,
                  vehiclePrice,
                } = vehicle || {};
                return (
                  <div
                    key={index}
                    className="p-4 border border-blue-200 rounded-lg"
                  >
                    <img
                      className="w-full h-44 object-cover rounded-md"
                      src={vehicleImage?.[0]?.url || "/placeholder-image.png"}
                      alt={vehicleName || "Vehicle"}
                    />
                    <div className="mt-2">
                      <Typography
                        variant="h6"
                        className="capitalize font-bold text-blue-700"
                      >
                        {vehicleName || "N/A"}
                      </Typography>
                      <Typography
                        variant="body2"
                        className="capitalize text-gray-900 app-font"
                      >
                        {vehicleNumber || "N/A"}
                      </Typography>
                      <div className="flex items-center justify-between mt-2">
                        <Typography
                          variant="body2"
                          className="capitalize text-gray-900 app-font"
                        >
                          ₹ {user?.role === "admin" ? shopAmount : vehiclePrice || "N/A"}
                        </Typography>
                        <RatingBadge vehicleRatings={vehicle?.vehicleRatings} />
                      </div>
                
                      <div className="flex justify-between items-center mt-2">
                        <h1 className="font-bold">Payment Status:</h1>
                        <Chip
                          size="sm"
                          variant="ghost"
                          value={status}
                          color={
                            status === "failed"
                              ? "red"
                              : status === "pending"
                              ? "orange"
                              : "blue"
                          }
                          className="px-3 text-center w-28"
                        />
                      </div>
                      <div className="flex justify-between items-center mt-2">
                        <h1 className="font-bold">Pickup Confirmed Status:</h1>
                        <Chip
                          size="sm"
                          variant="ghost"
                          value={rideConfirmed === false ? "pending" : "success"}
                          color={rideConfirmed === false ? "red" : "orange"}
                          className="px-3 text-center w-28"
                        />
                      </div>
                      {user?.role === "admin" && (
                        <div className="flex justify-between items-center mt-2">
                          <h1 className="font-bold">Settlement Status:</h1>
                          <Chip
                            size="sm"
                            variant="ghost"
                            value={settled === false ? "pending" : "fulfilled"}
                            color={settled === false ? "red" : "blue"}
                            className="px-3 text-center w-28"
                          />
                        </div>
                      )}
                      <div className="flex justify-between items-center mt-2">
                        <h1 className="font-bold">Ride Cancel Status:</h1>
                        {cancellationRefundId ? (
                          <Chip
                            size="sm"
                            variant="ghost"
                            value={cancellationRefundStatus && "success"}
                            color={cancellationRefundId ? "blue" : "orange"}
                            className="px-3 text-center w-28"
                          />
                        ) : (
                          "N/A"
                        )}
                      </div>
                      <div className="flex justify-between items-center mt-2">
                        <p className="font-bold">Created Date:</p>
                        <p className="app-font">{formatDate(createdAt)}</p>
                      </div>
                      {user?.role === "admin" && (
                        <div className="flex justify-between items-center mt-2">
                          <h1 className="font-bold">Confirm Booking:</h1>
                          <Button
                            size="sm"
                            color="blue"
                            disabled={
                              rideConfirmed ||
                              !["pending", "completed"].includes(status) ||
                              isConfirming
                            }
                            onClick={() => handleConfirmBooking(_id)}
                          >
                            {isConfirming ? "Confirming..." : "Confirm"}
                          </Button>
                        </div>
                      )}
                      <div className="flex items-center bg-blue-50 rounded-b-lg mt-3 justify-between">
                        <Tooltip text="Location">
                          <ShowLocationModal vehicle={vehicle} />
                        </Tooltip>
                        {user?.role === "admin" && (
                          <Tooltip text="Cancel Ride">
                            <CancelRideModal
                              orderId={_id}
                              vehicleBasePrice={shopAmount}
                              refetch={refetch}
                            />
                          </Tooltip>
                        )}
      
                    
        
                      </div>
                    </div>
                  </div>
                );
              }
            )}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-blue-300 p-4">
        <Typography variant="small" color="blue-gray" className="font-normal">
          Page {page} of {Math.ceil((data?.stats?.totalOrders ?? 0) / limit)}
        </Typography>
        <div className="flex gap-2">
          <Button
            variant="outlined"
            size="sm"
            className="hover:bg-blue-50 active:bg-blue-50 focus:bg-blue-50 transition-colors duration-300 hover:shadow-none shadow-none bg-transparent border text-black border-blue-200"
            onClick={handlePrevious}
            disabled={page === 1}
          >
            Previous
          </Button>
          <Button
            variant="outlined"
            size="sm"
            className="hover:shadow-none shadow-none bg-blue-500"
            onClick={handleNext}
            disabled={page === Math.ceil((data?.stats?.totalOrders ?? 0) / limit)}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}