import SuccessBookedVehicleTranscation from "./SuccessBookedVehicleTranscation"
const BookedVehicles = () => {
  return (
    <div>
        <SuccessBookedVehicleTranscation/>
    </div>
  )
}

export default BookedVehicles