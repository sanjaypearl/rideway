/* src/components/.../TodaysOrder.jsx */
import React from "react";
import { Eye, RefreshCw } from "lucide-react";
import VerifyRideModal from "../../bookedVehicles/modal/VerifyRideModal";
import { Chip, IconButton } from "@material-tailwind/react";
import { motion } from "framer-motion";
import authService from "../../../../services/authService";
import { useNavigate } from "react-router-dom";
import { useGetAdminStatsQuery } from "../../../../redux/slices/adminApiSlice";

const months = [
  { value: 1, label: "Jan" }, { value: 2, label: "Feb" },
  { value: 3, label: "Mar" }, { value: 4, label: "Apr" },
  { value: 5, label: "May" }, { value: 6, label: "Jun" },
  { value: 7, label: "Jul" }, { value: 8, label: "Aug" },
  { value: 9, label: "Sep" }, { value: 10, label: "Oct" },
  { value: 11, label: "Nov" }, { value: 12, label: "Dec" },
];
const years = [2023, 2024, 2025];

export default function TodaysOrder({
  selectedMonth,
  setSelectedMonth,
  selectedYear,
  setSelectedYear,
}) {
  const user = authService.getCurrentUser();
  const navigate = useNavigate();
  const { data, error, isLoading, refetch } = useGetAdminStatsQuery({
    year: selectedYear,
    month: selectedMonth,
  });

  return (
    <div className="flex-1 bg-blue-50 p-4 border border-blue-300 rounded-xl shadow-lg">
{/* 
        <pre>
            {JSON.stringify(data,null,2)}
        </pre> */}
      <header className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Today's Orders</h1>
        <div className="flex items-center space-x-2">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="border border-blue-300 rounded-lg px-3 py-1 bg-white text-sm"
          >
            {months.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="border border-blue-300 rounded-lg px-3 py-1 bg-white text-sm"
          >
            {years.map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <IconButton
            onClick={refetch}
            variant="text"
            className="p-1 hover:bg-transparent focus:bg-transparent"
          >
            <RefreshCw className="h-5 w-5 text-gray-600" />
          </IconButton>
        </div>
      </header>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="overflow-x-auto rounded-lg"
      >
        <table className="min-w-full divide-y divide-blue-300">
          <thead className="bg-blue-200 sticky top-0">
            <tr>
              {[
                "S.No.",
                "Number",
                "Price",
                "Payment Status",
                "Pickup Status",
                "Verify OTP",
                "Invoice",
              ].map((col) => (
                <th
                  key={col}
                  className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-blue-200">
            {data?.todayOrders?.map((order, idx) => (
              <tr
                key={order._id}
                className={`${
                  idx % 2 === 0 ? "bg-white" : "bg-blue-50"
                } hover:bg-blue-100 transition`}
              >
                <td className="px-4 py-2 text-sm text-gray-800">{idx + 1}.</td>
                <td className="px-4 py-2 text-sm text-gray-800">
                  {order.vehicleDetails?.vehicleNumber}
                </td>
                <td className="px-4 py-2 text-sm text-gray-800">
                  ₹ {order?.totalAmount}
                </td>
                <td className="px-4 py-2">
                  <Chip
                    size="sm"
                    variant="ghost"
                    value={order.status}
                    color={
                      order.status === "failed"
                        ? "red"
                        : order.status === "pending"
                        ? "orange"
                        : "blue"
                    }
                    className="w-24 text-center"
                  />
                </td>
                <td className="px-4 py-2">
                  <Chip
                    size="sm"
                    variant="ghost"
                    value={order.rideConfirmed ? "success" : "pending"}
                    color={order.rideConfirmed ? "blue" : "red"}
                    className="w-24 text-center"
                  />
                </td>
                <td className="px-4 py-2 text-center">
                  <VerifyRideModal
                    orderId={order._id}
                    refetch={refetch}
                    rideConfirmed={order.rideConfirmed}
                  />
                </td>
                <td className="px-4 py-2 text-right">
                  {[2].includes(user?.role) && (
                    <IconButton
                      onClick={() =>
                        navigate(
                          `/super-admin-dashboard/super-admin-home-page/super-admin-vehicle-book/vehicle-book-invoice/${order._id}`
                        )
                      }
                      variant="text"
                      className="hover:bg-transparent focus:bg-transparent"
                    >
                      <Eye className="h-5 w-5 text-gray-700" />
                    </IconButton>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  );
}
