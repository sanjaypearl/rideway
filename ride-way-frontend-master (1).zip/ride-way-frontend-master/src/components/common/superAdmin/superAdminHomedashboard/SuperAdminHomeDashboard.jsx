/* SuperAdminHomeDashboard.jsx */
import  { useState } from 'react';
import TopCardStatus from './TopCardStatus';
import TodaysOrder from './TodaysOrder';
import ChartStatus from './ChartStatus';

const SuperAdminHomeDashboard = () => {
  // default to current month & year
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());

  return (
    <div >
      {/* Top summary cards */}
      <TopCardStatus
        selectedMonth={selectedMonth}
        setSelectedMonth={setSelectedMonth}
        selectedYear={selectedYear}
        setSelectedYear={setSelectedYear}
      />

      {/* Orders table and chart side-by-side */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <TodaysOrder
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
          />
        </div>
        <div className="flex-2">
          <ChartStatus
            selectedMonth={selectedMonth}
            selectedYear={selectedYear}
          />
        </div>
      </div>
    </div>
  );
};

export default SuperAdminHomeDashboard;
