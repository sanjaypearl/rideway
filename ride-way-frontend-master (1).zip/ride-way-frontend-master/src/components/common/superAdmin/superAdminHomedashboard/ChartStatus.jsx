// src/components/.../ChartStatus.jsx
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { CardBody, Spinner } from "@material-tailwind/react";
import Chart from "react-apexcharts";
import { useGetAdminStatsQuery } from "../../../../redux/slices/adminApiSlice";

export default function ChartStatus({ selectedMonth, selectedYear }) {
  const { data, error, isLoading } = useGetAdminStatsQuery({
    year: selectedYear,
    month: selectedMonth,
  });

  const chartConfig = {
    type: "pie",
    width: 280,
    height: 280,
    series: data
      ? [
          data.totalVehicles,
          data.totalOrders,
          data.totalSettled,
          data.pendingSettlements,
          data.totalRevenue,
        ]
      : [0, 0, 0, 0, 0],
    options: {
      chart: { toolbar: { show: false } },
      dataLabels: { enabled: true },
      colors: ["#ff8f00", "#3B3B98", "#26de81", "#ff3838", "#4CAF50"],
      legend: { show: true, position: "bottom" },
      labels: [
        "Total Vehicles",
        "Total Orders",
        "Total Settled",
        "Pending Settlements",
        "Revenue (₹)",
      ],
    },
  };

  return (
    <div className="w-full lg:w-80 flex justify-center bg-blue-50 border border-blue-400 rounded-lg">
      <CardBody>
        {isLoading ? <Spinner /> : <Chart {...chartConfig} />}
      </CardBody>
    </div>
  );
}
