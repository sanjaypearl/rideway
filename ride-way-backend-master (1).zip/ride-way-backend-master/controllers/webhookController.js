// controllers/payments/webhookController.js
import crypto from "crypto";
import { Order } from "../models/Order.js";

export const razorpayWebhookHandler = async (req, res) => {
  try {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET;

    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(JSON.stringify(req.body))
      .digest("hex");

    const receivedSignature = req.headers["x-razorpay-signature"];

    if (expectedSignature !== receivedSignature) {
      console.log("⚠️ Signature mismatch");
      return res.status(400).json({ success: false, message: "Invalid signature" });
    }

    const event = req.body;

    if (event.event === "payment_link.paid") {
      const paymentLinkId = event.payload.payment_link.entity.id;
      const paymentId = event.payload.payment.entity.id;

      const updatedOrder = await Order.findOneAndUpdate(
        { razorpay_payment_link_id: paymentLinkId },
        {
          razorpay_payment_id: paymentId,
          status: "completed",
        },
        { new: true }
      );

      if (!updatedOrder) {
        console.log("No matching order for payment link:", paymentLinkId);
        return res.status(404).json({ success: false, message: "Order not found" });
      }

      console.log("✅ Order marked as completed:", updatedOrder._id);
      return res.status(200).json({ success: true });
    }

    // Handle other event types if needed
    return res.status(200).json({ success: true, message: "Unhandled event" });

  } catch (error) {
    console.error("Webhook handler error:", error);
    return res.status(500).json({ success: false, error: error.message });
  }
};
