// controllers/departmentController.js
import { Department } from "../models/Department.js";

/* ───────────── Add Department ───────────── */
export const addDepartment = async (req, res) => {
  try {
    const { departmentName } = req.body;
    if (!departmentName) {
      return res.status(400).json({ error: "Department name is required." });
    }

    const existing = await Department.findOne({ departmentName });
    if (existing) {
      return res.status(400).json({ error: "Department already exists." });
    }

    const newDept = new Department({ departmentName });
    await newDept.save();

    return res.status(201).json({ message: "Department added successfully." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

/* ───────────── Get Departments ───────────── */
export const getDepartments = async (req, res) => {
  try {
    const departments = await Department.find({});
    if (!departments || departments.length === 0) {
      return res.status(404).json({ message: "No departments found." });
    }
    return res.status(200).json({ departments });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

/* ───────────── Delete Department ───────────── */
export const deleteDepartment = async (req, res) => {
  try {
    const { id } = req.query;
    if (!id) return res.status(400).json({ error: "Department ID is required." });

    const deleted = await Department.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: "Department not found." });
    }
    return res.status(200).json({ message: "Department deleted successfully." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

/* ───────────── Edit Department ───────────── */
export const editDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { departmentName } = req.body;

    if (!departmentName) {
      return res.status(400).json({ error: "Department name is required." });
    }

    const exists = await Department.findOne({ departmentName });
    if (exists) {
      return res.status(400).json({ error: "Department with this name already exists." });
    }

    const updated = await Department.findByIdAndUpdate(
      id,
      { departmentName },
      { new: true, runValidators: true }
    );

    if (!updated) {
      return res.status(404).json({ error: "Department not found." });
    }

    return res.status(200).json({ message: "Department updated successfully." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
