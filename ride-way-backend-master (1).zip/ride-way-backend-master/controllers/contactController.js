// controllers/contactController.js
import { Contact } from "../models/Contact.js";

// Max 5 contacts per email per day
export const createContact = async (req, res) => {
  try {
    const { email } = req.body;

    // Define start & end of today
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    // Count existing contacts for this email today
    const countToday = await Contact.countDocuments({
      email,
      createdAt: { $gte: startOfDay, $lte: endOfDay },
    });

    if (countToday >= 5) {
      return res.status(429).json({
        error: "You have reached the maximum of 5 messages for today.",
      });
    }

    // Otherwise save new contact message
    const contact = new Contact(req.body);
    await contact.save();

    res.status(201).json({ message: "Message sent successfully" });
  } catch (error) {
    console.error("Error saving contact:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getAllContacts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || "";

    const query = {
      $or: [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { message: { $regex: search, $options: "i" } },
      ],
    };

    const total = await Contact.countDocuments(query);
    const contacts = await Contact.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({
      total,
      page,
      limit,
      contacts,
    });
  } catch (error) {
    console.error("Error fetching contacts:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
