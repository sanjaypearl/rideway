import cloudinary from "cloudinary";
import sanitizeHtml from "sanitize-html";
import { Blog } from "../models/blog.js";

/* ────────── HELPERS ────────── */
const uploadBlogImage = async (file) => {
  const r = await cloudinary.v2.uploader.upload(file.path);
  return { public_id: r.public_id, url: r.secure_url };
};

/* ────────── CONTROLLERS ────────── */

export const addBlog = async (req, res) => {
  try {
    const { title, content, author } = req.body;
    if (!title || !content)
      return res.status(400).json({ error: "Title and content are required." });
    if (!req.file)
      return res.status(400).json({ error: "Blog thumbnail is required." });

    const exists = await Blog.findOne({ title });
    if (exists)
      return res
        .status(400)
        .json({ error: "Blog with this title already exists." });

    const sanitizedContent = sanitizeHtml(content, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat([
        "h1",
        "h2",
        "h3",
        "img",
      ]),
      allowedAttributes: {
        ...sanitizeHtml.defaults.allowedAttributes,
        img: ["src", "alt"],
      },
    });

    const thumbnail = await uploadBlogImage(req.file);

    const blog = await Blog.create({
      title,
      content: sanitizedContent,
      author: author || "Admin",
      thumbnail,
    });
    res.status(201).json({ message: "Blog added successfully.", blog });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find({}).select(
      "title thumbnail content date author views"
    );
    if (!blogs.length)
      return res.status(404).json({ error: "No blogs found." });
    res.json({ blogs });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getSingleBlog = async (req, res) => {
  try {
    const { id } = req.params;

    const blog = await Blog.findById(id);
    if (!blog) return res.status(404).json({ error: "Blog not found." });

    res.json({ blog });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getBlogsAdmin = async (req, res) => {
  try {
    let { search = "", page = 1, limit = 10 } = req.query;
    page = Number(page);
    limit = Number(limit);
    if (!page || !limit || page < 1 || limit < 1)
      return res
        .status(400)
        .json({ error: "Page and limit must be numbers ≥ 1." });

    const regex = new RegExp(search, "i");
    const q = { $or: [{ title: regex }, { author: regex }] };

    const [totalBlogs, blogs] = await Promise.all([
      Blog.countDocuments(q),
      Blog.find(q)
        .skip((page - 1) * limit)
        .limit(limit),
    ]);

    if (!blogs.length)
      return res.status(404).json({ error: "No blogs found." });
    res.json({ blogs, totalBlogs });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const deleteBlog = async (req, res) => {
  try {
    const { id } = req.params; // Fixed: Use req.params instead of req.query
    const deleted = await Blog.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: "Blog not found." });

    // Optionally delete the associated thumbnail from Cloudinary
    if (deleted.thumbnail?.public_id) {
      await cloudinary.v2.uploader.destroy(deleted.thumbnail.public_id);
    }

    res.json({ message: "Blog deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const editBlog = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    if (!Object.keys(data).length && !req.file)
      return res.status(400).json({ error: "Nothing to update." });

    if (data.title) {
      const dup = await Blog.findOne({ title: data.title, _id: { $ne: id } });
      if (dup)
        return res
          .status(400)
          .json({ error: "Blog with this title already exists." });
    }

    if (data.content) {
      data.content = sanitizeHtml(data.content, {
        allowedTags: sanitizeHtml.defaults.allowedTags.concat([
          "h1",
          "h2",
          "h3",
          "img",
        ]),
        allowedAttributes: {
          ...sanitizeHtml.defaults.allowedAttributes,
          img: ["src", "alt"],
        },
      });
    }

    if (req.file) {
      // Delete old thumbnail from Cloudinary if it exists
      const existingBlog = await Blog.findById(id);
      if (existingBlog?.thumbnail?.public_id) {
        await cloudinary.v2.uploader.destroy(existingBlog.thumbnail.public_id);
      }
      data.thumbnail = await uploadBlogImage(req.file);
    }

    const updated = await Blog.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ error: "Blog not found." });

    res.json({ message: "Blog updated successfully.", blog: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
