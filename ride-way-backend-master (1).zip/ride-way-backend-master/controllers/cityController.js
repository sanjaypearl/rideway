// controllers/cityController.js
import cloudinary from "cloudinary";
import { City } from "../models/City.js";

/* ────────── HELPERS ────────── */
const uploadCityImage = async (file) => {
  const r = await cloudinary.v2.uploader.upload(file.path);
  return { public_id: r.public_id, url: r.secure_url };
};

/* ────────── CONTROLLERS ────────── */

export const addCity = async (req, res) => {
  try {
    const { cityName, cityState } = req.body;
    if (!cityName) return res.status(400).json({ error: "City name is required." });
    if (!req.file) return res.status(400).json({ error: "City image is required." });

    const exists = await City.findOne({ cityName });
    if (exists) return res.status(400).json({ error: "City already exists." });

    const cityImage = await uploadCityImage(req.file);


    const city = await City.create({ cityName, cityState, cityImage });
    res.status(201).json({ message: "City added successfully.", city });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getCities = async (req, res) => {
  try {
    const cities = await City.find({});
    if (!cities.length) return res.status(404).json({ error: "No cities found." });
    res.json({ cities });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getCitiesAdmin = async (req, res) => {
  try {
    let { search = "", page = 1, limit = 10 } = req.query;
    page = Number(page);
    limit = Number(limit);
    if (!page || !limit)
      return res.status(400).json({ error: "Page and limit must be numbers ≥ 1." });

    const regex = new RegExp(search, "i");
    const q = { $or: [{ cityName: regex }, { cityState: regex }] };

    const [totalCities, cities] = await Promise.all([
      City.countDocuments(q),
      City.find(q).skip((page - 1) * limit).limit(limit),
    ]);

    if (!cities.length) return res.status(404).json({ error: "No cities found." });
    res.json({ cities, totalCities });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const deleteCity = async (req, res) => {
  try {
    const { id } = req.query;
    const deleted = await City.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: "City not found." });
    res.json({ message: "City deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const editCity = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    if (!Object.keys(data).length && !req.files)
      return res.status(400).json({ error: "Nothing to update." });

    if (data.cityName) {
      const dup = await City.findOne({ cityName: data.cityName, _id: { $ne: id } });
      if (dup) return res.status(400).json({ error: "City with this name already exists." });
    }

    if (req.files?.cityImage?.[0]) {
      data.cityImage = await uploadCityImage(req.files.cityImage[0]);
    }

    const updated = await City.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ error: "City not found." });

    res.json({ message: "City updated successfully.", city: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
