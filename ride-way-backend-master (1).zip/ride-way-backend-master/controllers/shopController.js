// controllers/shopController.js
import bcrypt from "bcryptjs";
import cloudinary from "cloudinary";
import mongoose from "mongoose";

import { Shop } from "../models/Shop.js";
import { Vehicle } from "../models/Vehical.js";
import { Order } from "../models/Order.js";

// ───────────────────────────── HELPERS ─────────────────────────────
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * POST /add-shop
 */
export async function addShop(req, res) {
  try {
    const {
      shopName,
      ownerName,
      ownerEmail,
      password,
      ownerPhoneNumber,
      gender,
      selectCity,
      lat,
      lng,
      ifsc,
      account_number,
      account_holder_name,
      shop_OpeningTime,
      shop_ClosedTime,
    } = req.body;

    // 1️⃣ required‑field loop
    for (const [k, v] of Object.entries({
      shopName,
      ownerName,
      ownerEmail,
      password,
      ownerPhoneNumber,
      gender,
      selectCity,
      lat,
      lng,
      ifsc,
      account_number,
      account_holder_name,
      shop_OpeningTime,
      shop_ClosedTime,
    })) {
      if (!v) return res.status(400).json({ error: `${k} is required.` });
    }

    // 2️⃣ validation
    if (!emailRegex.test(ownerEmail))
      return res.status(400).json({ error: "Invalid email format." });

    if (ownerPhoneNumber.length !== 10 || !/^\d+$/.test(ownerPhoneNumber))
      return res
        .status(400)
        .json({ error: "Phone number must be exactly 10 digits." });

    const [emailExists, phoneExists] = await Promise.all([
      Shop.findOne({ ownerEmail }),
      Shop.findOne({ ownerPhoneNumber }),
    ]);
    if (emailExists || phoneExists)
      return res
        .status(400)
        .json({ error: "Shop with this email or phone already exists." });

    // 3️⃣ Cloudinary upload
    let shopImage;
    if (req.files?.shopImage?.[0]) {
      const img = req.files.shopImage[0];
      const result = await cloudinary.v2.uploader.upload(img.path);
      shopImage = { public_id: result.public_id, url: result.url };
    } else {
      return res.status(400).json({ error: "Shop image is required." });
    }

    // 4️⃣ persist
    const hashed = await bcrypt.hash(password, await bcrypt.genSalt(10));
    const shop = await Shop.create({
      shopImage,
      shopName,
      ownerName,
      ownerEmail,
      password: hashed,
      ownerPhoneNumber,
      gender,
      selectCity,
      lat,
      lng,
      ifsc,
      account_number,
      account_holder_name,
      shop_OpeningTime,
      shop_ClosedTime,
    });

    return res
      .status(201)
      .json({ message: "Congratulations! Your shop has been listed.", shop });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

/**
 * GET /get-shops
 */
export async function getShops(req, res) {
  try {
    let { search = "", page = 1, limit = 10, city } = req.query;
    page = Number(page);
    limit = Number(limit);
    if (!page || !limit)
      return res
        .status(400)
        .json({ error: "Page and limit must be numbers ≥ 1." });

    const filter = city ? { selectCity: city } : {};
    const regex = new RegExp(search, "i");
    const query = {
      $and: [
        filter,
        { $or: [{ ownerEmail: regex }, { shopName: regex }] },
      ],
    };

    const [total, shops] = await Promise.all([
      Shop.countDocuments(query),
      Shop.find(query)
        .populate("selectCity")
        .skip((page - 1) * limit)
        .limit(limit)
        .select("-password"),
    ]);

    if (!shops.length) return res.status(404).json({ error: "No shops found." });
    res.json({ shops, totalShops: total });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

/**
 * PUT /edit-shop/:id
 */
export async function editShop(req, res) {
  try {
    const { id } = req.params;
    const data = req.body;

    // parse JSON strings sent from front‑end form‑data
    ["shopImage", "legalDoc"].forEach((f) => {
      if (data[f]) data[f] = JSON.parse(data[f]);
    });

    if (!Object.keys(data).length && !req.files)
      return res.status(400).json({ error: "Nothing to update." });

    // duplicate check
    if (data.ownerEmail || data.ownerPhoneNumber) {
      const dup = await Shop.findOne({
        _id: { $ne: id },
        $or: [
          { ownerEmail: data.ownerEmail },
          { ownerPhoneNumber: data.ownerPhoneNumber },
        ],
      });
      if (dup)
        return res
          .status(400)
          .json({ error: "Shop with this email or number already exists." });
    }

    // uploads
    if (req.files?.shopImage?.[0]) {
      const img = req.files.shopImage[0];
      const r = await cloudinary.v2.uploader.upload(img.path);
      data.shopImage = { public_id: r.public_id, url: r.url };
    }
    if (req.files?.legalDoc?.[0]) {
      const doc = req.files.legalDoc[0];
      const r = await cloudinary.v2.uploader.upload(doc.path);
      data.legalDoc = { public_id: r.public_id, url: r.url };
    }

    const updated = await Shop.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ error: "Shop not found." });

    res.json({ message: "Shop updated successfully.", updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

/**
 * DELETE /delete-shop/:id
 */
export async function deleteShop(req, res) {
  try {
    const { id } = req.params;
    const deleted = await Shop.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: "Shop not found." });
    res.json({ message: "Shop deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

/* ─────────────────────── STATUS / ADMIN ACTIONS ─────────────────────── */

export async function verifyOwnerAccount(req, res) {
  try {
    const { shopId } = req.params;
    const shop = await Shop.findByIdAndUpdate(
      shopId,
      { account_verified: true },
      { new: true }
    );
    if (!shop) return res.status(404).json({ error: "Shop not found." });
    res.json({ message: "Owner account verified.", shop });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

export const deactivateShopByOwner = async (req, res) =>
  toggleShop(req, res, "ownerActivation", false);
export const activateShopByOwner = async (req, res) =>
  toggleShop(req, res, "ownerActivation", true);
export const deactivateShopByAdmin = async (req, res) =>
  toggleShop(req, res, "adminActivation", false);
export const activateShopByAdmin = async (req, res) =>
  toggleShop(req, res, "adminActivation", true);

async function toggleShop(req, res, field, value) {
  try {
    const { shopId } = req.params;
    const shop = await Shop.findByIdAndUpdate(
      shopId,
      { [field]: value },
      { new: true }
    );
    if (!shop) return res.status(404).json({ error: "Shop not found." });
    res.json({ message: `Shop ${value ? "activated" : "deactivated"} successfully.` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error." });
  }
}

/**
 * GET /shop-stats/:shopId
 */
export async function getShopStats(req, res) {
  try {
    const { shopId } = req.params;
    const { year, month } = req.query;
    if (!year || !month)
      return res.status(400).json({ error: "year and month are required." });

    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 0, 23, 59, 59);

    const today = new Date();
    const startToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const endToday = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);

    const totalVehicles = await Vehicle.countDocuments({ shop: shopId });

    const monthly = await Order.aggregate([
      {
        $lookup: {
          from: "vehicles",
          localField: "vehicle",
          foreignField: "_id",
          as: "vehicleDetails",
        },
      },
      { $unwind: "$vehicleDetails" },
      {
        $match: {
          "vehicleDetails.shop": new mongoose.Types.ObjectId(shopId),
          status: "completed",
          rideConfirmed: true,
          createdAt: { $gte: start, $lte: end },
        },
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalSettled: { $sum: { $cond: ["$settled", 1, 0] } },
          pendingSettlements: { $sum: { $cond: ["$settled", 0, 1] } },
          totalRevenue: { $sum: "$totalAmount" },
        },
      },
    ]);

    const todayOrders = await Order.aggregate([
      {
        $lookup: {
          from: "vehicles",
          localField: "vehicle",
          foreignField: "_id",
          as: "vehicleDetails",
        },
      },
      { $unwind: "$vehicleDetails" },
      {
        $match: {
          "vehicleDetails.shop": new mongoose.Types.ObjectId(shopId),
          status: "completed",
          createdAt: { $gte: startToday, $lte: endToday },
        },
      },
    ]);

    const m = monthly[0] || {
      totalOrders: 0,
      totalSettled: 0,
      pendingSettlements: 0,
      totalRevenue: 0,
    };

    res.json({
      totalVehicles,
      totalOrders: m.totalOrders,
      totalSettled: m.totalSettled,
      pendingSettlements: m.pendingSettlements,
      totalRevenue: m.totalRevenue,
      todayOrders,
      todayOrderCount: todayOrders.length,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch shop statistics." });
  }
}
