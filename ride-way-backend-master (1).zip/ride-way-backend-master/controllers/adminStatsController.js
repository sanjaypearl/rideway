// controllers/adminStatsController.js
import { Order } from "../models/Order.js";
import { Vehicle } from "../models/Vehical.js";
import { User } from "../models/User.js";
import { Shop } from "../models/Shop.js";
import { Employee } from "../models/Employee.js";
import { Host } from "../models/Host.js";
import cloudinary from "cloudinary";

export const getAdminStats = async (req, res) => {
  try {
    const { year, month } = req.query;
    if (!year || !month) {
      return res
        .status(400)
        .json({ error: "Year and month are required as query params." });
    }

    // Build date ranges
    const y = Number(year);
    const m = Number(month);
    const startOfMonth = new Date(y, m - 1, 1);
    const endOfMonth = new Date(y, m, 0, 23, 59, 59);

    const today = new Date();
    const startOfDay = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
    const endOfDay = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
      23,
      59,
      59
    );

    /* 1️⃣ Simple counts */
    const [totalVehicles, totalShopOwners, totalUsers, totalEmployees] =
      await Promise.all([
        Vehicle.countDocuments(),
        Shop.countDocuments(),
        User.countDocuments(),
        Employee.countDocuments(),
      ]);

    /* 2️⃣ Monthly order stats */
    const monthly = await Order.aggregate([
      {
        $match: {
          status: "completed",
       
        },
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalSettled: { $sum: { $cond: ["$settled", 1, 0] } },
          pendingSettlements: { $sum: { $cond: ["$settled", 0, 1] } },
          totalRevenue: { $sum: "$totalAmount" },
        },
      },
    ]);

    const {
      totalOrders = 0,
      totalSettled = 0,
      pendingSettlements = 0,
      totalRevenue = 0,
    } = monthly[0] || {};

    /* 3️⃣ Today’s completed orders (+vehicle details) */
    const todayOrders = await Order.aggregate([

      {
        $lookup: {
          from: "vehicles",
          localField: "vehicle",
          foreignField: "_id",
          as: "vehicleDetails",
        },
      },
      { $unwind: "$vehicleDetails" },
    ]);
    const todayOrderCount = todayOrders.length;

    return res.json({
      totalVehicles,
      totalShopOwners,
      totalUsers,
      totalEmployees,

      totalOrders,
      totalSettled,
      pendingSettlements,
      totalRevenue,

      todayOrders,
      todayOrderCount,
    });
  } catch (err) {
    console.error("Admin stats error:", err);
    res.status(500).json({ error: "Failed to fetch admin statistics." });
  }
};

// @desc Get all hosts (with optional filter by status)
export const getAllHosts = async (req, res) => {
  try {
    const { approved } = req.query; // optional filter

    const query = {};
    if (approved === "true") query.approved = true;
    if (approved === "false") query.approved = false;
    console.log(query)

    const hosts = await Host.find(query).sort({ createdAt: -1 });
    res.json({ hosts });
  } catch (error) {
    console.error("Get all hosts error:", error);
    res.status(500).json({ error: "Failed to fetch hosts." });
  }
};

// @desc Verify a host by ID
export const verifyHost = async (req, res) => {
  try {
    const { id } = req.params;

    const host = await Host.findById(id);
    if (!host) return res.status(404).json({ error: "Host not found." });

    host.approved = true;
    await host.save();

    res.json({ message: "Host verified successfully." });
  } catch (error) {
    console.error("Verify host error:", error);
    res.status(500).json({ error: "Failed to verify host." });
  }
};

// @desc Delete a host by ID (with file cleanup if needed)
export const deleteHost = async (req, res) => {
  try {
    const { id } = req.params;

    const host = await Host.findById(id);
    if (!host) return res.status(404).json({ error: "Host not found." });

    // Optional: Remove files from Cloudinary
    if (host.aadhaar?.public_id)
      await cloudinary.v2.uploader.destroy(host.aadhaar.public_id);
    if (host.license?.public_id)
      await cloudinary.v2.uploader.destroy(host.license.public_id);

    await host.deleteOne();

    res.json({ message: "Host deleted successfully." });
  } catch (error) {
    console.error("Delete host error:", error);
    res.status(500).json({ error: "Failed to delete host." });
  }
};

export const confirmBooking = async (req, res) => {
  const { orderId } = req.params;

  try {
    // 1. Validate admin authorization
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Only admins can confirm bookings.",
      });
    }

    // 2. Find the order by ID
    const order = await Order.findById(orderId).populate("user vehicle");
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found.",
      });
    }

    // 3. Check if the order is already confirmed or cancelled
    if (order.status === "completed" || order.rideConfirmed) {
      return res.status(400).json({
        success: false,
        message: "Order is already confirmed.",
      });
    }
    if (order.status === "cancelled") {
      return res.status(400).json({
        success: false,
        message: "Cannot confirm a cancelled order.",
      });
    }

    // 4. Find the vehicle
    const vehicle = await Vehicle.findById(order.vehicle);
    if (!vehicle) {
      return res.status(404).json({
        success: false,
        message: "Vehicle not found.",
      });
    }

    // 5. Update the order
    order.status = "completed";
    order.rideConfirmed = true;
    await order.save();

    // 6. Update the vehicle's bookedDates
    vehicle.bookedDates.push({
      bookedThrough: "rideRozClient",
      startDate: order.startDate,
      endDate: order.endDate,
    });
    await vehicle.save();

    // 7. Return the updated order
    const updatedOrder = await Order.findById(orderId).populate("user vehicle");
    return res.status(200).json({
      success: true,
      message: "Booking confirmed successfully.",
      order: updatedOrder,
    });
  } catch (error) {
    console.error("Error confirming booking:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to confirm booking due to an internal error.",
      error: error?.message || "Unknown error",
    });
  }
};
