import express from "express";
import multer from "multer";
import {
  addBlog,
  getBlogs,
  getBlogsAdmin,
  deleteBlog,
  editBlog,
  getSingleBlog,
} from "../controllers/blogController.js";
import { authenticateAnyRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

/* ────────────── Multer setup ────────────── */
const storage = multer.diskStorage({});
const upload = multer({ storage });

/* ────────────── Routes ────────────── */

// Only admins can create a blog
router.post(
  "/add-blog",
  authenticateAnyRoles("admin"),
  upload.single("thumbnail"),
  addBlog
);

// Public list of blogs
router.get("/get-blogs", getBlogs);
router.get("/get-blogs/:id", getSingleBlog);

// Admin list with extra details
router.get(
  "/get-blogs-admin",
  authenticateAnyRoles("admin"),
  getBlogsAdmin
);

// Delete blog
router.delete(
  "/delete-blog/:id",
  authenticateAnyRoles("admin"),
  deleteBlog
);

// Edit blog
router.put(
  "/edit-blog/:id",
  authenticateAnyRoles("admin"),
  upload.single("thumbnail"),
  editBlog
);

export default router;