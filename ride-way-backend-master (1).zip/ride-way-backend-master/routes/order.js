import express from "express";
import multer from "multer";

import {
  createOrder,
  uploadAadharCard,
  confirmOrder,
  cancelOrder,
  getOrders,
  getOrderById,
  getOrdersByShop,
  getOrderStatus,
} from "../controllers/orderController.js";

import {
  authenticateLoggedInUser,
  authenticateAnyRoles,
} from "../middleware/authMiddleware.js"; // adjust path if needed

const router = express.Router();

/* ────────── Multer Setup ────────── */
const storage = multer.diskStorage({});
const upload = multer({ storage });

/* ────────── Public/User Actions ────────── */

// Create a new order (by logged-in user)
router.post("/create-order/:vehicleId", authenticateLoggedInUser, createOrder);
router.get("/get-order-status/:reference_id", authenticateLoggedInUser, getOrderStatus);

// Upload Aadhaar card (by user)
router.post(
  "/upload-aadharcard",
  authenticateLoggedInUser,
  upload.fields([{ name: "adharcardImg", maxCount: 2 }]),
  uploadAadharCard
);

// Confirm an order (by user)
router.put("/confirm-order/:orderId", authenticateLoggedInUser, confirmOrder);

// Cancel an order (by user)
router.post("/cancel-order/:orderId", authenticateLoggedInUser, cancelOrder);

/* ────────── Admin/Host/Employee Access ────────── */

// View all orders
router.get(
  "/get-orders",
  authenticateAnyRoles("admin", "user"),
  getOrders
);

// View specific order by ID
router.get(
  "/get-order/:id",
  authenticateAnyRoles("admin", "user"),
  getOrderById
);

// View orders by shop ID (only admin and host)
router.get(
  "/get-orders-by-shop/:shopId",
  authenticateAnyRoles("admin"),
  getOrdersByShop
);

export default router;
