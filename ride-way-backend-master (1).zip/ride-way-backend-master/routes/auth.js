import express from "express";
import {
  forgotPassword,
  resetPassword,
  firstPasswordChange,
  signUpInitiate,
  signUpVerify,
  loginPhoneOrEmailRequest,
  loginPhoneOrEmailVerify,
  signUpHostInitiate,
  signUpHostVerify
} from "../controllers/authController.js";
import multer from "multer";

const upload = multer({ dest: "uploads/" });

const router = express.Router();

// User signup
router.post("/user/signup-initiate", signUpInitiate);
router.post("/user/signup-verify", signUpVerify);

// Host signup
router.post(
  "/host/signup-initiate",
  upload.fields([
    { name: "aadhaar", maxCount: 1 },
    { name: "license", maxCount: 1 },
    { name: "rc", maxCount: 1 },
    { name: "insurance", maxCount: 1 },
    { name: "puc", maxCount: 1 },
  ]),
  signUpHostInitiate
);
router.post("/host/signup-verify", signUpHostVerify);

// Shared login using phone or email
router.post("/login/request-otp", loginPhoneOrEmailRequest);
router.post("/login/verify-otp", loginPhoneOrEmailVerify);

// Password handling
router.post("/forgot-password", forgotPassword);
router.post("/reset-password/:token", resetPassword);
router.put("/first-password-change/:id", firstPasswordChange);

export default router;
