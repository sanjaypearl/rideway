// routes/cityRoutes.js
import express from "express";
import multer from "multer";

import {
  addCity,
  getCities,
  getCitiesAdmin,
  deleteCity,
  editCity,
} from "../controllers/cityController.js";

import {
  authenticateAnyRoles,    // new helper that accepts any number of roles
} from "../middleware/authMiddleware.js";  // adjust path if different

const router = express.Router();

/* ──────────────  Multer setup  ────────────── */
const storage = multer.diskStorage({});
const upload  = multer({ storage });

/* ──────────────  Routes  ────────────── */

// Only admins & hosts may create a city
router.post(
  "/add-city",
  authenticateAnyRoles("admin"),
  upload.single("cityImage"),        // simpler than .fields for one file
  addCity
);

// Public list
router.get("/get-cities", getCities);

// Admin / Host list with extra details
router.get(
  "/get-cities-admin",
  authenticateAnyRoles("admin"),
  getCitiesAdmin
);

// Delete city
router.delete(
  "/delete-city/:id",               // RESTful → include :id
  authenticateAnyRoles("admin"),
  deleteCity
);

// Edit city
router.put(
  "/edit-city/:id",
  authenticateAnyRoles("admin"),
  upload.single("cityImage"),
  editCity
);

export default router;
