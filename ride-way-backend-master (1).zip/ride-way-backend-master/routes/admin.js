import express from "express";
import { getAdminStats,getAllHosts,verifyHost,deleteHost, confirmBooking } from "../controllers/adminStatsController.js";
import { authenticateAdmin } from "../middleware/authMiddleware.js"; // updated import path if needed

const router = express.Router();

/**
 * Route: GET /admin/stats
 * Access: Admins only
 */
router.get("/stats", authenticateAdmin, getAdminStats);
router.get("/hosts", authenticateAdmin, getAllHosts);
router.patch("/hosts/verify/:id", authenticateAdmin, verifyHost);
router.delete("/hosts/:id", authenticateAdmin, deleteHost);
router.put("/order/confirm-booking/:orderId", authenticateAdmin, confirmBooking);


export default router;
