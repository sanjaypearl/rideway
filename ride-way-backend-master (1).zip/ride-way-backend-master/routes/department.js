import express from "express";
import {
  addDepartment,
  getDepartments,
  deleteDepartment,
  editDepartment,
} from "../controllers/departmentController.js";

import {
  authenticateAnyRoles,
} from "../middleware/authMiddleware.js"; // Adjust path if needed

const router = express.Router();

// Admin and Host can manage departments
router.post("/add-department", authenticateAnyRoles("admin"), addDepartment);
router.get("/get-departments", authenticateAnyRoles("admin"), getDepartments);
router.delete("/delete-department/:id", authenticateAnyRoles("admin"), deleteDepartment);
router.put("/edit-department/:id", authenticateAnyRoles("admin"), editDepartment);

export default router;
