import express from "express";
import { verifyPayment } from "../controllers/paymentController.js";
import { authenticateLoggedInUser } from "../middleware/authMiddleware.js"; // updated import path

const router = express.Router();

// Route: PUT /api/payment/verify
// Access: Logged-in users (any role)
router.put("/verify", authenticateLoggedInUser, verifyPayment);

export default router;
