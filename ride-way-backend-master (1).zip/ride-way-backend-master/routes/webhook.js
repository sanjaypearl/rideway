// routes/webhook.js
import express from "express";
import { razorpayWebhookHandler } from "../controllers/webhookController.js";
const router = express.Router();

// Razorpay webhooks must receive raw body
router.post(
  "/razorpay",
  express.raw({ type: "application/json" }), // 👈 required
  razorpayWebhookHandler
);

export default router;
