// routes/couponRoutes.js
import express from 'express';
import {
  createCoupon,
  validateCoupon,
  deactivateCoupon,
  deleteCoupon,
  getAllCoupons
} from '../controllers/couponController.js';

const router = express.Router();

router.post('/create', createCoupon);
router.post('/validate', validateCoupon);
router.put('/deactivate/:coupenId', deactivateCoupon);
router.delete('/delete/:coupenId', deleteCoupon);
router.get('/get-all', getAllCoupons);

export default router;
