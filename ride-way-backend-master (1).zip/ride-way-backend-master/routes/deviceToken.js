import express from 'express';
import { DeviceToken } from '../models/DeviceToken.js';
const router = express.Router();

router.post("/save-deviceToken", async (req, res) => {
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ message: "Token is required" });
  }

  try {
    let existingToken = await DeviceToken.findOne({ token });
    if (!existingToken) {
      const newToken = new DeviceToken({ token });
      await newToken.save();
    }
    res.status(200).json({ message: "Token saved successfully" });
  } catch (error) {
    console.error("Error saving token:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});


export default router;
