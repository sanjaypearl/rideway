// routes/employeeRoutes.js
import express from "express";
import multer from "multer";

import {
  addEmployee,
  getEmployees,
  editEmployee,
  deleteEmployee,
} from "../controllers/employeeController.js";

import {
  authenticateAnyRoles,        // helper that accepts any number of roles
} from "../middleware/authMiddleware.js"; // adjust path if different

const router = express.Router();

/* ──────────────  Multer setup  ────────────── */
const storage = multer.diskStorage({});
const upload  = multer({ storage });

const fileFields = [
  { name: "employeeAdharCard", maxCount: 1 },
  { name: "employeePanCard",  maxCount: 1 },
  { name: "employeeAgreement", maxCount: 1 },
  { name: "employeePhoto",     maxCount: 1 },
];

/* ──────────────  Routes  ────────────── */

// Create employee
router.post(
  "/add-employee",
  authenticateAnyRoles("admin"),
  upload.fields(fileFields),
  addEmployee
);

// List employees
router.get(
  "/get-employees",
  authenticateAnyRoles("admin"),
  getEmployees
);

// Update employee
router.put(
  "/edit-employee/:id",
  authenticateAnyRoles("admin"),
  upload.fields(fileFields),
  editEmployee
);

// Delete employee
router.delete(
  "/delete-employee/:id",
  authenticateAnyRoles("admin"),
  deleteEmployee
);

export default router;
