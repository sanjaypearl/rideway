import express from "express";
import {
  addRole,
  getRoles,
  deleteRole,
  editRole,
} from "../controllers/roleController.js";

import {
  authenticateAnyRoles,
} from "../middleware/authMiddleware.js"; // Update path if needed

const router = express.Router();

// Only admin and host can manage roles
router.post("/add-role", authenticateAnyRoles("admin",), addRole);
router.get("/get-roles", authenticateAnyRoles("admin"), getRoles);
router.delete("/delete-role/:id", authenticateAnyRoles("admin"), deleteRole);
router.put("/edit-role/:id", authenticateAnyRoles("admin"), editRole);

export default router;
