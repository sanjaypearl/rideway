import Tesseract from 'tesseract.js';

export const checkAadharCard = async (imagePath) => {
  try {
    const { data: { text, confidence } } = await Tesseract.recognize(imagePath, 'eng', {
      tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ',
      psm: 6,
    });

    // Normalize OCR text
    const cleanedText = text
      .replace(/[^A-Z0-9\s]/g, '')  // Remove symbols
      .replace(/\s+/g, ' ')         // Reduce spaces
      .toUpperCase()
      .trim();

    // Flexible Aadhaar number pattern
    const aadhaarPattern = /\b\d{4}\s?\d{4}\s?\d{4}\b/;

    // Expanded keyword list for better matching
    const keywords = [
      "GOVT", "INDIA", "AADHAAR", "AADHAR", "UNIQUE IDENTIFICATION", "UIDAI",
      "HELP", "DOB", "YOB", "S/O", "1800 300 1947", "INDIAN GOV"
    ];

    // Aadhaar detection logic
    const containsAadhaarNumber = aadhaarPattern.test(cleanedText);
    const containsKeywords = keywords.some(keyword => cleanedText.includes(keyword));

    // Log OCR for troubleshooting
    console.log("OCR Text:", cleanedText);
    console.log("OCR Confidence:", confidence);

    // Return result based on conditions
    if (containsAadhaarNumber && containsKeywords && confidence > 35) {
      return true;
    } else {
      console.warn("Low OCR confidence or insufficient Aadhaar data.");
      return false;
    }

  } catch (error) {
    console.error("Error recognizing Aadhaar text:", error);
    return false;
  }
};
