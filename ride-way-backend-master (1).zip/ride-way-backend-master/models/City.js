import mongoose from 'mongoose';

const citySchema = new mongoose.Schema({
    cityName: {
        type: String,
        required: true,
    },
    cityState: {
        type: String,
        required: true,
    },
    cityImage: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true
        }
    },
    priority: {
        type: String,
        default: "low",
        enum: ["low", "medium", "high"]
    }
},{
    timestamps: true,
});

// Ensure combination of cityName and cityState is unique
citySchema.index({ cityName: 1, cityState: 1 }, { unique: true });

export const City = mongoose.model('city', citySchema);
