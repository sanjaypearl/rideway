import mongoose from "mongoose";

const vehicleSchema = new mongoose.Schema(
  {
    vehicleType: {
      type: String,
      required: true,
      enum: ["car", "bike", "scooty"],
    },
    vehicleCity: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "city",
      required: true,
    },
    vehicleNumber: {
      type: String,
      required: true,
      unique: true,
    },
    vehicleName: {
      type: String,
      required: true,
    },
    vehicleModel: {
      type: String,
      required: true,
    },
    pricingPlans: [
      {
        durationInDays: {
          type: Number,
          required: true,
          enum: [1, 7, 30, 90, 180, 270, 365],
        },
        label: {
          type: String,
          required: true,
          enum: [
            "1 Day",
            "1 Week",
            "1 Month",
            "3 Months",
            "6 Months",
            "9 Months",
            "12 Months",
          ],
        },
        price: {
          type: Number,
          required: true,
        },
      },
    ],

    vehicleDetails: {
      type: String,
    },
    bookingPrice: {
      type: Number,
      required: true,
    },
    sittingCapacity: {
      type: Number,
      required: true,
      enum: [2, 5, 8, 10],
    },
    vehicleImage: [
      {
        // To store multiple images
        public_id: {
          type: String,
          required: true,
        },
        url: {
          type: String,
          required: true,
        },
      },
    ],
    vehicleAvailability: {
      type: Boolean,
      required: true,
      default: true,
    },
    shop: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "shop",
      required: true,
    },
    vehicleRatings: {
      type: Number,
      default: 0,
    },
    numOfReviews: {
      type: Number,
      default: 0,
    },
    bookedDates: [
      {
        bookedThrough: {
          type: String,
          required: true,
          enum: ["shopWalkin", "rideRozClient"],
        },
        startDate: {
          type: Date,
          required: true,
        },
        endDate: {
          type: Date,
          required: true,
        },
      },
    ],
    reviews: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "user",
          required: true,
        },
        rating: {
          type: Number,
          required: true,
        },
        comment: {
          type: String,
          required: true,
        },
        createdAt: {
          type: Date,
          default: Date.now,
          required: true,
        },
      },
    ],
    location: {
      // Added a location field to store latitude and longitude
      type: { type: String, enum: ["Point"], required: true, default: "Point" },
      coordinates: { type: [Number], required: true }, // Array format: [longitude, latitude]
    },
  },
  {
    timestamps: true,
  }
);

// Create a 2dsphere index on the location field
vehicleSchema.index({ location: "2dsphere" });

export const Vehicle = mongoose.model("Vehicle", vehicleSchema);
