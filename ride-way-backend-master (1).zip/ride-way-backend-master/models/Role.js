import mongoose from 'mongoose';

const roleSchema=new mongoose.Schema({
    roleName:{
        type:String,
        required:true,
        unique:true
    },
    roleCode:{
        type:Number,
        required:true,
        unique:true
    },
    departmentName:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'department',
        required:true
    }
},{
    timestamps: true,
})


export const Role=mongoose.model('role',roleSchema)