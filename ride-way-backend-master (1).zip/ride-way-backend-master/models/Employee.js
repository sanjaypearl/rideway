import mongoose from 'mongoose';


const employeeSchema = new mongoose.Schema({
    employeePhoto: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true,
        },
    },
    employeeName: {
        type: String,
        required: true,
    },
    employeeEmail: {
        type: String,
        required: true
    },
    employeeMobileNumber: {
        type: Number,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    department: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'department',
        required: true
    },
    role: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'role',
        required: true
    },
    employeeSalary: {
        type: Number,
        required: true
    },
    employeeAdharCard: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true,
        },
    },
    employeePanCard: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true,
        },
    },
    employeeAgreement: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true,
        },
    },
    fatherOrHusbandName: {
        type: String,
        required: true,
    },
    sex: {
        type: String,
        required: true,
        enum: ["male", "female", "other"],
    },
    maritalStatus: {
        type: String,
        required: true,
        enum: ["single", "married", "divorced", "widowed"],
    },
    bloodGroup: {
        type: String,
    },
    presentAddress: {
        type: String,
        required: true,
    },
    permanentAddress: {
        type: String,
        required: true,
    },
    dateOfBirth: {
        type: String,
        required: true,
    },
    dateOfJoining: {
        type: String,
        required: true,
    },
    requiredPasswordChange: {
        type: Boolean,
        default: true
    }
},{
    timestamps: true,
})


export const Employee = mongoose.model('employee', employeeSchema);