import { Vehicle } from "../models/Vehical.js"; // Note: "Vehical" seems to be a typo in the original code; assuming it should be "Vehicle"
import { Shop } from "../models/Shop.js";
import cloudinary from "cloudinary";
import mongoose from "mongoose";
import fs from "fs/promises";

// Helper function to calculate Haversine distance
const haversineDistance = (coords1, coords2) => {
  const toRad = (value) => (value * Math.PI) / 180;
  const lat1 = coords1[1];
  const lon1 = coords1[0];
  const lat2 = coords2[1];
  const lon2 = coords2[0];
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in kilometers
};

// Add vehicle (for shop owner)
export const addVehicle = async (req, res) => {
  try {
    let {
      vehicleType,
      vehicleName,
      vehicleNumber,
      vehicleModel,
      pricingPlans,
      sittingCapacity,
      vehicleDetails,
      vehicleAvailability = true,
      city,
      vehicalDetails, // fallback from frontend typo
    } = req.body;

    const userId = req.userId;
    const details = vehicleDetails || vehicalDetails || "";

    // Validate required fields
    const requiredFields = {
      vehicleType,
      vehicleName,
      vehicleNumber,
      vehicleModel,
      sittingCapacity,
      pricingPlans,
    };
    for (const [field, value] of Object.entries(requiredFields)) {
      if (!value) {
        return res.status(400).json({
          error: `${field.replace(/([A-Z])/g, " $1")} is required.`,
        });
      }
    }

    // Validate vehicle type
    const validVehicleTypes = ["car", "bike", "scooty"];
    if (!validVehicleTypes.includes(vehicleType.toLowerCase())) {
      return res
        .status(400)
        .json({ error: "Vehicle type must be car, bike, or scooty" });
    }

    // Validate sitting capacity
    const validCapacities = [2, 5, 8, 10];
    const parsedCapacity = parseInt(sittingCapacity);
    if (!validCapacities.includes(parsedCapacity)) {
      return res
        .status(400)
        .json({ error: "Sitting capacity must be 2, 5, 8, or 10" });
    }

    // Validate pricingPlans
    pricingPlans = JSON.parse(req.body.pricingPlans);
    if (!Array.isArray(pricingPlans) || pricingPlans.length === 0) {
      return res.status(400).json({
        error: "Pricing plans are required and must be a non-empty array.",
      });
    }
    console.log(pricingPlans);
    for (const plan of pricingPlans) {
      if (![1, 7, 30, 90, 180, 270, 365].includes(plan.durationInDays)) {
        return res
          .status(400)
          .json({ error: `Invalid duration: ${plan.durationInDays}` });
      }
      if (!plan.price || typeof plan.price !== "number" || plan.price <= 0) {
        return res
          .status(400)
          .json({ error: `Invalid price for ${plan.durationInDays} days` });
      }
    }

    const parsedAvailability =
      vehicleAvailability === "true" || vehicleAvailability === true;

    // Get shop and city
    const shop = await Shop.findById(userId);
    if (!shop) return res.status(404).json({ error: "Shop not found" });

    if (!mongoose.Types.ObjectId.isValid(shop.selectCity)) {
      return res.status(400).json({ error: "Invalid vehicle city reference" });
    }

    // Check duplicate vehicle
    const existingVehicle = await Vehicle.findOne({ vehicleNumber });
    if (existingVehicle) {
      return res
        .status(400)
        .json({ error: "Vehicle with this number already exists!" });
    }

    // Handle image uploads
    let vehicleImage = [];
    if (req.files && req.files.length > 0) {
      const uploadPromises = req.files.map(async (file) => {
        if (!file.mimetype.startsWith("image/")) {
          throw new Error(`File ${file.originalname} is not an image`);
        }
        const result = await cloudinary.uploader.upload(file.path, {
          folder: "vehicles",
        });
        return {
          public_id: result.public_id,
          url: result.secure_url,
        };
      });

      try {
        vehicleImage = await Promise.all(uploadPromises);
      } catch (uploadError) {
        return res
          .status(400)
          .json({ error: `Image upload failed: ${uploadError.message}` });
      } finally {
        await Promise.all(
          req.files.map((file) => fs.unlink(file.path).catch(() => {}))
        );
      }
    }

    // Calculate booking price from 1-day price
    const oneDayPlan = pricingPlans.find((p) => p.durationInDays === 1);
    const basePrice = oneDayPlan ? oneDayPlan.price : pricingPlans[0].price;
    const bookingPrice = basePrice <= 600 ? basePrice * 0.1 : basePrice * 0.07;

    const newVehicle = new Vehicle({
      vehicleType: vehicleType.toLowerCase(),
      vehicleCity: city,
      vehicleNumber,
      vehicleName,
      vehicleModel,
      pricingPlans,
      vehicleDetails: details,
      bookingPrice: parseFloat(bookingPrice.toFixed(2)),
      sittingCapacity: parsedCapacity,
      vehicleImage,
      vehicleAvailability: parsedAvailability,
      shop: userId,
      location: {
        type: "Point",
        coordinates: [parseFloat(shop.lng), parseFloat(shop.lat)],
      },
      vehicleRatings: 0,
      numOfReviews: 0,
      bookedDates: [],
      reviews: [],
    });

    await newVehicle.save();
    return res
      .status(200)
      .json({ message: "Vehicle added successfully!", newVehicle });
  } catch (error) {
    console.error("Error in addVehicle:", error.message);
    if (error.code === 11000) {
      return res
        .status(400)
        .json({ error: "Vehicle with this number already exists!" });
    }
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Add vehicle by shop ID (for admin)
export const addVehicleByShopId = async (req, res) => {
  try {
    const {
      vehicleType,
      vehicleName,
      vehicleNumber,
      vehicleModel,
      pricingPlans,
      sittingCapacity,
      vehicleDetails,
      vehicleAvailability,
    } = req.body;
    const { shopId } = req.params;

    // Required fields
    const requiredFields = {
      vehicleType,
      vehicleName,
      vehicleNumber,
      vehicleModel,
      sittingCapacity,
      pricingPlans,
      vehicleAvailability,
    };
    for (const [field, value] of Object.entries(requiredFields)) {
      if (!value) {
        return res.status(400).json({
          error: `${field.replace(/([A-Z])/g, " $1")} is required!`,
        });
      }
    }

    const validVehicleTypes = ["car", "bike", "scooty"];
    if (!validVehicleTypes.includes(vehicleType.toLowerCase())) {
      return res
        .status(400)
        .json({ error: "Vehicle type must be car, bike, or scooty" });
    }

    const validCapacities = [2, 5, 8, 10];
    const parsedCapacity = parseInt(sittingCapacity);
    if (!validCapacities.includes(parsedCapacity)) {
      return res
        .status(400)
        .json({ error: "Sitting capacity must be 2, 5, 8, or 10" });
    }

    if (!Array.isArray(pricingPlans) || pricingPlans.length === 0) {
      return res.status(400).json({
        error: "Pricing plans are required and must be a non-empty array.",
      });
    }

    for (const plan of pricingPlans) {
      if (![1, 7, 30, 90, 180, 270, 365].includes(plan.durationInDays)) {
        return res
          .status(400)
          .json({ error: `Invalid duration: ${plan.durationInDays}` });
      }
      if (!plan.price || typeof plan.price !== "number" || plan.price <= 0) {
        return res
          .status(400)
          .json({ error: `Invalid price for ${plan.durationInDays} days` });
      }
    }

    const existingVehicle = await Vehicle.findOne({ vehicleNumber });
    if (existingVehicle) {
      return res
        .status(400)
        .json({ error: "Vehicle with this number already exists!" });
    }

    const shop = await Shop.findById(shopId);
    if (!shop) {
      return res.status(404).json({ error: "Shop not found." });
    }

    // Image Upload
    let vehicleImage = [];
    if (req.files?.vehicleImage) {
      const uploadPromises = req.files["vehicleImage"].map((image) =>
        cloudinary.uploader.upload(image.path)
      );
      const uploadedImages = await Promise.all(uploadPromises);
      vehicleImage = uploadedImages.map((result) => ({
        public_id: result.public_id,
        url: result.secure_url,
      }));
    }

    const oneDayPlan = pricingPlans.find((p) => p.durationInDays === 1);
    const basePrice = oneDayPlan ? oneDayPlan.price : pricingPlans[0].price;
    const bookingPrice = basePrice <= 600 ? basePrice * 0.1 : basePrice * 0.07;

    const newVehicle = new Vehicle({
      vehicleType: vehicleType.toLowerCase(),
      vehicleNumber,
      vehicleName,
      vehicleModel,
      pricingPlans,
      sittingCapacity: parsedCapacity,
      vehicleImage,
      vehicleDetails,
      vehicleAvailability,
      bookingPrice: parseFloat(bookingPrice.toFixed(2)),
      shop: shopId,
      vehicleCity: shop.selectCity,
      location: {
        type: "Point",
        coordinates: [parseFloat(shop.lng), parseFloat(shop.lat)],
      },
    });

    await newVehicle.save();
    return res
      .status(200)
      .json({ message: "Vehicle added successfully!", newVehicle });
  } catch (error) {
    console.error("Error in addVehicleByShopId:", error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get nearby vehicles
export const getNearbyVehicles = async (req, res) => {
  try {
    const { lat, lng, maxDistance, vehicleCity, vehicleType, startDate, endDate } = req.query;
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    const maxDist = parseInt(maxDistance, 10) || 300;

    // Validate latitude and longitude
    if ((lat && isNaN(latitude)) || (lng && isNaN(longitude))) {
      return res.status(400).json({ error: 'Invalid latitude or longitude provided.' });
    }

    // Validate dates if provided
    let newStartDate, newEndDate;
    if (startDate && endDate) {
      newStartDate = new Date(startDate);
      newEndDate = new Date(endDate);
      if (isNaN(newStartDate) || isNaN(newEndDate) || newEndDate < newStartDate) {
        return res.status(400).json({ error: 'Invalid startDate or endDate provided.' });
      }
    }

    const query = {};

    // Filter by vehicle type
    if (vehicleType) {
      query.vehicleType = vehicleType;
    }

    // Filter by active shops
    const activeShops = await Shop.find({
      ownerActivation: true,
      adminActivation: true,
    }).select('_id');
    const activeShopIds = activeShops.map((shop) => shop._id);
    query.shop = { $in: activeShopIds };

    // Filter by availability if dates are provided
    if (startDate && endDate) {
      query.bookedDates = {
        $not: {
          $elemMatch: {
            startDate: { $lte: newEndDate },
            endDate: { $gte: newStartDate },
          },
        },
      };
    }

    let vehicles = [];
    if (lat && lng) {
      const userLocation = [longitude, latitude];
      query.location = {
        $near: {
          $geometry: { type: 'Point', coordinates: userLocation },
          $maxDistance: maxDist,
        },
      };
      vehicles = await Vehicle.find(query).populate('shop', '-password');
      vehicles = vehicles.map((vehicle) => {
        const vehicleLocation = vehicle.location.coordinates;
        const distance = haversineDistance(userLocation, vehicleLocation);
        return {
          ...vehicle.toObject(),
          distance: `${distance.toFixed(1)} km`,
        };
      });
    } else if (vehicleCity) {
      query.vehicleCity = vehicleCity;
      vehicles = await Vehicle.find(query).populate('shop', '-password');
    } else {
      return res.status(400).json({ error: 'Either lat/lng or vehicleCity is required.' });
    }

    if (!vehicles || vehicles.length === 0) {
      return res.status(404).json({ error: 'No vehicles found for the selected criteria.' });
    }

    return res.status(200).json({ vehicles });
  } catch (error) {
    console.error('Error in getNearbyVehicles:', error);
    return res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
};

// Get vehicles
export const getVehicles = async (req, res) => {
  try {
    const { search = "", vehicalType } = req.query;
    const filter = {};

    if (vehicalType) {
      filter.vehicleType = vehicalType;
    }

    if (req.role === 14) {
      filter.shop = req.userId;
    }

    const searchRegex = new RegExp(search, "i");
    const query = {
      $and: [
        filter,
        {
          $or: [
            { vehicleName: searchRegex },
            { vehicleNumber: searchRegex },
            { vehicleModel: searchRegex },
          ],
        },
      ],
    };

    const vehicles = await Vehicle.find(query).populate("shop", "-password");
    if (!vehicles || vehicles.length === 0) {
      return res.status(400).json({ error: "No Vehicle found!!." });
    }

    return res.status(200).json({ vehicles });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get vehicle by ID
export const getVehicleById = async (req, res) => {
  try {
    const { id } = req.params;
    const vehicle = await Vehicle.findById(id)
      .populate("shop", "-password")
      .populate({
        path: "reviews.user",
        select: "userName",
      });

    if (!vehicle) {
      return res.status(404).json({ error: "Vehicle not found." });
    }

    return res.status(200).json({ vehicle });
  } catch (error) {
    console.error(error.message);
    if (error.kind === "ObjectId") {
      return res.status(400).json({ error: "Invalid vehicle ID." });
    }
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Update vehicle availability
export const updateVehicleAvailability = async (req, res) => {
  try {
    const { id } = req.params;
    const { vehicleAvailability } = req.body;

    const updateAvailability = await Vehicle.findByIdAndUpdate(
      id,
      { vehicleAvailability },
      { new: true, runValidators: true }
    );

    if (!updateAvailability) {
      return res.status(400).json({ error: "Vehicle not found!!." });
    }

    return res
      .status(200)
      .json({ message: "Vehicle availability updated successfully!!." });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Add or update review
export const addReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const { vehicleId } = req.params;

    const review = {
      user: req.user._id,
      rating: Number(rating),
      comment,
    };

    const vehicle = await Vehicle.findById(vehicleId);
    if (!vehicle) {
      return res.status(404).json({ message: "Vehicle not found" });
    }

    const isReviewed = vehicle.reviews.find(
      (rev) => rev.user.toString() === req.user._id.toString()
    );

    if (isReviewed) {
      vehicle.reviews.forEach((rev) => {
        if (rev.user.toString() === req.user._id.toString()) {
          rev.rating = rating;
          rev.comment = comment;
        }
      });
    } else {
      vehicle.reviews.push(review);
      vehicle.numOfReviews = vehicle.reviews.length;
    }

    let avg = 0;
    vehicle.reviews.forEach((rev) => {
      avg += rev.rating;
    });
    vehicle.vehicleRatings = avg / vehicle.reviews.length;

    await vehicle.save();
    const updatedVehicle = await Vehicle.findById(vehicleId).populate({
      path: "reviews.user",
      select: "name email",
    });

    return res.status(200).json({
      message: "Review added/updated successfully!",
      updatedVehicle,
    });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get vehicle rating distribution
export const getVehicleRating = async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const vehicle = await Vehicle.findById(vehicleId);

    if (!vehicle) {
      return res.status(404).json({ message: "Vehicle not found" });
    }

    const totalReviews = vehicle.reviews.length;
    if (totalReviews === 0) {
      return res.status(200).json({
        message: "No reviews yet",
        ratingDistribution: {
          oneStar: { count: 0, percentage: 0 },
          twoStar: { count: 0, percentage: 0 },
          threeStar: { count: 0, percentage: 0 },
          fourStar: { count: 0, percentage: 0 },
          fiveStar: { count: 0, percentage: 0 },
        },
      });
    }

    let oneStarCount = 0,
      twoStarCount = 0,
      threeStarCount = 0,
      fourStarCount = 0,
      fiveStarCount = 0;

    vehicle.reviews.forEach((review) => {
      switch (review.rating) {
        case 1:
          oneStarCount++;
          break;
        case 2:
          twoStarCount++;
          break;
        case 3:
          threeStarCount++;
          break;
        case 4:
          fourStarCount++;
          break;
        case 5:
          fiveStarCount++;
          break;
      }
    });

    const oneStarPercentage = (oneStarCount / totalReviews) * 100;
    const twoStarPercentage = (twoStarCount / totalReviews) * 100;
    const threeStarPercentage = (threeStarCount / totalReviews) * 100;
    const fourStarPercentage = (fourStarCount / totalReviews) * 100;
    const fiveStarPercentage = (fiveStarCount / totalReviews) * 100;

    return res.status(200).json({
      vehicleId,
      totalReviews,
      ratingDistribution: {
        oneStar: { count: oneStarCount, percentage: oneStarPercentage },
        twoStar: { count: twoStarCount, percentage: twoStarPercentage },
        threeStar: { count: threeStarCount, percentage: threeStarPercentage },
        fourStar: { count: fourStarCount, percentage: fourStarPercentage },
        fiveStar: { count: fiveStarCount, percentage: fiveStarPercentage },
      },
    });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Delete review
export const deleteReview = async (req, res) => {
  try {
    const { vehicleId, reviewId } = req.params;
    const vehicle = await Vehicle.findById(vehicleId);

    if (!vehicle) {
      return res.status(404).json({ message: "Vehicle not found" });
    }

    const reviews = vehicle.reviews.filter(
      (rev) => rev._id.toString() !== reviewId.toString()
    );

    let avg = 0;
    reviews.forEach((rev) => {
      avg += rev.rating;
    });

    const vehicleRatings = reviews.length === 0 ? 0 : avg / reviews.length;
    const numOfReviews = reviews.length;

    await Vehicle.findByIdAndUpdate(
      vehicleId,
      { reviews, vehicleRatings, numOfReviews },
      { new: true, runValidators: true }
    );

    return res.status(200).json({
      success: true,
      message: "Review deleted successfully.",
    });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Check vehicle availability
export const checkAvailability = async (vehicleId, startDate, endDate) => {
  const vehicle = await Vehicle.findById(vehicleId);
  const newStartDate = new Date(startDate);
  newStartDate.setHours(0, 0, 0, 0);
  const newEndDate = new Date(endDate);
  newEndDate.setHours(23, 59, 59, 999);

  const isAvailable = vehicle.bookedDates.every((booking) => {
    const bookingStartDate = new Date(booking.startDate);
    const bookingEndDate = new Date(booking.endDate);
    return newEndDate < bookingStartDate || newStartDate > bookingEndDate;
  });
  return isAvailable;
};

// Get vehicles by shop ID
export const getVehiclesByShopId = async (req, res) => {
  try {
    const { shopId } = req.params;
    const { search = "", vehicleType, page = 1, limit = 10 } = req.query;

    if (!mongoose.Types.ObjectId.isValid(shopId)) {
      return res.status(400).json({ error: "Invalid shop ID." });
    }

    const pageNumber = parseInt(page, 10);
    const pageSize = parseInt(limit, 10);
    const skip = (pageNumber - 1) * pageSize;

    const shop = await Shop.findById(shopId).select(
      "ownerName ownerEmail shopName account_number ifsc account_holder_name account_verified shop_OpeningTime shop TrustsTime"
    );

    if (!shop) {
      return res.status(404).json({ error: "Shop not found." });
    }

    const query = { shop: shopId };
    if (search) {
      query.$or = [
        { vehicleName: { $regex: search, $options: "i" } },
        { vehicleNumber: { $regex: search, $options: "i" } },
      ];
    }

    if (vehicleType) {
      query.vehicleType = vehicleType;
    }

    const vehicles = await Vehicle.find(query).skip(skip).limit(pageSize);
    const totalVehicles = await Vehicle.countDocuments(query);

    if (vehicles.length === 0) {
      return res
        .status(404)
        .json({ error: "No vehicles found for this shop." });
    }

    return res.json({
      totalVehicles,
      currentPage: pageNumber,
      totalPages: Math.ceil(totalVehicles / pageSize),
      vehicles,
      shop: {
        _id: shop._id,
        ownerName: shop.ownerName,
        ownerEmail: shop.ownerEmail,
        shopName: shop.shopName,
        account_number: shop.account_number,
        ifsc: shop.ifsc,
        account_holder_name: shop.account_holder_name,
        account_verified: shop.account_verified,
        shop_OpeningTime: shop.shop_OpeningTime,
        shop_ClosedTime: shop.shop_ClosedTime,
      },
    });
  } catch (error) {
    console.error("Error:", error.message);
    return res.status(500).json({ error: "Internal Server Error." });
  }
};

// Delete vehicle
export const deleteVehicle = async (req, res) => {
  try {
    const { id } = req.params;
    const vehicle = await Vehicle.findById(id);

    if (!vehicle) {
      return res.status(404).json({ error: "Vehicle not found." });
    }

    if (req.role === 14 && vehicle.shop.toString() !== req.userId) {
      return res
        .status(403)
        .json({ error: "You are not authorized to delete this vehicle." });
    }

    await Vehicle.findByIdAndDelete(id);
    return res.status(200).json({ message: "Vehicle deleted successfully." });
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
