import crypto from "crypto";
import { Order } from "../models/Order.js";

// You don't need RAZORPAY_KEY_ID in this function
const RAZORPAY_SECRET = process.env.RAZORPAY_SECRET;

export const verifyPayment = async (req, res) => {
  const {
    razorpay_payment_link_id,
    razorpay_payment_id,
    razorpay_signature,
    razorpay_payment_link_reference_id,
    razorpay_payment_link_status,
  } = req.body;

  // Validate that all required fields are present
  if (
    !razorpay_payment_link_id ||
    !razorpay_payment_id ||
    !razorpay_signature ||
    !razorpay_payment_link_reference_id ||
    !razorpay_payment_link_status
  ) {
    console.error("Verification Error: Missing payment details.");
    return res.status(400).json({ error: "Missing payment details" });
  }

  // =================================================================
  // ▼▼▼ THIS IS THE CORRECTED LINE ▼▼▼
  // =================================================================
  const stringToSign = `${razorpay_payment_link_id}|${razorpay_payment_link_reference_id}|${razorpay_payment_link_status}|${razorpay_payment_id}`;
  // =================================================================

  // Create the expected signature
  const expectedSignature = crypto
    .createHmac("sha256", RAZORPAY_SECRET)
    .update(stringToSign)
    .digest("hex");

  if (expectedSignature !== razorpay_signature) {
    console.error("SIGNATURE MISMATCH!");
    return res
      .status(400)
      .json({ error: "Payment verification failed (signature mismatch)" });
  }

  // --- Signature is valid, proceed with updating the database ---
  try {
    const order = await Order.findOne({
      reference_id: razorpay_payment_link_reference_id,
    });
    if (!order) {
      console.error(
        "Order not found for reference_id:",
        razorpay_payment_link_reference_id
      );
      return res.status(404).json({ error: "Order not found" });
    }

    if (order.status === "completed") {
      return res.status(200).json({ message: "Order already completed" });
    }

    if (razorpay_payment_link_status !== "paid") {
      order.status = "failed";
      await order.save();
      return res.status(400).json({ error: "Payment was not successful." });
    }

    // Update order as completed
    order.status = "completed";
    order.razorpay_payment_id = razorpay_payment_id;
    order.razorpay_signature = razorpay_signature;
    order.rideConfirmed = true;
    await order.save();

    console.log("--- Payment Verification Successful ---");
    return res
      .status(200)
      .json({ message: "Payment verified and order completed" });
  } catch (dbError) {
    console.error("Database Error during verification:", dbError);
    // Even if signature was valid, if DB fails, report an internal error
    return res
      .status(500)
      .json({ error: "Internal Server Error during order update" });
  }
};
