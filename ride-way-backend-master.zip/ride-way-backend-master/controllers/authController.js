// authController.js (Cleaned & Fixed)
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cloudinary from "cloudinary";

import { Employee } from "../models/Employee.js";
import { Shop } from "../models/Shop.js";
import { User } from "../models/User.js";
import { Host } from "../models/Host.js";
import { OtpToken } from "../models/OtpToken.js";
import { createOtp, verifyOtp } from "../utils/otp.js";
import { sendOtpEmail } from "../utils/sendOtpEmail.js";

export async function signUpInitiate(req, res) {
  try {
    const { userName, userEmail, userPhoneNumber, gender } = req.body;
    for (const [k, v] of Object.entries({
      userName,
      userEmail,
      userPhoneNumber,
      gender,
    }))
      if (!v) return res.status(400).json({ error: `${k} is required` });

    const taken = await User.findOne({
      isVerified: true,
      $or: [{ userEmail }, { userPhoneNumber }],
    });
    if (taken)
      return res.status(400).json({ error: "Email or phone already in use." });

    const code = await createOtp({ phone: userPhoneNumber, purpose: "signup" });
    await sendOtpEmail(userEmail, code);

    await OtpToken.findOneAndUpdate(
      { phone: userPhoneNumber, purpose: "signup" },
      { $set: { note: { userName, userEmail, userPhoneNumber, gender } } },
      { upsert: true }
    );

    return res.status(200).json({ message: "OTP sent." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error." });
  }
}

export async function signUpVerify(req, res) {
  try {
    const { userPhoneNumber, otp, password } = req.body;
    if (!userPhoneNumber || !otp)
      return res.status(400).json({ error: "Phone and OTP required." });

    const { ok, reason } = await verifyOtp({
      phone: userPhoneNumber,
      purpose: "signup",
      code: otp,
    });
    if (!ok) return res.status(400).json({ error: reason });

    const tokenDoc = await OtpToken.findOne({
      phone: userPhoneNumber,
      purpose: "signup",
    }).lean();
    if (!tokenDoc?.note)
      return res
        .status(400)
        .json({ error: "Registration data lost; restart." });

    const { userName, userEmail, gender } = tokenDoc.note;
    const hashed = password ? await bcrypt.hash(password, 10) : undefined;

    const newUser = await User.create({
      userName,
      userEmail,
      userPhoneNumber,
      gender,
      password: hashed,
      isVerified: true,
    });
    return res.status(201).json({ message: "Account created.", newUser });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error." });
  }
}

export async function signUpHostInitiate(req, res) {
  try {
    const {
      fullName,
      phone,
      email,
      city,
      vehicleType,
      makeModel,
      registrationNumber,
      ownsVehicle,
    } = req.body;

    const { aadhaar, license, rc, insurance, puc } = req.files || {};

    const requiredFields = {
      fullName,
      phone,
      email,
      city,
      vehicleType,
      makeModel,
      registrationNumber,
      ownsVehicle,
    };

    for (const [key, val] of Object.entries(requiredFields)) {
      if (!val) return res.status(400).json({ error: `${key} is required.` });
    }

    const requiredDocs = { aadhaar, license, rc, insurance, puc };
    for (const [key, val] of Object.entries(requiredDocs)) {
      if (!val || !val[0])
        return res
          .status(400)
          .json({ error: `${key.toUpperCase()} document is required.` });
    }

    const existingHost = await Host.findOne({ phone });
    if (existingHost) {
      return res
        .status(400)
        .json({ error: "Phone already registered as host." });
    }

    // Upload all documents to Cloudinary
    const uploadToCloudinary = async (file) =>
      await cloudinary.uploader.upload(file.path);

    const [aadhaarUpload, licenseUpload, rcUpload, insuranceUpload, pucUpload] =
      await Promise.all([
        uploadToCloudinary(aadhaar[0]),
        uploadToCloudinary(license[0]),
        uploadToCloudinary(rc[0]),
        uploadToCloudinary(insurance[0]),
        uploadToCloudinary(puc[0]),
      ]);

    // Save Host directly with approved = false
    const host = await Host.create({
      fullName,
      phone,
      email,
      city,
      vehicleType,
      makeModel,
      registrationNumber,
      ownsVehicle,
      aadhaarUrl: aadhaarUpload.secure_url,
      licenseUrl: licenseUpload.secure_url,
      rcUrl: rcUpload.secure_url,
      insuranceUrl: insuranceUpload.secure_url,
      pucUrl: pucUpload.secure_url,
    });

    return res
      .status(201)
      .json({ message: "Host registered for review", host });
  } catch (err) {
    console.error("Signup error:", err);
    return res.status(500).json({ error: "Server error." });
  }
}

export async function signUpHostVerify(req, res) {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp)
      return res.status(400).json({ error: "Phone and OTP required." });

    const { ok, reason } = await verifyOtp({
      phone: phone,
      purpose: "host-signup",
      code: otp,
    });
    if (!ok) return res.status(400).json({ error: reason });

    const tokenDoc = await OtpToken.findOne({
      phone: phone,
      purpose: "host-signup",
    }).lean();
    if (!tokenDoc?.note)
      return res
        .status(400)
        .json({ error: "Registration data lost; restart." });

    const {
      fullName,
      email,
      city,
      vehicleType,
      makeModel,
      registrationNumber,
      ownsVehicle,
      aadhaarUrl,
      licenseUrl,
    } = tokenDoc.note;

    const newHost = await Host.create({
      fullName,
      phone: phone,
      email,
      city,
      vehicleType,
      makeModel,
      registrationNumber,
      ownsVehicle,
      aadhaarUrl,
      licenseUrl,
      approved: false, // Will be approved manually
    });

    return res
      .status(201)
      .json({ message: "Host registered successfully.", newHost });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error." });
  }
}

export async function loginPhoneRequest(req, res) {
  const { phone, role = "user" } = req.body;

  if (!phone || !role)
    return res.status(400).json({ error: "Phone and role are required." });

  if (!["user", "host", "admin"].includes(role))
    return res.status(400).json({ error: "Invalid role." });

  let account;
  if (role === "host") {
    account = await Host.findOne({ phone, approved: true });
  } else if (role === "admin") {
    account = await Shop.findOne({
      ownerPhoneNumber: phone,
      ownerActivation: true,
      adminActivation: true,
    });
  } else {
    account = await User.findOne({ userPhoneNumber: phone, isVerified: true });
  }

  if (!account) return res.status(404).json(`${role} account not found.`);

  const code = await createOtp({ phone, purpose: "login" });

  if (role == "admin") {
    await sendOtpEmail(account.ownerEmail, code);
  } else {
    await sendOtpEmail(account.userEmail, code);
  }

  return res.status(200).json({ message: "OTP sent." });
}

export async function loginPhoneOrEmailRequest(req, res) {
  const { identifier, role = "user" } = req.body;

  if (!identifier || !role)
    return res.status(400).json({ error: "Identifier and role are required." });

  if (!["user", "host", "admin"].includes(role))
    return res.status(400).json({ error: "Invalid role." });

  const isEmail = identifier.includes("@");
  let account;

  try {
    if (role === "host") {
      account = isEmail
        ? await Host.findOne({ userEmail: identifier, approved: true })
        : await Host.findOne({ phone: identifier, approved: true });
    } else if (role === "admin") {
      account = isEmail
        ? await Shop.findOne({
            ownerEmail: identifier,
            ownerActivation: true,
            adminActivation: true,
          })
        : await Shop.findOne({
            ownerPhoneNumber: identifier,
            ownerActivation: true,
            adminActivation: true,
          });
    } else {
      account = isEmail
        ? await User.findOne({ userEmail: identifier, isVerified: true })
        : await User.findOne({ userPhoneNumber: identifier, isVerified: true });
    }

    if (!account)
      return res.status(404).json({ error: `${role} account not found.` });

    // You may choose to use phone for OTP purpose even if found by email
    const phone = isEmail
      ? role === "admin"
        ? account.ownerPhoneNumber
        : account.phone || account.userPhoneNumber
      : identifier;

    const email = isEmail
      ? identifier
      : role === "admin"
      ? account.ownerEmail
      : account.userEmail;

    const code = await createOtp({ phone, purpose: "login" });
    await sendOtpEmail(email, code);

    return res.status(200).json({ message: "OTP sent." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

/* ───────────────── STEP 2 – Verify OTP ───────────────── */
export async function loginPhoneVerify(req, res) {
  const { phone, otp, role = "user" } = req.body;

  if (!phone || !otp || !role)
    return res
      .status(400)
      .json({ error: "Phone, OTP, and role are required." });

  if (!["user", "host", "admin"].includes(role))
    return res.status(400).json({ error: "Invalid role." });

  const { ok, reason } = await verifyOtp({
    phone,
    purpose: "login",
    code: otp,
  });
  if (!ok) return res.status(400).json({ error: reason });

  let account;
  if (role === "host") {
    account = await Host.findOne({ phone }).select("-password");
  } else if (role === "admin") {
    account = await Shop.findOne({ ownerPhoneNumber: phone }).select(
      "-password"
    );
  } else {
    account = await User.findOne({ userPhoneNumber: phone }).select(
      "-password"
    );
  }

  if (!account) return res.status(404).json({ error: "Account not found." });

  const token = jwt.sign({ id: account._id, role }, process.env.JWT_SECRET, {
    expiresIn: "365d",
  });

  return res.status(200).json({
    message: "Login successful",
    token,
    user: account,
  });
}

export async function loginPhoneOrEmailVerify(req, res) {
  const { identifier, otp, role = "user" } = req.body;

  if (!identifier || !otp || !role)
    return res
      .status(400)
      .json({ error: "Identifier, OTP, and role are required." });

  if (!["user", "host", "admin"].includes(role))
    return res.status(400).json({ error: "Invalid role." });

  const isEmail = identifier.includes("@");
  let account;

  // Determine phone for OTP verification
  try {
    if (role === "host") {
      account = isEmail
        ? await Host.findOne({ userEmail: identifier }).select("-password")
        : await Host.findOne({ phone: identifier }).select("-password");
    } else if (role === "admin") {
      account = isEmail
        ? await Shop.findOne({ ownerEmail: identifier }).select("-password")
        : await Shop.findOne({ ownerPhoneNumber: identifier }).select(
            "-password"
          );
    } else {
      account = isEmail
        ? await User.findOne({ userEmail: identifier }).select("-password")
        : await User.findOne({ userPhoneNumber: identifier }).select(
            "-password"
          );
    }

    if (!account) return res.status(404).json({ error: "Account not found." });

    const phone = isEmail
      ? role === "admin"
        ? account.ownerPhoneNumber
        : account.phone || account.userPhoneNumber
      : identifier;

    const { ok, reason } = await verifyOtp({
      phone,
      purpose: "login",
      code: otp,
    });

    if (!ok) return res.status(400).json({ error: reason });

    const token = jwt.sign({ id: account._id, role }, process.env.JWT_SECRET, {
      expiresIn: "365d",
    });

    return res.status(200).json({
      message: "Login successful",
      token,
      user: account,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

export const forgotPassword = async (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes("@"))
    return res.status(400).json({ error: "Invalid email" });

  try {
    const user =
      (await Employee.findOne({ employeeEmail: email })) ||
      (await Shop.findOne({ ownerEmail: email })) ||
      (await User.findOne({ userEmail: email }));

    if (!user) return res.status(404).json({ error: "User not found" });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "10m",
    });

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    await transporter.sendMail({
      from: `"Kamal Associates" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Reset your password",
      html: `<p>Click to reset: <a href="https://kamalcrm.com/reset-password/${token}">Reset Password</a></p>`,
    });

    res.status(200).json({ message: "Reset link sent to email." });
  } catch (err) {
    console.error("Forgot password error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const resetPassword = async (req, res) => {
  try {
    const decoded = jwt.verify(req.params.token, process.env.JWT_SECRET);

    const user =
      (await Employee.findById(decoded.id)) ||
      (await Shop.findById(decoded.id)) ||
      (await User.findById(decoded.id));

    if (!user)
      return res.status(404).json({ error: "Invalid or expired link" });

    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ error: "Password too short" });

    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    res.status(200).json({ message: "Password reset successfully" });
  } catch (err) {
    console.error("Reset password error:", err);
    res.status(500).json({ error: "Invalid or expired token" });
  }
};

export const firstPasswordChange = async (req, res) => {
  try {
    const { id } = req.params;
    const { password, confirmPassword } = req.body;

    if (password !== confirmPassword)
      return res.status(400).json({ error: "Passwords do not match" });

    const pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!pattern.test(password)) {
      return res.status(400).json({
        error:
          "Password must be at least 8 characters with uppercase, lowercase, and a number.",
      });
    }

    const hashed = await bcrypt.hash(password, 10);
    const updated = await Employee.findByIdAndUpdate(
      id,
      {
        password: hashed,
        requiredPasswordChange: false,
      },
      { new: true }
    );

    if (!updated) return res.status(404).json({ error: "User not found" });
    return res.status(200).json({ message: "Password changed successfully" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
