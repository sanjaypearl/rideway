// controllers/employeeController.js
import bcrypt from "bcryptjs";
import cloudinary from "cloudinary";
import { Employee } from "../models/Employee.js";

/* ───────────── helpers ───────────── */
const uploadToCloudinary = async (file, folder) =>
  cloudinary.v2.uploader.upload(file.path, {
    folder,
    resource_type: file.mimetype.includes("image") ? "image" : "raw",
  });

const emailRegex = /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/;
const isMobileValid = (m) => /^\d{10}$/.test(m);

/* ───────────── controllers ───────────── */

export const addEmployee = async (req, res) => {
  try {
    const {
      employeeName,
      employeeEmail,
      employeeMobileNumber,
      department,
      role,
      employeeSalary,
      fatherOrHusbandName,
      sex,
      maritalStatus,
      bloodGroup,
      presentAddress,
      permanentAddress,
      dateOfBirth,
      dateOfJoining,
    } = req.body;

    /* 1️⃣ required‑field check (excluding files handled below) */
    for (const [k, v] of Object.entries({
      employeeName,
      employeeEmail,
      employeeMobileNumber,
      department,
      role,
      employeeSalary,
    })) {
      if (!v) return res.status(400).json({ error: `${k} is required.` });
    }

    /* 2️⃣ validate formats */
    if (!emailRegex.test(employeeEmail))
      return res.status(400).json({ error: "Invalid email format." });

    if (!isMobileValid(employeeMobileNumber))
      return res.status(400).json({ error: "Invalid mobile number." });

    /* 3️⃣ uniqueness check */
    const dup = await Employee.findOne({
      $or: [{ employeeEmail }, { employeeMobileNumber }],
    });
    if (dup)
      return res
        .status(400)
        .json({ error: "Employee with this email or number already exists." });

    /* 4️⃣ file uploads */
    const uploadMap = {};
    const mapKey = {
      employeePhoto: "photo",
      employeeAdharCard: "aadhar",
      employeePanCard: "pan",
      employeeAgreement: "agreement",
    };

    for (const field of Object.keys(mapKey)) {
      if (req.files?.[field]?.[0]) {
        const r = await uploadToCloudinary(
          req.files[field][0],
          `employees/tmp/${field}`
        );
        uploadMap[field] = { public_id: r.public_id, url: r.secure_url };
      } else {
        return res
          .status(400)
          .json({ error: `${field.replace(/([A-Z])/g, " $1")} is required.` });
      }
    }

    /* 5️⃣ create */
    const hashedPwd = await bcrypt.hash(employeeMobileNumber, 10);
    const employee = await Employee.create({
      ...uploadMap,
      employeeName,
      employeeEmail: employeeEmail.toLowerCase(),
      employeeMobileNumber,
      password: hashedPwd,
      department,
      role,
      employeeSalary,
      fatherOrHusbandName,
      sex,
      maritalStatus,
      bloodGroup,
      presentAddress,
      permanentAddress,
      dateOfBirth,
      dateOfJoining,
    });

    res.status(201).json({ message: "Employee added successfully.", employee });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const getEmployees = async (req, res) => {
  try {
    let { search = "", page = 1, limit = 10, department, role } = req.query;
    page = Number(page);
    limit = Number(limit);
    if (!page || !limit)
      return res
        .status(400)
        .json({ error: "Page and limit must be numbers ≥ 1." });

    const filter = {};
    if (department) filter.department = department;
    if (role) filter.role = role;

    const regex = new RegExp(search, "i");
    const q = { $and: [filter, { $or: [{ employeeName: regex }] }] };

    const [total, employees] = await Promise.all([
      Employee.countDocuments(q),
      Employee.find(q)
        .skip((page - 1) * limit)
        .limit(limit)
        .populate("department", "departmentName")
        .populate("role", "roleName")
        .select("-password"),
    ]);

    if (!employees.length)
      return res.status(404).json({ error: "No employees found." });

    res.json({ employees, totalEmployee: total, totalPages: Math.ceil(total / limit) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const editEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    if (!Object.keys(data).length && !req.files)
      return res.status(400).json({ error: "Nothing to update." });

    if (data.employeeEmail && !emailRegex.test(data.employeeEmail))
      return res.status(400).json({ error: "Invalid email format." });

    if (data.employeeMobileNumber && !isMobileValid(data.employeeMobileNumber))
      return res.status(400).json({ error: "Invalid mobile number." });

    if (data.employeeEmail || data.employeeMobileNumber) {
      const dup = await Employee.findOne({
        _id: { $ne: id },
        $or: [
          { employeeEmail: data.employeeEmail },
          { employeeMobileNumber: data.employeeMobileNumber },
        ],
      });
      if (dup)
        return res
          .status(400)
          .json({ error: "Mobile number or email already in use." });
    }

    const mapKey = {
      employeePhoto: "photo",
      employeeAdharCard: "aadhar",
      employeePanCard: "pan",
      employeeAgreement: "agreement",
    };

    if (req.files) {
      for (const key of Object.keys(mapKey)) {
        if (req.files[key]?.[0]) {
          const r = await uploadToCloudinary(
            req.files[key][0],
            `employees/${id}/${mapKey[key]}`
          );
          data[key] = { public_id: r.public_id, url: r.secure_url };
        }
      }
    }

    const updated = await Employee.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ error: "Employee not found." });

    res.json({ message: "Employee updated successfully.", data: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Employee.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: "Employee not found." });
    res.json({ message: "Employee deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
