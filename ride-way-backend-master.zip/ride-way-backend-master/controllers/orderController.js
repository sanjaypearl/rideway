// controllers/orderController.js
import moment from "moment";
import crypto from "crypto";
import { v4 as uuidv4 } from "uuid";
import cloudinary from "cloudinary";
import razorpayInstance from "../config/razorpay.js";

import { Order } from "../models/Order.js";
import { Vehicle } from "../models/Vehical.js";
import { CoupenCode } from "../models/CoupenCode.js";
import { User } from "../models/User.js";
import { Shop } from "../models/Shop.js";

/* ───────────────────────────── HELPERS ───────────────────────────── */

const checkAvailability = async (vehicleId, startDate, endDate) => {
  const vehicle = await Vehicle.findById(vehicleId);
  if (!vehicle) throw new Error("Vehicle not found");

  const s = moment.utc(startDate);
  const e = moment.utc(endDate);
  if (!s.isValid() || !e.isValid()) throw new Error("Invalid start/end date");

  const conflicts = vehicle.bookedDates.filter(({ startDate, endDate }) => {
    const bs = moment.utc(startDate);
    const be = moment.utc(endDate);
    return bs.isBefore(e) && be.isAfter(s); // overlap
  });

  if (conflicts.length) {
    conflicts.sort((a, b) =>
      moment.utc(a.startDate).diff(moment.utc(b.startDate))
    );
    const latestConflict = moment.utc(conflicts.at(-1).endDate);
    return {
      isAvailable: false,
      availableFrom: latestConflict.format("DD-MM-YYYY, hh:mm A"),
    };
  }

  return { isAvailable: true };
};

const generateOTP = () => crypto.randomInt(1000, 9999).toString();

/* ─────────────────────────── CONTROLLERS ─────────────────────────── */

export const createOrder = async (req, res) => {
  const { vehicleId } = req.params;
  const {
    shopAmount,
    platformAmount = 0,
    miscAmount = 0,
    couponCode,
    startDate,
    endDate,
    startTime,
    endTime,
    discountAmount = 0,
    extraHours = 0,
    extraHourCharge = 0,
    rentDuration,
  } = req.body;

  try {
    // Ensure user is authenticated
    if (!req.userId || !req.user) {
      return res.status(401).json({ error: "User authentication required." });
    }

    // Validate required date/time
    if (!startDate || !startTime || !endDate || !endTime) {
      return res
        .status(400)
        .json({ error: "Pickup and drop-off times are required." });
    }

    const combinedStart = moment.utc(`${startDate}T${startTime}`).toDate();
    const combinedEnd = moment.utc(`${endDate}T${endTime}`).toDate();

    if (isNaN(combinedStart) || isNaN(combinedEnd)) {
      return res.status(400).json({ error: "Invalid date/time format." });
    }

    // Validate vehicle
    const vehicle = await Vehicle.findById(vehicleId);
    if (!vehicle) {
      return res.status(404).json({ error: "Vehicle not found." });
    }

    // Check availability
    const availability = await checkAvailability(
      vehicleId,
      combinedStart,
      combinedEnd
    );
    if (!availability.isAvailable) {
      return res.status(400).json({
        error: `Vehicle not available. Available from ${availability.availableFrom}`,
      });
    }

    // Validate and apply coupon
    let appliedCoupon = null;
    let validatedDiscountAmount = discountAmount;
    if (couponCode) {
      const coupon = await CoupenCode.findOne({ code: couponCode });
      if (!coupon || !coupon.isActive || coupon.expirationDate < new Date()) {
        return res.status(400).json({ error: "Invalid or expired coupon." });
      }
      appliedCoupon = coupon._id;
      if (coupon.discountAmount && discountAmount !== coupon.discountAmount) {
        validatedDiscountAmount = coupon.discountAmount;
      }
    }

    // Validate base amounts
    if (shopAmount <= 0 || shopAmount > 1_000_000) {
      return res.status(400).json({ error: "Invalid shop amount." });
    }

    const totalAmount =
      shopAmount + platformAmount + miscAmount - validatedDiscountAmount;

    if (totalAmount <= 0) {
      return res
        .status(400)
        .json({ error: "Total amount must be greater than 0." });
    }

    const referenceId = uuidv4();

    // Create Razorpay Payment Link
    const paymentLink = await razorpayInstance.paymentLink.create({
      amount: totalAmount * 100, // Convert to paisa
      currency: "INR",
      accept_partial: false,
      description: `Booking: ${vehicle.vehicleName}`,
      customer: {
        name: req.user.userName || "Customer",
        email: req.user.userEmail || "test@example.com",
        contact: req.user.userPhoneNumber?.toString() || "9999999999",
      },
      reminder_enable: true,
      reference_id: referenceId,
      callback_url: `${process.env.CLIENT_URL}/payment/result?reference_id=${referenceId}`,
      callback_method: "get",
    });

    // Create order in DB with status pending
    const order = await Order.create({
      user: req.userId,
      vehicle: vehicle._id,
      shopAmount,
      platformAmount,
      miscAmount,
      discountAmount: validatedDiscountAmount,
      totalAmount,
      startDate: combinedStart,
      endDate: combinedEnd,
      razorpay_payment_link_id: paymentLink.id,
      reference_id: referenceId,
      coupon: appliedCoupon,
      extraHours,
      extraHourCharge,
      rentDuration,
      conformationOtp: generateOTP(),
      status: "pending",
    });

    return res.status(201).json({
      success: true,
      order,
      paymentLink: paymentLink.short_url,
      reference_id: referenceId,
    });
  } catch (err) {
    console.error("Order creation error:", err);
    return res.status(err?.statusCode || 500).json({
      error: "Failed to create order.",
      details: err.message || "Unknown error",
    });
  }
};

export const getOrderStatus = async (req, res) => {
  const { reference_id } = req.params;

  if (!reference_id) {
    return res.status(400).json({
      success: false,
      message: "Reference ID is required.",
    });
  }

  try {
    // Find the order by reference_id and populate user and vehicle
    const order = await Order.findOne({ reference_id }).populate(
      "user vehicle"
    );
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found for the given reference ID.",
      });
    }

    // Return the order status and details
    return res.status(200).json({
      success: true,
      message: "Order status retrieved successfully.",
      orderStatus: order.status,
      paymentLinkStatus: order.status, // Map order.status to paymentLinkStatus for frontend compatibility
      razorpay_payment_id: order.razorpay_payment_id || null,
      order,
    });
  } catch (error) {
    console.error("Error fetching order status:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch order status due to an internal error.",
      error: error?.message || "Unknown error",
    });
  }
};

export const uploadAadharCard = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: "User not found." });

    if (!req.files?.adharcardImg)
      return res.status(400).json({ error: "Aadhaar card image is required." });

    const uploads = req.files.adharcardImg.map(async (file) => {
      const res = await cloudinary.v2.uploader.upload(file.path);
      return { public_id: res.public_id, url: res.secure_url };
    });

    user.adharcardImg = await Promise.all(uploads);
    await user.save();

    res.json({
      success: true,
      message: "Aadhaar card images uploaded.",
      adharcardImg: user.adharcardImg,
    });
  } catch (err) {
    console.error("Aadhaar upload error:", err);
    res.status(500).json({ error: err.message });
  }
};

export const confirmOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { otp } = req.body;
    if (!otp) return res.status(400).json({ error: "OTP is required." });

    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ error: "Order not found." });

    if (order.conformationOtp !== Number(otp))
      return res.status(400).json({ error: "Invalid OTP." });

    order.rideConfirmed = true;
    await order.save();
    res.json({ message: "Order confirmed. OTP verified." });
  } catch (err) {
    console.error("OTP confirmation error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export const cancelOrder = async (req, res) => {
  const { orderId } = req.params;
  try {
    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ message: "Order not found." });

    /* cancellation window: within 1 h of pickup */
    const diffHours = (Date.now() - new Date(order.startDate).getTime()) / 36e5;
    if (diffHours > 1)
      return res
        .status(400)
        .json({ error: "Cancellation not eligible for refund." });

    const refundAmount = order.shopAmount * 0.5;

    const refund = await razorpayInstance.payments.refund(
      order.razorpay_payment_id,
      { amount: Math.round(refundAmount * 100) }
    );

    Object.assign(order, {
      cancellationRefundId: refund.id,
      cancellationRefundAmount: refundAmount,
      cancellationRefundStatus: refund.status,
      cancellationInitiatedAt: new Date(),
      cancellationArn: refund.acquirer_data?.arn || null,
      status: "cancelled",
    });
    await order.save();

    res.json({ message: "Refund initiated.", refundDetails: refund });
  } catch (err) {
    console.error(err);
    res
      .status(500)
      .json({ message: "Internal Server Error", error: err.message });
  }
};

export const getOrders = async (req, res) => {
  const {
    status,
    settled,
    startDate,
    endDate,
    limit = 10,
    page = 1,
  } = req.query;
  const userId = req.userId;
  const role = req.role;

  try {
    let q = {};

    if (role === "admin") {
      // admin → all
    } else if (role === "host") {
      const vehicles = await Vehicle.find({ shop: userId }).select("_id");
      q.vehicle = { $in: vehicles.map((v) => v._id) };
    } else if (role === "user") {
      q.user = userId;
    } else {
      return res.status(403).json({ error: "Unauthorized" });
    }

    if (status) q.status = status;
    if (settled !== undefined) q.settled = settled === "true";
    if (startDate && endDate)
      q.createdAt = { $gte: new Date(startDate), $lte: new Date(endDate) };

    const orders = await Order.find(q)
      .populate("user", "userName userEmail")
      .populate(
        "vehicle",
        "vehicleNumber vehicleName vehicleImage vehiclePrice vehicleRatings location"
      )
      .populate("coupon", "code discountAmount")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(+limit);

    if (!orders.length)
      return res.status(404).json({ error: "No orders found." });

    /* stats */
    const [total, completed, pending, failed, cancelled] = await Promise.all([
      Order.countDocuments(q),
      Order.countDocuments({ ...q, status: "completed" }),
      Order.countDocuments({ ...q, status: "pending" }),
      Order.countDocuments({ ...q, status: "failed" }),
      Order.countDocuments({ ...q, status: "cancelled" }),
    ]);

    res.json({
      success: true,
      stats: {
        totalOrders: total,
        totalCompleted: completed,
        totalPending: pending,
        totalFailed: failed,
        totalCancelled: cancelled,
      },
      orders,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

export const getOrderById = async (req, res) => {
  const { id: orderId } = req.params;
  const userId = req.userId;
  const role = req.role;

  try {
    let order;

    if (role === 2) {
      order = await Order.findById(orderId).populate("user vehicle coupon");
    } else if (role === 14) {
      const vehicles = await Vehicle.find({ shop: userId }).select("_id");
      order = await Order.findOne({
        _id: orderId,
        vehicle: { $in: vehicles },
      }).populate("user vehicle coupon");
    } else if (role === 15) {
      order = await Order.findOne({ _id: orderId, user: userId }).populate(
        "user vehicle coupon"
      );
    }

    if (!order) return res.status(404).json({ message: "Order not found." });
    res.json({ success: true, order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

export const getOrdersByShop = async (req, res) => {
  const { shopId } = req.params;
  const {
    status,
    settled,
    startDate,
    endDate,
    limit = 10,
    page = 1,
  } = req.query;

  try {
    const shop = await Shop.findById(shopId).select(
      "ownerName ownerEmail shopName account_number ifsc account_holder_name account_verified"
    );
    if (!shop) return res.status(404).json({ error: "Shop not found." });

    const vehicles = await Vehicle.find({ shop: shopId }).select("_id");
    const vIds = vehicles.map((v) => v._id);

    let q = { vehicle: { $in: vIds } };
    if (status) q.status = status;
    if (settled !== undefined) q.settled = settled === "true";
    if (startDate && endDate)
      q.createdAt = { $gte: new Date(startDate), $lte: new Date(endDate) };

    const orders = await Order.find(q)
      .populate("user", "userName userEmail")
      .populate(
        "vehicle",
        "vehicleNumber vehicleName vehicleImage vehiclePrice"
      )
      .populate("coupon", "code discountAmount")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(+limit);

    const [total, completed, pending, failed, cancelled] = await Promise.all([
      Order.countDocuments({ vehicle: { $in: vIds } }),
      Order.countDocuments({ vehicle: { $in: vIds }, status: "completed" }),
      Order.countDocuments({ vehicle: { $in: vIds }, status: "pending" }),
      Order.countDocuments({ vehicle: { $in: vIds }, status: "failed" }),
      Order.countDocuments({ vehicle: { $in: vIds }, status: "cancelled" }),
    ]);

    res.json({
      shop,
      orders,
      stats: {
        totalOrders: total,
        totalCompleted: completed,
        totalPending: pending,
        totalFailed: failed,
        totalCancelled: cancelled,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
