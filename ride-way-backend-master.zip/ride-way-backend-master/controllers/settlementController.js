// controllers/settlementController.js
import { Order } from "../models/Order.js";
import cloudinary from "cloudinary";

// Cloudinary config is assumed to be done globally via env or server entry
export const settleOrder = async (req, res) => {
  try {
    const { orderId } = req.params;
    const {
      settlementDate,
      settlementAmount,
      settlementTransactionId,
      settlementPlatformUsed,
    } = req.body;

    // Upload settlement proof to Cloudinary if provided
    let settlementProofImage;
    if (req.files?.settlementProofImage?.[0]) {
      const photo = req.files.settlementProofImage[0];
      const result = await cloudinary.v2.uploader.upload(photo.path);
      settlementProofImage = {
        public_id: result.public_id,
        url: result.secure_url || result.url,
      };
    }

    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      {
        settled: true,
        settlementDate,
        settlementAmount,
        settlementTransactionId,
        settlementPlatformUsed,
        settlementProofImage,
      },
      { new: true }
    );

    if (!updatedOrder)
      return res.status(404).json({ error: "Order not found" });

    res
      .status(200)
      .json({ message: "Amount settled for this order", order: updatedOrder });
  } catch (err) {
    console.error("Settlement Error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
