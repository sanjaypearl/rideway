// controllers/userController.js
import bcrypt from "bcryptjs";
import { User } from "../models/User.js";
import { Employee } from "../models/Employee.js";
import { Shop } from "../models/Shop.js";

/* ─────────────────────────── HELPERS ────────────────────────── */
const validateEmail = (email = "") =>
  /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email);

export async function signUp(req, res) {
  try {
    const { userName, userEmail, userPhoneNumber, password } = req.body;

    // 1️⃣ Required‐field check
    for (const [k, v] of Object.entries({
      userName,
      userEmail,
      userPhoneNumber,
      password,
    })) {
      if (!v) {
        return res
          .status(400)
          .json({ error: `${k.replace(/([A-Z])/g, " $1")} required.` });
      }
    }

    // 2️⃣ Format & strength checks
    if (!validateEmail(userEmail))
      return res.status(400).json({ error: "Invalid email format." });

    if (userPhoneNumber.length !== 10)
      return res.status(400).json({ error: "Invalid mobile number." });

    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/.test(password))
      return res.status(400).json({
        error:
          "Password must have ≥ 8 chars, incl. at least 1 upper‑case, 1 lower‑case and 1 digit.",
      });

    // 3️⃣ Duplicate check
    const existing = await User.findOne({
      $or: [{ userEmail }, { userPhoneNumber }],
    });
    if (existing)
      return res
        .status(400)
        .json({ error: "User with email or phone already exists." });

    // 4️⃣ Persist
    const hashed = await bcrypt.hash(password, await bcrypt.genSalt(10));
    const newUser = await User.create({
      userName,
      userEmail,
      userPhoneNumber,
      password: hashed,
    });

    return res.status(201).json({ message: "Sign‑up successful.", newUser });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

export async function getUsers(req, res) {
  try {
    let { search = "", page = 1, limit = 10 } = req.query;
    page = Number(page);
    limit = Number(limit);

    if (!page || !limit || page < 1 || limit < 1)
      return res
        .status(400)
        .json({ error: "Page and limit must be numbers ≥ 1." });

    const regex = new RegExp(search, "i");
    const filter = { $or: [{ userName: regex }] };

    const [total, users] = await Promise.all([
      User.countDocuments(filter),
      User.find(filter)
        .skip((page - 1) * limit)
        .limit(limit)
        .select("-password"),
    ]);

    if (users.length === 0)
      return res.status(404).json({ error: "No users found." });

    return res.status(200).json({ users, total });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

export async function getUserById(req, res) {
  try {
    const { id } = req.params;

    const shop = await Shop.findById(id).select("-password");
    if (shop) return res.json({ userType: "Shop", user: shop });

    const user = await User.findById(id).select("-password");
    if (user) return res.json({ userType: "User", user });

    return res.status(404).json({ error: "User not found." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

export async function editUser(req, res) {
  try {
    const { id } = req.params;
    const data = req.body;

    if (data.userEmail || data.userPhoneNumber) {
      const duplicate = await User.findOne({
        _id: { $ne: id },
        $or: [{ userEmail: data.userEmail }, { userPhoneNumber: data.userPhoneNumber }],
      });
      if (duplicate)
        return res
          .status(400)
          .json({ error: "Phone or email already in use by another user." });
    }

    const updated = await User.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });

    if (!updated) return res.status(404).json({ error: "User not found." });
    return res.json({ message: "User updated successfully.", updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}

export async function deleteUser(req, res) {
  try {
    const { id } = req.params;
    const deleted = await User.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: "User not found." });
    return res.json({ message: "User deleted successfully." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error." });
  }
}
