// controllers/couponController.js
import { CoupenCode } from '../models/CoupenCode.js';

export const createCoupon = async (req, res) => {
  try {
    const { code, discountType, discountValue, expirationDate } = req.body;

    const existing = await CoupenCode.findOne({ code });
    if (existing) {
      return res.status(400).json({ error: 'Coupon code already exists' });
    }

    const coupon = new CoupenCode({
      code,
      discountType,
      discountValue,
      expirationDate
    });

    await coupon.save();
    res.status(201).json({ message: 'Coupon created successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

export const validateCoupon = async (req, res) => {
  const { code } = req.body;

  try {
    const coupon = await CoupenCode.findOne({ code });
    if (!coupon) return res.status(404).json({ error: 'Coupon not found' });

    if (!coupon.isActive) return res.status(400).json({ error: 'Coupon is inactive' });

    if (new Date(coupon.expirationDate) < new Date()) {
      return res.status(400).json({ error: 'Coupon has expired' });
    }

    res.status(200).json({ message: 'Coupon is valid', coupon });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to validate coupon' });
  }
};

export const deactivateCoupon = async (req, res) => {
  const { coupenId } = req.params;

  try {
    const coupon = await CoupenCode.findByIdAndUpdate(
      coupenId,
      { isActive: false },
      { new: true }
    );
    if (!coupon) return res.status(404).json({ error: 'Coupon not found' });

    res.status(200).json({ message: 'Coupon deactivated successfully', coupon });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to deactivate coupon' });
  }
};

export const deleteCoupon = async (req, res) => {
  const { coupenId } = req.params;

  try {
    const coupon = await CoupenCode.findByIdAndDelete(coupenId);
    if (!coupon) return res.status(404).json({ error: 'Coupon not found' });

    res.status(200).json({ message: 'Coupon deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to delete coupon' });
  }
};

export const getAllCoupons = async (req, res) => {
  try {
    const coupons = await CoupenCode.find();
    res.status(200).json(coupons);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch coupons' });
  }
};
