// controllers/roleController.js
import { Role } from "../models/Role.js";

// Add new role
export const addRole = async (req, res) => {
  try {
    const { roleName, roleCode, departmentName } = req.body;

    const existingRole = await Role.findOne({ roleName });
    const existingRoleCode = await Role.findOne({ roleCode });

    if (existingRole) {
      return res.status(400).json({ error: "Role already exists!!." });
    }
    if (existingRoleCode) {
      return res.status(400).json({ error: "Role Code already exists!!." });
    }

    const newRole = new Role({ roleName, roleCode, departmentName });
    await newRole.save();

    return res.status(200).json({ message: "Role Added Successfully!!." });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get all roles
export const getRoles = async (req, res) => {
  try {
    const roles = await Role.find({}).populate("departmentName");

    if (!roles || roles.length === 0) {
      return res.status(404).json({ error: "Roles Not Exist!!." });
    }

    return res.status(200).json({ roles });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Delete role
export const deleteRole = async (req, res) => {
  try {
    const { id } = req.query;

    const role = await Role.findByIdAndDelete(id);
    if (!role) {
      return res.status(404).json({ error: "Role not found!!." });
    }

    return res.status(200).json({ message: "Role deleted successfully!!." });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

// Edit role
export const editRole = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    const existing = await Role.findOne({
      roleName: updatedData.roleName,
      _id: { $ne: id }, // exclude current role
    });

    if (existing) {
      return res
        .status(400)
        .json({ error: "Role with this name already exists!" });
    }

    const updatedRole = await Role.findByIdAndUpdate(id, updatedData, {
      new: true,
      runValidators: true,
    });

    if (!updatedRole) {
      return res.status(404).json({ error: "Role not found!" });
    }

    return res
      .status(200)
      .json({ message: "Role info updated successfully", updatedRole });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
