import nodemailer from "nodemailer";

// Send OTP Email Utility
export const sendOtpEmail = async ( to, otp ) => {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER, // Your Gmail address
        pass: process.env.EMAIL_PASS, // Gmail App Password
      },
    });

    const mailOptions = {
      from: `"RideAway" <${process.env.EMAIL_USER}>`,
      to,
      subject: "Your OTP Code",
      html: `
        <div style="font-family: Arial, sans-serif; padding: 10px;">
          <h2>🔐 OTP Verification</h2>
          <p>Your OTP code is:</p>
          <div style="font-size: 24px; font-weight: bold; background: #f0f0f0; display: inline-block; padding: 10px 20px; border-radius: 6px; margin: 10px 0;">
            ${otp}
          </div>
          <p>This code is valid for the next 5 minutes. Please do not share it with anyone.</p>
          <br/>
          <p>Thanks,<br/>RideAway</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);
    return { success: true, message: "OTP email sent successfully." };
  } catch (error) {
    console.error("❌ Failed to send OTP email:", error);
    return { success: false, message: "Failed to send OTP email.", error };
  }
};
