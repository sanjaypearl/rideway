// utils/otp.js
import crypto from "crypto";
import { OtpToken } from "../models/OtpToken.js";

/* 1) generate a 6‑digit code, 2) store its hash + expiry */
export async function createOtp({ phone, email, purpose }) {
  const raw  = Math.floor(100000 + Math.random() * 900000).toString(); // "654321"
  const hash = crypto.createHash("sha256").update(raw).digest("hex");

  await OtpToken.findOneAndUpdate(
    { phone, email, purpose },
    { phone, email, purpose, codeHash: hash, expiresAt: Date.now() + 10 * 60 * 1000 },
    { upsert: true, new: true }
  );

  return raw; // the *plaintext* code to send to user
}

export async function verifyOtp({ phone, email, purpose, code }) {
  const token = await OtpToken.findOne({ phone, email, purpose });
  if (!token)        return { ok: false, reason: "Code not found" };
  if (token.expiresAt < Date.now())
    return { ok: false, reason: "Code expired" };

  const hash = crypto.createHash("sha256").update(code).digest("hex");
  if (hash !== token.codeHash) return { ok: false, reason: "Wrong code" };

  // await token.deleteOne();                 // one‑time use
  return { ok: true };
}
