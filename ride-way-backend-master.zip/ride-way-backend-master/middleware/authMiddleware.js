import jwt from "jsonwebtoken";
import "dotenv/config";
import { Shop } from "../models/Shop.js";
import { User } from "../models/User.js";

// Helper: Verify token
const verifyToken = (token) => {
  if (!token) throw new Error("NoToken");
  return jwt.verify(token, process.env.JWT_SECRET);
};

// Core Auth Middleware
const authenticateAllUsers = (allowedRoles = []) => {
  return async (req, res, next) => {
    try {
      const token = req.header("auth-token");
      if (!token)
        return res.status(401).json({ error: "Access denied. No token." });

      const decoded = verifyToken(token);

      const { id, role } = decoded;
  
      let user = null;
      // Load user from corresponding model based on role
      if (role === "admin") {
        user = await Shop.findById(id).select("-password");
      } else if (role === "host") {
        user = await Shop.findById(id).select("-password");
      } else if (role === "user") {
        user = await User.findById(id).select("-password");
      }
 
      if (!user) return res.status(404).json({ error: "User not found." });

      // Check if user's role is allowed
      if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
        return res
          .status(403)
          .json({ error: "Access denied. Insufficient permissions." });
      }

      req.user = user;
      req.userId = id;
      req.role = role;

      next();
    } catch (err) {
      console.error("Auth Error:", err.message);
      if (err.name === "JsonWebTokenError") {
        return res.status(401).json({ error: "Invalid token." });
      }
      return res.status(401).json({ error: "Authentication failed." });
    }
  };
};

export const authenticateUser = authenticateAllUsers(["user"]);
export const authenticateHost = authenticateAllUsers(["host"]);
export const authenticateAdmin = authenticateAllUsers(["admin"]);
export const authenticateLoggedInUser = authenticateAllUsers(); // no role check
export const authenticateAnyRoles = (...roles) => authenticateAllUsers(roles);
