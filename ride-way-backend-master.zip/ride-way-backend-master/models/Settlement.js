import mongoose from "mongoose";


const settlementSchema = new mongoose.Schema({
    shop: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shop",
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    orders: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
    }],
    settlementDate: {
      type: Date,
      default: Date.now,
    },
  });
  
  export const Settlement = mongoose.model("Settlement", settlementSchema);
  