// models/OtpToken.js
import mongoose from "mongoose";

const otpTokenSchema = new mongoose.Schema(
  {
    /* One (and only one) of these two will be filled in: */
    phone: { type: String },
    email: { type: String },
    note: {},
    purpose: { type: String, enum: ["signup", "login"], required: true },
    codeHash: { type: String, required: true }, // sha‑256 of the 6‑digit code
    expiresAt: { type: Date, required: true }, // e.g. now + 10 min
  },
  { timestamps: true }
);

export const OtpToken = mongoose.model("OtpToken", otpTokenSchema);
