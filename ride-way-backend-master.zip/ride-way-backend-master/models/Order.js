import mongoose from "mongoose";

const orderSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    vehicle: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vehicle",
      required: true,
    },
    coupon: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "coupencode", // Add coupon reference
    },
    shopAmount: {
      type: Number,
      required: true,
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    extraHours: {
      type: Number,
      default: 0, // Add extra hours field to track the added hours
    },
    rentDuration: {
      type: String,
      required: true,
    },
    extraHourCharge: {
      type: Number,
      default: 0, // Add extra hour charge field to track the added charge per extra hour
    },
    platformAmount: {
      type: Number,
      required: true,
    },
    miscAmount: {
      type: Number,
      required: true,
    },
    discountAmount: {
      // Add discount amount to track the applied discount
      type: Number,
      default: 0,
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    status: {
      type: String,
      enum: ["pending", "completed", "failed", "cancelled"],
      default: "pending",
    },
    settled: {
      type: Boolean,
      default: false, // Initially set to false, changes to true when settled
    },
    settlementDate: {
      type: Date,
    },
    settlementProofImage: {
      public_id: {
        type: String,
      },
      url: {
        type: String,
      },
    },
    conformationOtp: {
      type: Number,
    },
    rideConfirmed: {
      type: Boolean,
      default: false,
    },
    settlementAmount: {
      type: Number,
      // required: true,
    },
    settlementTransactionId: {
      type: String,
    },
    settlementPlatformUsed: {
      type: String,
    },
    razorpay_order_id: String,
    razorpay_payment_id: String,
    razorpay_signature: String,
    reference_id: { type: String, unique: true }, //
    cancellationRefundId: {
      type: String,
    },
    cancellationRefundAmount: {
      type: Number,
    },
    cancellationRefundStatus: {
      type: String,
    },
    cancellationInitiatedAt: {
      type: Date,
    },
    cancellationArn: {
      type: String, // Acquirer Reference Number for card/bank refunds
    },
  },
  {
    timestamps: true,
  }
);

export const Order = mongoose.model("Order", orderSchema);
