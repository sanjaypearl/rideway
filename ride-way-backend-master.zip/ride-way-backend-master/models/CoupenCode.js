import mongoose from 'mongoose';

const coupenSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        unique: true
    },
    discountType: {
        type: String,
        enum: ['percentage', 'fixed'], // e.g., 'percentage' or 'fixed' discount
        required: true
    },
    discountValue: {
        type: Number,
        required: true
    },
    expirationDate: {
        type: Date,
        required: true
    },
    isActive: {
        type: Boolean,
        default: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date
    }
})

export const CoupenCode = mongoose.model('coupencode', coupenSchema)