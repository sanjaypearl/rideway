import mongoose from 'mongoose';

const deviceTokenSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user",
    },
    shopOwnerId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "shop",
    },
    employeeId:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"employee"
    },
    token: {
        type: String, required: true,
        unique: true
    },
    createdAt: { type: Date, default: Date.now },
});

export const DeviceToken = mongoose.model("DeviceToken", deviceTokenSchema);


