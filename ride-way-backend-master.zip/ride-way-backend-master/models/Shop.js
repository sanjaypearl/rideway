import mongoose from "mongoose";

const shopSchema = new mongoose.Schema({
    shopImage: {
        public_id: {
            type: String,
            required: true,
        },
        url: {
            type: String,
            required: true,
        },
    },
    shopName: {
        type: String,
        required: true
    },
    ownerName: {
        type: String,
        required: true
    },
    ownerEmail: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    ownerPhoneNumber: {
        type: Number,
        required: true,
        unique: true,
        minLength: 10,
        maxLength: 10
    },
    gender: {
        type: String,
        required: true,
        enum: ['male', 'female', 'other']
    },
    selectCity: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'city',
        required: true
    },
    role: {
        type: String,
        required: true,
        default: "admin",
        enum:["admin"]
    },
    lat: {
        type: Number,
        required: true
    },
    lng: {
        type: Number,
        required: true
    },
    shop_OpeningTime: {
        type: String,
        required: true,
    },
    shop_ClosedTime: {
        type: String,
        required: true,
    },
    account_holder_name: {
        type: String,
    },
    ifsc: {
        type: String,
    },
    account_number: {
        type: String,
    },
    account_verified: {
        type: Boolean,
        default: false,
    },
    ownerActivation:{
        type: Boolean,
        default: true,
    },
    adminActivation:{
        type: Boolean,
        default: true,
    }
}, {
    timestamps: true,
})




export const Shop = mongoose.model("shop", shopSchema);