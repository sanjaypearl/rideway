import mongoose from "mongoose";

const hostSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
    },
    city: {
      type: String,
      required: true,
    },
    vehicleType: {
      type: String,
      enum: ["Motorcycle", "Scooter"],
      required: true,
    },
    makeModel: {
      type: String,
      required: true,
    },
    registrationNumber: {
      type: String,
      required: true,
    },
    ownsVehicle: {
      type: Boolean,
      default : false,
      required: true,
    },
    aadhaarUrl: {
      type: String,
      required: true,
    },
    licenseUrl: {
      type: String,
      required: true,
    },
    rcUrl: {
      type: String,
      required: true,
    },
    insuranceUrl: {
      type: String,
      required: true,
    },
    pucUrl: {
      type: String,
      required: true,
    },
    approved: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

export const Host = mongoose.models.Host || mongoose.model("Host", hostSchema);
