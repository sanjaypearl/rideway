import mongoose from "mongoose";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";

// Load environment variables
dotenv.config();

const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/your-db";

// ----- City Model -----
const citySchema = new mongoose.Schema({
  cityName: { type: String, required: true },
  cityState: { type: String, required: true },
  cityImage: {
    public_id: { type: String, required: true },
    url: { type: String, required: true },
  },
  priority: {
    type: String,
    default: "low",
    enum: ["low", "medium", "high"],
  },
}, { timestamps: true });

citySchema.index({ cityName: 1, cityState: 1 }, { unique: true });
const City = mongoose.model("city", citySchema);

// ----- Shop Model -----
const shopSchema = new mongoose.Schema({
  shopImage: {
    public_id: { type: String, required: true },
    url: { type: String, required: true },
  },
  shopName: { type: String, required: true },
  ownerName: { type: String, required: true },
  ownerEmail: { type: String, required: true },
  password: { type: String, required: true },
  ownerPhoneNumber: {
    type: Number,
    required: true,
    unique: true,
    minLength: 10,
    maxLength: 10,
  },
  gender: {
    type: String,
    required: true,
    enum: ["male", "female", "other"],
  },
  selectCity: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "city",
    required: true,
  },
  role: {
    type: String,
    required: true,
    default: "admin",
    enum: ["admin"],
  },
  lat: { type: Number, required: true },
  lng: { type: Number, required: true },
  shop_OpeningTime: { type: String, required: true },
  shop_ClosedTime: { type: String, required: true },
  account_holder_name: { type: String },
  ifsc: { type: String },
  account_number: { type: String },
  account_verified: { type: Boolean, default: false },
  ownerActivation: { type: Boolean, default: true },
  adminActivation: { type: Boolean, default: true },
}, { timestamps: true });

const Shop = mongoose.model("shop", shopSchema);

// ----- Seeding Logic -----
const seedData = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("✅ MongoDB connected");

    // Step 1: Ensure at least one city exists
    let city = await City.findOne();
    if (!city) {
      console.log("🌆 No city found. Creating default city...");
      city = await City.create({
        cityName: "Delhi",
        cityState: "Delhi",
        cityImage: {
          public_id: "city_delhi",
          url: "https://example.com/images/delhi.jpg",
        },
        priority: "high",
      });
    }

    // Step 2: Clear previous shops
    await Shop.deleteMany();

    const hashedPassword = await bcrypt.hash("Test@1234", 10);

    // Step 3: Create shop
    await Shop.create({
      shopImage: {
        public_id: "shop_image_001",
        url: "https://example.com/images/shop.jpg",
      },
      shopName: "Test Shop",
      ownerName: "John Doe",
      ownerEmail: "kartikchauhan@pearlorganisation.com",
      password: hashedPassword,
      ownerPhoneNumber: 9145103053,
      gender: "male",
      selectCity: city._id,
      role: "admin",
      lat: 28.6139,
      lng: 77.2090,
      shop_OpeningTime: "09:00",
      shop_ClosedTime: "21:00",
      account_holder_name: "John Doe",
      ifsc: "TEST0001234",
      account_number: "1234567890",
      account_verified: true,
      ownerActivation: true,
      adminActivation: true,
    });

    console.log("✅ Shop seeded successfully");
    process.exit();
  } catch (error) {
    console.error("❌ Seeding failed:", error.message);
    process.exit(1);
  }
};

seedData();
