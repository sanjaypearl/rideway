import admin from "firebase-admin";
import { readFile } from "fs/promises";

// Load the Firebase service account key
const serviceAccount = JSON.parse(
  await readFile(new URL("./rideroznotification-firebase-adminsdk-qjvo3-91f873b450.json", import.meta.url))
);

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

/**
 * Function to send a notification
 * @param {string} token - FCM token of the target device
 * @param {object} notification - Notification payload (title & body)
 * @param {object} data - Additional data (optional)
 */
const sendNotification = async (token, notification, data = {}) => {
  try {
    const message = {
      token, // FCM device token
      notification: {
        title: notification.title,
        body: notification.body,
      },
      data, // Custom data (optional)
    };

    const response = await admin.messaging().send(message);
    console.log("Notification sent successfully:", response);
  } catch (error) {
    console.error("Error sending notification:", error);
  }
};

// Test the function
const fcmToken =
  "fFEdm0J6AiUVdQgJG2N23r:APA91bGt1XPOogugGftFSmMVsAOROGmCp2XkW-gIJC6yba9aJnvvW5Ax8KJ1m5-kuQ35N6NUr0rxuURL5uRG3UQjaA4xHd1nzJZnZVOueUhp9INrcS2S2ck"; // Replace with your token
const notificationPayload = {
  title: "Hello from Backend",
  body: "This is a test notification sent via the backend!",
};
const dataPayload = {
  key1: "value1",
  key2: "value2",
};

// Send the notification
sendNotification(fcmToken, notificationPayload, dataPayload);