import connectToMongo from './database/db.js';
import express from 'express';
import cors from 'cors';
import cloudinary from 'cloudinary';
import 'dotenv/config';

import city from './routes/city.js';
import shop from './routes/shop.js';
import department from './routes/department.js';
import role from './routes/role.js';
import employee from './routes/employee.js';
import user from './routes/user.js';
import contact from './routes/contact.js';
import auth from './routes/auth.js';
import vehical from './routes/vehical.js';
import order from './routes/order.js'
import payment from './routes/payment.js'
import coupenCode from './routes/coupenCode.js'
import settlement from './routes/settlement.js';
import deviceToken from './routes/deviceToken.js'
import admin from './routes/admin.js'
import blog from './routes/blog.js'
import webhookRoutes from "./routes/webhook.js";



connectToMongo();
const app = express();
const port = 4000;

const corsOptions = {
    // origin: true, // Allow all origins temporarily for testing
    origin: ["http://localhost:5173", "https://ride-way-frontend.vercel.app"],
    methods: ["GET", "HEAD", "PUT", "PATCH", "POST", "DELETE"],
    credentials: true,
    optionsSuccessStatus: 200,
};

cloudinary.v2.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
});

app.use(express.json());
app.use(cors(corsOptions));


app.get('/', (req, res) => {
    res.send('Rideroz Server Working Fine')
});
app.use("/api/webhook", webhookRoutes);

app.use('/api/v1/city',city);
app.use('/api/v1/contacts',contact);
app.use('/api/v1/shop',shop);
app.use('/api/v1/department',department);
app.use('/api/v1/role',role);
app.use('/api/v1/employee',employee);
app.use('/api/v1/auth',auth);
app.use("/api/v1/user",user);
app.use("/api/v1/blog",blog);
app.use('/api/v1/vehicle',vehical);
app.use('/api/v1/order',order);
app.use('/api/v1/payment',payment);
app.use('/api/v1/coupenCode',coupenCode);
app.use('/api/v1/shopPayment',settlement);
app.use('/api/v1/deviceToken',deviceToken);
app.use('/api/v1/admin',admin);


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
})
