// routes/vehicleRoutes.js
import express from "express";
import multer from "multer";

import {
  addVehicle,
  addVehicleByShopId,
  getNearbyVehicles,
  getVehicles,
  getVehicleById,
  updateVehicleAvailability,
  addReview,
  getVehicleRating,
  deleteReview,
  getVehiclesByShopId,
  deleteVehicle,
} from "../controllers/vehicleController.js";

import {
  authenticateAnyRoles,       // role‑based
  authenticateLoggedInUser,   // any logged‑in user
} from "../middleware/authMiddleware.js"; // adjust path if needed

const router  = express.Router();
const storage = multer.diskStorage({});
const upload  = multer({ storage });

/* ─────────────  Host‑only  ───────────── */

// Host adds a vehicle to **their** shop
router.post(
  "/add-vehicle",
  authenticateAnyRoles("admin"),
  upload.array("vehicleImage", 2),
  addVehicle
);

// Host updates availability of their vehicle
router.put(
  "/update-availability/:id",
  authenticateAnyRoles("admin"),
  updateVehicleAvailability
);

/* ─────────────  Admin‑only  ───────────── */

// Admin adds a vehicle to any shop (by :shopId)
router.post(
  "/add-vehicle/:shopId",
  authenticateAnyRoles("admin"),
  upload.array("vehicleImage", 2),
  addVehicleByShopId
);

// Admin or Host deletes a vehicle
router.delete(
  "/delete-vehicle/:id",
  authenticateAnyRoles("admin"),
  deleteVehicle
);

/* ─────────────  Admin + Host  ───────────── */

// List all vehicles
router.get(
  "/get-vehicles",
  authenticateAnyRoles("admin"),
  getVehicles
);

// Get vehicles belonging to a particular shop
router.get(
  "/get-vehicles-by-shop-id/:shopId",
  authenticateAnyRoles("admin"),
  getVehiclesByShopId
);

/* ─────────────  Public / Logged‑in Users  ───────────── */

// Public listings near user
router.get("/vehicles-nearby", getNearbyVehicles);

// Public single vehicle view
router.get("/get-vehicle/:id", getVehicleById);

// Add review (any logged‑in user)
router.post("/add-review/:vehicleId", authenticateLoggedInUser, addReview);

// Vehicle rating (public)
router.get("/vehicle-rating/:vehicleId", getVehicleRating);

// Delete review (logged‑in user; add extra checks in controller if needed)
router.delete(
  "/delete-review/:vehicleId/:reviewId",
  authenticateLoggedInUser,
  deleteReview
);

export default router;
