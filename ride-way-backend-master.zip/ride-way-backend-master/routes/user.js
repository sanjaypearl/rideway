// routes/userRoutes.js
import express from "express";
import {
  signUp,
  getUsers,
  getUserById,
  editUser,
  deleteUser,
} from "../controllers/userController.js";

import {
  authenticateLoggedInUser,   // any logged‑in user
  authenticateAnyRoles,       // supply one or more allowed roles
} from "../middleware/authMiddleware.js"; // adjust path if needed

const router = express.Router();

/* ───────────── Public ───────────── */
router.post("/sign-up", signUp);   // REST‑y kebab case, optional change

/* ───────────── Admin / Manager ───────────── */

// List all users
router.get(
  "/get-users",
  authenticateAnyRoles("admin"),
  getUsers
);

// Edit a user
router.put(
  "/edit-user/:id",
  authenticateAnyRoles("admin"),
  editUser
);

// Delete a user
router.delete(
  "/delete-user/:id",
  authenticateAnyRoles("admin"),
  deleteUser
);

/* ───────────── Any Logged‑in User ───────────── */

// Get individual user (self or by ID if authorised elsewhere)
router.get("/get-user/:id", authenticateLoggedInUser, getUserById);

export default router;
