import express from "express";
import multer from "multer";
import { settleOrder } from "../controllers/settlementController.js";
import { authenticateAnyRoles } from "../middleware/authMiddleware.js"; // updated import

const router = express.Router();

/* ───── Multer Setup ───── */
const storage = multer.diskStorage({});
const upload = multer({ storage });

/* ───── Routes ───── */

// Only admins can settle orders
router.post(
  "/settle/:orderId",
  authenticateAnyRoles("admin"),
  upload.fields([{ name: "settlementProofImage", maxCount: 1 }]),
  settleOrder
);

export default router;
