// routes/contactRoutes.js
import express from "express";
import { createContact, getAllContacts } from "../controllers/contactController.js";
import { authenticateAdmin } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post('/', createContact);
router.get('/',authenticateAdmin, getAllContacts);

export default router;
