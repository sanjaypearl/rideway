import express from "express";
import multer from "multer";

import {
  addShop,
  getShops,
  editShop,
  deleteShop,
  verifyOwnerAccount,
  deactivateShopByOwner,
  activateShopByOwner,
  deactivateShopByAdmin,
  activateShopByAdmin,
  getShopStats,
} from "../controllers/shopController.js";

import {
  authenticateAnyRoles,
  authenticateLoggedInUser,
} from "../middleware/authMiddleware.js"; // Update path if needed

const router = express.Router();

/* ────────── Multer Setup ────────── */
const storage = multer.diskStorage({});
const upload = multer({ storage });

/* ────────── Routes ────────── */

// Add shop (public or signup context)
router.post(
  "/add-shop",
  upload.fields([{ name: "shopImage", maxCount: 1 }]),
  addShop
);

// Admin/Host can get shops
router.get("/get-shops", authenticateAnyRoles("admin"), getShops);

// Admin/Host/Employee can edit a shop
router.put(
  "/edit-shop/:id",
  authenticateAnyRoles("admin"),
  upload.fields([
    { name: "shopImage", maxCount: 1 },
    { name: "legalDoc", maxCount: 1 },
  ]),
  editShop
);

// Admin/Host can delete a shop
router.delete("/delete-shop/:id", authenticateAnyRoles("admin"), deleteShop);

// Admin or employee verifies shop owner
router.put(
  "/shop-owner-account-verify/:shopId",
  authenticateAnyRoles("admin"),
  verifyOwnerAccount
);

// Host (owner) deactivates or activates shop
router.put(
  "/deactivate-shop-by-owner/:shopId",
  authenticateAnyRoles("admin"),
  deactivateShopByOwner
);
router.put(
  "/activate-shop-by-owner/:shopId",
  authenticateAnyRoles("admin"),
  activateShopByOwner
);

// Admin deactivates or activates shop
router.put(
  "/deactivate-shop-by-admin/:shopId",
  authenticateAnyRoles("admin"),
  deactivateShopByAdmin
);
router.put(
  "/activate-shop-by-admin/:shopId",
  authenticateAnyRoles("admin"),
  activateShopByAdmin
);

// Shop statistics (open route or protect if needed)
router.get("/shop-stats/:shopId", getShopStats);

export default router;
